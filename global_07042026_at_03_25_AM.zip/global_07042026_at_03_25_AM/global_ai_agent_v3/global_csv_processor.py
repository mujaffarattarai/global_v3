# =============================================================
# global_csv_processor.py
# Unified processor — works for ALL apps, ALL scenarios.
#
# Web mode  : called with app_key + scenario_key + progress_queue
# Batch mode: called with app_key only — scenario detected per row
#
# Multi-zone (SCRM): scenario_key IS the zone (ZONE_1 … ZONE_4).
#   Each zone has its own DB config in apps_registry.yaml.
#   All zones share the same SQL, SOP, rules, and RAG vectors.
# =============================================================

import pandas as pd
import re
import os
import json
import logging
import importlib
import requests
import oracledb

from datetime import datetime
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

from config_utils import load_properties
from app_registry import get_app_config
from rag_engine    import RAGEngine

# ── Logging ───────────────────────────────────────────────────
logger = logging.getLogger(__name__)

# ── Oracle client — lazy init ──────────────────────────────────
# Do NOT call init_oracle_client() at module load time.
# LD_LIBRARY_PATH must be set before first DB connection.
# Called once lazily inside process_csv() just before connecting.
_oracle_initialized = False

def _ensure_oracle_client():
    global _oracle_initialized
    if not _oracle_initialized:
        oracledb.init_oracle_client()
        _oracle_initialized = True

# ── Constants ─────────────────────────────────────────────────
SUMMARY_COLUMN   = "Summary*"
TEXT_COLUMNS     = ["Summary*", "Notes", "Resolution", "Attachment"]
MSISDN_REGEX     = r"\b[6-9]\d{9}\b"
ORDER_CODE_REGEX = r"\b[A-Z]{3,}[0-9]{6,}\b"

AI_COLUMNS = [
    "AI_Scenario_Detected",
    "AI_Zone_Found",
    "AI_Primary_Rule",
    "AI_RAG_Context",
    "AI_RAG_Score",
    "AI_Root_Cause",
    "AI_Status",
    "AI_Action",
    "AI_Rule_Reference",
    "AI_RAG_Reference",
    "AI_Narrative_Response",
    "AI_Confidence",
    "AI_LLM_Raw",
    "AI_Skip_Reason",
]

# =============================================================
# SCENARIO KEYWORD FILTER
# Used in batch mode to auto-detect the scenario per row.
# Web mode passes scenario_key explicitly — keywords not used.
# Leave list EMPTY to always process (no filter).
# =============================================================
SCENARIO_KEYWORDS = {
    # Telecom Digital
    "UNBLOCK": [
        "unblock", "release", "digital block", "block release",
        "number block", "unblocking", "neo block", "neo-block",
        "sim block", "number release", "release number",
    ],
    "FRC": [
        "frc", "first recharge", "first charge", "recharge",
        "activation", "activate", "frc failed", "frc pending",
        "frc not done", "first time recharge",
    ],
    "REFUND": [
        "refund", "reversal", "money back", "payment failed",
        "payment not received", "deducted", "amount deducted",
        "refund pending", "refund not received", "payment reverse",
    ],
    # SKYC
    "CAF_SUBMISSION": [
        "caf", "caf submission", "form submission", "kyc",
        "document", "verification", "caf pending", "caf rejected",
        "caf not submitted", "customer form", "caf status",
    ],
    # SCRM — all zones share these keywords
    # (zone is already known from which input folder the file came from)
    "SCRM_UNBLOCK": [
        "unblock", "release", "block", "account block", "scrm block",
        "sim block", "number release",
    ],
}

# ── RAG engine cache — keyed by vector_file path ──────────────
_rag_cache = {}


def _get_rag_engine(cfg, embed_url, embed_model):
    key = cfg["vector_file"]
    if key not in _rag_cache:
        _rag_cache[key] = RAGEngine(
            vector_file=cfg["vector_file"],
            embed_url=embed_url,
            embed_model=embed_model,
        )
    return _rag_cache[key]

# =============================================================
# SCRM ZONE CONNECTION HELPER
# Tries each zone in order, returns first connection + zone_key
# where data is actually found for the given identifiers.
# =============================================================
def _scrm_first_match_zone(app_key, identifiers, base_sql):
    """
    Queries zone DBs in order (ZONE_1 → ZONE_2 → ZONE_3 → ZONE_4).
    Connects, queries, and closes each zone DB fully before moving on.
    Returns (zone_key, raw_solution) — no open cursor/conn returned.
    Falls back to last zone result if no zone has data.
    """
    from app_registry import _load_registry
    reg     = _load_registry()
    app_cfg = reg.get(app_key, {})
    zones   = app_cfg.get("zone_order",
              list(app_cfg.get("scenarios", {}).keys()))

    last_zone     = zones[-1] if zones else "ZONE_1"
    last_solution = "NO DATA FOUND IN ANY ZONE"

    for zone_key in zones:
        conn   = None
        cursor = None
        try:
            cfg      = get_app_config(app_key, zone_key)
            db_props = load_properties(cfg["db_config_path"])
            db_cfg   = {
                "user":     db_props["db.user"],
                "password": db_props["db.password"],
                "dsn":      db_props["db.dsn"],
            }
            _ensure_oracle_client()
            conn   = oracledb.connect(**db_cfg)
            cursor = conn.cursor()

            parts = []
            found = False
            for search_by, value in identifiers:
                try:
                    result = run_query(cursor, base_sql, value, search_by)
                except Exception as e:
                    result = f"DB ERROR: {e}"
                parts.append(f"{search_by}: {value}\n{result}")
                if "NO DATA FOUND" not in result and "DB ERROR" not in result:
                    found = True

            raw_solution  = "\n\n".join(parts)
            last_zone     = zone_key
            last_solution = raw_solution

            if found:
                logger.info(f"SCRM zone match: {zone_key} has data")
                return zone_key, raw_solution
            else:
                logger.info(f"SCRM zone {zone_key}: NO DATA — trying next zone")

        except Exception as e:
            logger.warning(f"SCRM zone {zone_key} connection error: {e}")

        finally:
            # Always close cursor and conn before moving to next zone
            try:
                if cursor: cursor.close()
            except Exception:
                pass
            try:
                if conn: conn.close()
            except Exception:
                pass

    logger.info(f"SCRM: no zone had data — returning result from {last_zone}")
    return last_zone, last_solution



# =============================================================
# SCENARIO DETECTION (batch mode only)
# =============================================================
def detect_scenario(row):
    """
    Scans text columns for scenario keywords.
    Returns (scenario_key, None) on match, or (None, reason).
    """
    combined = " ".join(
        str(row.get(col, "")).lower() for col in TEXT_COLUMNS
    )
    for scenario, keywords in SCENARIO_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in combined:
                return scenario, None
    return None, "No scenario detected from ticket content"


def matches_scenario_keywords(row, scenario_key):
    """
    Web mode filter — row must contain at least one keyword for the scenario.
    Returns (True, None) to process, (False, reason) to skip.
    Empty keyword list → always process.
    """
    keywords = SCENARIO_KEYWORDS.get(scenario_key.upper(), [])
    if not keywords:
        return True, None

    combined = " ".join(
        str(row.get(col, "")).lower() for col in TEXT_COLUMNS
    )
    for kw in keywords:
        if kw.lower() in combined:
            return True, None

    return False, f"No keyword match for scenario '{scenario_key}' — skipped"


# =============================================================
# IDENTIFIER EXTRACTION
# =============================================================
def extract_identifiers(row):
    msisdns, order_codes = [], []
    for col in TEXT_COLUMNS:
        val = str(row.get(col, ""))
        msisdns.extend(re.findall(MSISDN_REGEX, val))
        order_codes.extend(re.findall(ORDER_CODE_REGEX, val))
    return list(dict.fromkeys(msisdns)), list(dict.fromkeys(order_codes))


# =============================================================
# DB HELPERS
# =============================================================
def parse_db_result(raw_text):
    data = {}
    for line in raw_text.split("\n"):
        if ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip()
    return data


def load_sql(query_file):
    with open(query_file, "r", encoding="utf-8") as f:
        return f.read()


def run_query(cursor, sql, value, search_by):
    if search_by == "ORDER_CODE":
        sql = sql.replace(
            "WHERE caf.SELECTED_NUMBER = :1",
            "WHERE caf.ORDER_CODE = :1",
        )
    cursor.execute(sql, [value])
    row = cursor.fetchone()
    return row[0] if row else "NO DATA FOUND"


# =============================================================
# RULES LOADER
# =============================================================
def load_rules_evaluator(rules_module_path):
    module = importlib.import_module(rules_module_path)
    return module.evaluate_rules


# =============================================================
# LLM: STRUCTURED JSON DECISION
# =============================================================
def generate_structured_llm(summary, db_result, rule_output, rag_chunks,
                             llm_url, llm_model, llm_enabled, emit=None):
    if not llm_enabled:
        return None, None

    all_matched = rule_output.get("all_matched_details", [])
    matched_rules_text = "\n".join(
        f"  - [{r['rule_id']}] {r['description']}\n    Condition: {r['condition']}"
        for r in all_matched
    ) if all_matched else "  None"

    prompt = f"""You are a telecom support AI decision formatter.
You DO NOT make business decisions. You follow the Primary Rule as the FINAL authority.

Respond ONLY with valid JSON in this exact format:
{{
  "root_cause": "one sentence",
  "status": "one word or short phrase",
  "action": "one sentence recommended action"
}}

CRITICAL: Your entire response must be ONLY the JSON object above.
No explanation. No markdown. No backticks. No preamble. Just the raw JSON.
If you cannot determine a value, use "N/A" as the string value.

TICKET SUMMARY:
{summary}

DATABASE RESULT:
{db_result}

ALL MATCHED RULES:
{matched_rules_text}

PRIMARY RULE: [{rule_output.get("reference")}] {rule_output.get("decision")}
CONDITION: {rule_output.get("condition")}

RAG CONTEXT:
{chr(10).join(rag_chunks) if rag_chunks else "N/A"}
"""

    if emit:
        emit({"type": "prompt_start", "label": "LLM Structured Prompt"})
        for line in prompt.strip().splitlines():
            emit({"type": "prompt_line", "line": line})
        emit({"type": "prompt_end"})

    try:
        response = requests.post(
            llm_url,
            json={"model": llm_model, "prompt": prompt, "stream": False},
            timeout=120,
        )
        response.raise_for_status()
        raw = response.json().get("response", "").strip()

        # Strip markdown fences if present
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        parsed = json.loads(clean)

        if emit:
            emit({"type": "llm_structured", "msg": str(parsed)})

        return parsed, raw

    except Exception as e:
        logger.error(f"Structured LLM Error: {e}")
        return None, None


# =============================================================
# LLM: HUMAN NARRATIVE RESPONSE
# =============================================================
def generate_human_response(summary, db_result, rule_output, rag_chunks,
                             llm_url, llm_model, llm_enabled, emit=None,
                             db_parsed=None):
    if not llm_enabled:
        return ""

    if db_parsed is None:
        db_parsed = {}

    prompt = f"""You are a telecom support resolution writer.

RULES:
- DO NOT copy text from SOP context
- DO NOT contradict the Primary Rule decision
- Base root cause on DATABASE RESULT only
- Base resolution on PRIMARY RULE only
- Always start with "Dear User,"
- Always end with exactly this line:
"To know the latest status of any Order/Transaction/Refund/FRC/Unblock Please Use Neo Assist(https://neogold.myvi.in/cms/login). User access for Neo Assist can be created by raising a ticket to IT Service Desk (itsd.support@vodafoneidea.com). As this ticket does not require any action, hence we are cancelling this ticket."

Ticket Summary: {summary}

Key DB Facts:
- MSISDN        : {db_parsed.get("MSISDN") or db_parsed.get("SELECTED_NUMBER") or "—"}
- ACCOUNT_STATUS: {db_parsed.get("ACCOUNT_STATUS") or db_parsed.get("ORDER_STATUS") or "—"}
- IS_UNBLOCKED  : {db_parsed.get("IS_UNBLOCKED") or "—"}
- BLOCK_REASON  : {db_parsed.get("BLOCK_REASON") or "—"}
- ZONE          : {db_parsed.get("ZONE") or "—"}
- OPS_COMMENTS  : {db_parsed.get("OPS_COMMENTS") or "—"}

Primary Rule: [{rule_output.get("reference")}] {rule_output.get("decision")}

Write the resolution note now. No JSON. No bullet points. Plain paragraph only.
"""

    if emit:
        emit({"type": "prompt_start", "label": "LLM Narrative Prompt"})
        for line in prompt.strip().splitlines():
            emit({"type": "prompt_line", "line": line})
        emit({"type": "prompt_end"})

    try:
        response = requests.post(
            llm_url,
            json={"model": llm_model, "prompt": prompt, "stream": False},
            timeout=120,
        )
        response.raise_for_status()
        result = response.json().get("response", "").strip()

        if emit:
            emit({"type": "narrative_response", "msg": result})

        return result

    except Exception as e:
        logger.error(f"Narrative LLM Error: {e}")
        return "AI narrative generation failed."


# =============================================================
# EXCEL OUTPUT
# =============================================================
def write_styled_excel(df, output_file):
    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Report")
        ws = writer.sheets["Report"]

        header_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)
        wrap_align  = Alignment(wrap_text=True, vertical="top")
        thin_border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"),  bottom=Side(style="thin"),
        )

        for cell in ws[1]:
            cell.fill   = header_fill
            cell.font   = header_font
            cell.border = thin_border
            ws.column_dimensions[cell.column_letter].width = 35

        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = wrap_align
                cell.border    = thin_border


# =============================================================
# CORE ROW PROCESSOR
# Shared by both web and batch paths
# =============================================================
def _process_row(idx, row, df, scenario_key, cfg,
                 cursor, sql, evaluate_rules, rules_scenario,
                 rag_engine, llm_url, llm_model, llm_enabled,
                 total_rows, emit):
    """
    Processes a single DataFrame row.
    Returns a dict with counters: processed, skipped, unknown, failed,
    scenario_key, rule_matched, rag_used, confidence.
    """
    summary = str(row.get(SUMMARY_COLUMN, "")).strip()
    result  = {
        "processed": 0, "skipped": 0, "unknown": 0, "failed": 0,
        "scenario_key": scenario_key, "rule_matched": False,
        "rag_used": False, "confidence": 0,
    }

    try:
        # ── Keyword filter (web mode only; batch skips this) ──
        if scenario_key:
            df.at[idx, "AI_Scenario_Detected"] = scenario_key
            matched, skip_reason = matches_scenario_keywords(row, rules_scenario)
            if not matched:
                df.at[idx, "AI_Skip_Reason"] = skip_reason
                df.at[idx, "Solution"]        = "SKIPPED"
                emit({"type": "row", "done": idx + 1, "total": total_rows,
                      "ticket": summary[:40], "msisdn": "—", "rule": "SKIPPED"})
                result["skipped"] = 1
                return result

        msisdns, order_codes = extract_identifiers(row)
        identifiers = (
            [("MSISDN", m) for m in msisdns] +
            [("ORDER_CODE", o) for o in order_codes]
        )

        if not identifiers:
            df.at[idx, "Solution"] = "No identifiers found"
            emit({"type": "row", "done": idx + 1, "total": total_rows,
                  "ticket": summary[:40], "msisdn": "—", "rule": "No identifiers"})
            result["unknown"] = 1
            return result

        # ── DB queries ────────────────────────────────────────
        db_parts = []
        for search_by, value in identifiers:
            try:
                qr = run_query(cursor, sql, value, search_by)
            except Exception as e:
                qr = f"DB ERROR: {e}"
            db_parts.append(f"{search_by}: {value}\n{qr}")

        raw_solution = "\n\n".join(db_parts)
        df.at[idx, "Solution"] = raw_solution
        first_id = msisdns[0] if msisdns else (order_codes[0] if order_codes else "—")
        emit({"type": "db", "msg": f"Fetched data for {first_id}"})

        # ── Rules engine ──────────────────────────────────────
        structured  = parse_db_result(raw_solution)
        rule_output = evaluate_rules(rules_scenario, structured)
        df.at[idx, "AI_Primary_Rule"] = rule_output.get("primary_rule")

        rule_matched = bool(rule_output.get("primary_rule"))
        result["rule_matched"] = rule_matched

        # ── Decision path: Rule → RAG fallback ───────────────
        rag_chunks, rag_refs, rag_score = [], [], 0.0

        if rule_matched:
            emit({"type": "rag", "score": "SKIPPED", "ref": "Rule matched — RAG not required"})
            df.at[idx, "AI_RAG_Score"]     = "SKIPPED"
            df.at[idx, "AI_RAG_Context"]   = "SKIPPED - Rule Matched"
            df.at[idx, "AI_RAG_Reference"] = "SKIPPED - Rule Matched"
        else:
            emit({"type": "rag", "msg": "No rule matched — calling RAG"})
            rag_results = rag_engine.search(
                summary + raw_solution, top_k=1, scenario=rules_scenario
            )
            if rag_results:
                rag_score = float(rag_results[0][0])
                for score, text, chunk_id, section in rag_results:
                    rag_chunks.append(text)
                    rag_refs.append(f"{chunk_id} ({section})")

            emit({"type": "rag", "score": round(rag_score, 4),
                  "ref": rag_refs[0] if rag_refs else "—"})
            df.at[idx, "AI_RAG_Score"]     = round(rag_score, 4)
            df.at[idx, "AI_RAG_Context"]   = "\n---\n".join(rag_chunks)
            df.at[idx, "AI_RAG_Reference"] = ", ".join(rag_refs)
            result["rag_used"] = True

        # ── LLM Structured ────────────────────────────────────
        ai_result, raw_llm = generate_structured_llm(
            summary, raw_solution, rule_output, rag_chunks,
            llm_url, llm_model, llm_enabled, emit=emit,
        )
        df.at[idx, "AI_LLM_Raw"]        = raw_llm
        df.at[idx, "AI_Rule_Reference"] = rule_output.get("rule_id")

        if ai_result:
            df.at[idx, "AI_Root_Cause"] = ai_result.get("root_cause", "")
            df.at[idx, "AI_Status"]     = ai_result.get("status", "")
            df.at[idx, "AI_Action"]     = ai_result.get("action", "")
            emit({"type": "llm",
                  "msg": f"Status={ai_result.get('status','—')} | Action={ai_result.get('action','—')}"})
        else:
            df.at[idx, "AI_Root_Cause"] = rule_output.get("condition", "")
            df.at[idx, "AI_Status"]     = rule_output.get("decision", "")
            df.at[idx, "AI_Action"]     = rule_output.get("reference", "")
            emit({"type": "llm", "msg": "LLM parse failed — using rule engine fallback"})

        # ── Narrative ─────────────────────────────────────────
        human_text = generate_human_response(
            summary, raw_solution, rule_output, rag_chunks,
            llm_url, llm_model, llm_enabled, emit=emit,
            db_parsed=structured,
        )
        df.at[idx, "AI_Narrative_Response"] = human_text

        # ── Confidence ────────────────────────────────────────
        confidence = 0
        if rule_matched:
            confidence += 40
            if ai_result:
                confidence += 30
        else:
            if rag_score > 0.7:
                confidence += 30
            if ai_result:
                confidence += 30
        df.at[idx, "AI_Confidence"] = confidence
        result["confidence"]        = confidence

        emit({"type": "row", "done": idx + 1, "total": total_rows,
              "ticket": summary[:40], "msisdn": first_id,
              "rule": rule_output.get("primary_rule") or "No match — RAG used"})

        result["processed"] = 1
        return result

    except Exception as e:
        logger.error(f"Row {idx + 1} ERROR: {e}", exc_info=True)
        df.at[idx, "AI_Skip_Reason"] = f"Row error: {e}"
        result["failed"] = 1
        return result


# =============================================================
# PUBLIC API — process_csv
#
# Web mode  : call with scenario_key set
# Batch mode: call with scenario_key=None (auto-detected per row)
# =============================================================
def process_csv(input_csv, output_file, app_key,
                scenario_key=None, progress_queue=None):
    """
    Main entry point.

    app_key      : e.g. "TELECOM_DIGITAL", "SCRM"
    scenario_key : e.g. "UNBLOCK", "ZONE_1"
                   Pass None in batch mode — detected per row.
    progress_queue: queue.Queue for SSE streaming (web mode only)
    """

    def emit(data):
        if progress_queue:
            progress_queue.put(data)

    # batch_mode = True when called from batch processor (no progress_queue)
    # SCRM passes scenario_key='ZONE_1' etc. but is still batch mode
    batch_mode = (progress_queue is None)
    file_name  = os.path.basename(input_csv)

    logger.info("=" * 60)
    logger.info(f"PROCESS START: app={app_key} scenario={scenario_key or 'AUTO'} file={file_name}")
    logger.info("=" * 60)

    # ── Stats DB (batch mode only) ────────────────────────────
    file_id     = None
    start_time  = datetime.now()
    total_rows  = 0
    proc_rows   = 0
    skip_rows   = 0
    unk_rows    = 0
    fail_rows   = 0
    scenario_counts = {
        "UNBLOCK": 0, "FRC": 0, "REFUND": 0,
        "CAF_SUBMISSION": 0, "SCRM_UNBLOCK": 0, "UNKNOWN": 0,
    }

    if batch_mode:
        try:
            from batch.stats_db import (
                insert_file_start, update_file_end,
                insert_row_stat, upsert_daily_stats,
                upsert_live_progress, insert_result_row,
            )
            _stats_enabled = True
            file_id = insert_file_start(file_name, app_key, input_csv)
        except Exception as _se:
            logger.warning(f"Stats DB not available: {_se}")
            _stats_enabled = False
    else:
        _stats_enabled = False

    # ── Resolve scenario for connection ──────────────────────
    # For multi-zone apps (SCRM) scenario_key carries the zone.
    # Batch mode: we need to load DB config from the first scenario
    # of the app or from the zone folder name passed by batch_processor.
    resolve_scenario = scenario_key

    if batch_mode:
        # batch_processor passes app_key="SCRM" + scenario_key="ZONE_1"
        # (batch_processor is updated to always pass zone for SCRM)
        # Fallback: use first scenario in registry
        if resolve_scenario is None:
            from app_registry import _load_registry
            reg     = _load_registry()
            app_cfg = reg.get(app_key, {})
            scenarios = list(app_cfg.get("scenarios", {}).keys())
            resolve_scenario = scenarios[0] if scenarios else None

    if not resolve_scenario:
        raise RuntimeError(f"Cannot determine scenario for app '{app_key}'")

    cfg      = get_app_config(app_key, resolve_scenario)
    db_props = load_properties(cfg["db_config_path"])

    db_config = {
        "user":     db_props["db.user"],
        "password": db_props["db.password"],
        "dsn":      db_props["db.dsn"],
    }

    llm_enabled = db_props.get("llm.enabled", "false").lower() == "true"
    llm_model   = db_props.get("llm.model", "llama3.2:3b")
    llm_url     = db_props.get("llm.url")
    embed_url   = db_props.get("embedding.url")
    embed_model = db_props.get("embedding.model")

    # ── Load SQL, rules, RAG ─────────────────────────────────
    # For SCRM: scenario config for all zones points to the same files
    sql            = load_sql(cfg["query_file"])
    evaluate_rules = load_rules_evaluator(cfg["rules_module"])
    rules_scenario = cfg["rules_scenario"]
    rag_engine     = _get_rag_engine(cfg, embed_url, embed_model)

    # ── Read CSV ─────────────────────────────────────────────
    df = pd.read_csv(input_csv, encoding="latin1", engine="python")
    df = df.loc[:, ~df.columns.str.contains("^Unnamed")]

    if "Solution" not in df.columns:
        df["Solution"] = ""
    for col in AI_COLUMNS:
        if col not in df.columns:
            df[col] = ""

    total_rows = len(df)
    emit({"type": "total", "value": total_rows})

    # ── Connect to DB ─────────────────────────────────────────
    # SCRM: no single connection here — zone is resolved per row
    # All other apps: connect once and reuse for all rows
    is_scrm = (app_key.upper() == "SCRM")

    if not is_scrm:
        _ensure_oracle_client()
        try:
            conn   = oracledb.connect(**db_config)
            cursor = conn.cursor()
            logger.info(f"DB connected: {db_props['db.dsn']}")
        except Exception as db_err:
            err_msg = (
                f"DB Connection Failed for app='{app_key}' zone/scenario='{resolve_scenario}': "
                f"{db_err}. Check properties file: {cfg['db_config_path']}"
            )
            logger.error(err_msg)
            emit({"type": "error", "msg": err_msg})
            if _stats_enabled:
                update_file_end(file_id, None, "FAILED", 0, 0, 0, 0, 0,
                                (datetime.now() - start_time).total_seconds(),
                                error_message=err_msg)
            raise RuntimeError(err_msg) from db_err
    else:
        conn   = None
        cursor = None
        logger.info(f"SCRM multi-zone mode — zone resolved per row")

    # ── Process rows ──────────────────────────────────────────
    try:
        for idx, row in df.iterrows():

            # Batch mode: auto-detect scenario per row
            # SCRM skips keyword detection — zone logic handles all rows
            if batch_mode and not is_scrm:
                detected, det_reason = detect_scenario(row)
                if not detected:
                    df.at[idx, "AI_Skip_Reason"]       = det_reason
                    df.at[idx, "AI_Scenario_Detected"]  = "UNKNOWN"
                    df.at[idx, "Solution"]              = "UNKNOWN"
                    unk_rows += 1
                    scenario_counts["UNKNOWN"] = scenario_counts.get("UNKNOWN", 0) + 1
                    if _stats_enabled:
                        insert_row_stat(file_id, file_name, app_key,
                                        "UNKNOWN", False, False, 0, "UNKNOWN")
                    continue
                effective_scenario = detected
            else:
                effective_scenario = scenario_key or "SCRM_UNBLOCK"

            # ── SCRM: find first zone with data per row ──────
            # _scrm_first_match_zone handles all DB connections internally
            # and returns only (zone_key, raw_solution) — no open cursor
            if is_scrm:
                msisdns, order_codes = extract_identifiers(row)
                identifiers = (
                    [("MSISDN", m) for m in msisdns] +
                    [("ORDER_CODE", o) for o in order_codes]
                )
                if identifiers:
                    zone_found, raw_solution = _scrm_first_match_zone(
                        app_key, identifiers, sql
                    )
                    df.at[idx, "AI_Zone_Found"]        = zone_found
                    df.at[idx, "AI_Scenario_Detected"] = "SCRM_UNBLOCK"
                    df.at[idx, "Solution"]              = raw_solution
                    emit({"type": "db", "msg": f"SCRM zone match: {zone_found}"})

                    # Run rules, RAG, LLM on the fetched data
                    structured  = parse_db_result(raw_solution)
                    rule_output = evaluate_rules(rules_scenario, structured)
                    df.at[idx, "AI_Primary_Rule"] = rule_output.get("primary_rule")
                    rule_matched = bool(rule_output.get("primary_rule"))

                    rag_chunks, rag_refs, rag_score = [], [], 0.0
                    if rule_matched:
                        df.at[idx, "AI_RAG_Score"]     = "SKIPPED"
                        df.at[idx, "AI_RAG_Context"]   = "SKIPPED - Rule Matched"
                        df.at[idx, "AI_RAG_Reference"] = "SKIPPED - Rule Matched"
                        emit({"type": "rag", "score": "SKIPPED", "ref": "Rule matched"})
                    else:
                        summary    = str(row.get(SUMMARY_COLUMN, "")).strip()
                        rag_results = rag_engine.search(
                            summary + raw_solution, top_k=1, scenario=rules_scenario
                        )
                        if rag_results:
                            rag_score = float(rag_results[0][0])
                            for score, text, chunk_id, section in rag_results:
                                rag_chunks.append(text)
                                rag_refs.append(f"{chunk_id} ({section})")
                        df.at[idx, "AI_RAG_Score"]     = round(rag_score, 4)
                        df.at[idx, "AI_RAG_Context"]   = "\n---\n".join(rag_chunks)
                        df.at[idx, "AI_RAG_Reference"] = ", ".join(rag_refs)
                        emit({"type": "rag", "score": round(rag_score, 4),
                              "ref": rag_refs[0] if rag_refs else "—"})

                    summary    = str(row.get(SUMMARY_COLUMN, "")).strip()
                    first_id   = msisdns[0] if msisdns else (order_codes[0] if order_codes else "—")

                    ai_result, raw_llm = generate_structured_llm(
                        summary, raw_solution, rule_output, rag_chunks,
                        llm_url, llm_model, llm_enabled, emit=emit,
                    )
                    df.at[idx, "AI_LLM_Raw"]        = raw_llm
                    df.at[idx, "AI_Rule_Reference"]  = rule_output.get("rule_id")

                    if ai_result:
                        df.at[idx, "AI_Root_Cause"] = ai_result.get("root_cause", "")
                        df.at[idx, "AI_Status"]     = ai_result.get("status", "")
                        df.at[idx, "AI_Action"]     = ai_result.get("action", "")
                    else:
                        df.at[idx, "AI_Root_Cause"] = rule_output.get("condition", "")
                        df.at[idx, "AI_Status"]     = rule_output.get("decision", "")
                        df.at[idx, "AI_Action"]     = rule_output.get("reference", "")

                    human_text = generate_human_response(
                        summary, raw_solution, rule_output, rag_chunks,
                        llm_url, llm_model, llm_enabled, emit=emit,
                        db_parsed=structured,
                    )
                    df.at[idx, "AI_Narrative_Response"] = human_text

                    confidence = 0
                    if rule_matched:
                        confidence += 40
                        if ai_result: confidence += 30
                    else:
                        if rag_score > 0.7: confidence += 30
                        if ai_result:       confidence += 30
                    df.at[idx, "AI_Confidence"] = confidence

                    emit({"type": "row", "done": idx + 1, "total": total_rows,
                          "ticket": summary[:40], "msisdn": first_id,
                          "rule": rule_output.get("primary_rule") or "No match — RAG used"})

                    row_result = {
                        "processed": 1, "skipped": 0, "unknown": 0, "failed": 0,
                        "scenario_key": effective_scenario,
                        "rule_matched": rule_matched,
                        "rag_used": not rule_matched,
                        "confidence": confidence,
                    }
                else:
                    df.at[idx, "AI_Zone_Found"] = "NO IDENTIFIERS"
                    df.at[idx, "Solution"]       = "No identifiers found"
                    row_result = {
                        "processed": 0, "skipped": 0, "unknown": 1, "failed": 0,
                        "scenario_key": effective_scenario, "rule_matched": False,
                        "rag_used": False, "confidence": 0,
                    }
            else:
                row_result = _process_row(
                    idx=idx, row=row, df=df,
                    scenario_key=effective_scenario,
                    cfg=cfg,
                    cursor=cursor, sql=sql,
                    evaluate_rules=evaluate_rules,
                    rules_scenario=rules_scenario,
                    rag_engine=rag_engine,
                    llm_url=llm_url, llm_model=llm_model, llm_enabled=llm_enabled,
                    total_rows=total_rows, emit=emit,
                )

            proc_rows += row_result["processed"]
            skip_rows += row_result["skipped"]
            unk_rows  += row_result["unknown"]
            fail_rows += row_result["failed"]

            sc = row_result["scenario_key"] or "UNKNOWN"
            scenario_counts[sc] = scenario_counts.get(sc, 0) + 1

            if _stats_enabled:
                row_status = (
                    "PROCESSED" if row_result["processed"]
                    else "SKIPPED" if row_result["skipped"]
                    else "UNKNOWN" if row_result["unknown"]
                    else "FAILED"
                )
                insert_row_stat(
                    file_id, file_name, app_key, sc,
                    row_result["rule_matched"],
                    row_result["rag_used"],
                    row_result["confidence"],
                    row_status,
                )

                # ── Live progress update ──────────────────────
                upsert_live_progress(
                    file_id    = file_id,
                    file_name  = file_name,
                    app_key    = app_key,
                    total_rows = total_rows,
                    current_row= idx + 1,
                    current_ticket = str(row.get(SUMMARY_COLUMN, ""))[:80],
                    current_msisdn = str(df.at[idx, "AI_Zone_Found"]
                                        if is_scrm
                                        else "").strip(),
                    current_zone   = str(df.at[idx, "AI_Zone_Found"]
                                        if is_scrm else "").strip(),
                    current_rule   = str(df.at[idx, "AI_Primary_Rule"] or "").strip(),
                )

                # ── Save full result row ──────────────────────
                # Detect ticket number column (Ticket No / Issue key / Ticket Number)
                ticket_col = next(
                    (c for c in df.columns
                     if c.lower().replace(" ","").replace("_","")
                        in ("ticketno","ticketnumber","issuekey","ticket","id")),
                    None
                )
                insert_result_row(
                    file_id              = file_id,
                    file_name            = file_name,
                    app_key              = app_key,
                    ticket_number        = str(df.at[idx, ticket_col]) if ticket_col else str(idx+1),
                    summary              = str(row.get("Summary*", row.get("Summary", ""))),
                    notes                = str(row.get("Notes",    "")),
                    solution             = str(df.at[idx, "Solution"]),
                    ai_zone_found        = str(df.at[idx, "AI_Zone_Found"]        if "AI_Zone_Found"        in df.columns else ""),
                    ai_primary_rule      = str(df.at[idx, "AI_Primary_Rule"]      if "AI_Primary_Rule"      in df.columns else ""),
                    ai_root_cause        = str(df.at[idx, "AI_Root_Cause"]        if "AI_Root_Cause"        in df.columns else ""),
                    ai_status            = str(df.at[idx, "AI_Status"]            if "AI_Status"            in df.columns else ""),
                    ai_action            = str(df.at[idx, "AI_Action"]            if "AI_Action"            in df.columns else ""),
                    ai_narrative         = str(df.at[idx, "AI_Narrative_Response"] if "AI_Narrative_Response" in df.columns else ""),
                    ai_confidence        = int(df.at[idx, "AI_Confidence"]        if "AI_Confidence"        in df.columns else 0),
                    ai_scenario_detected = str(df.at[idx, "AI_Scenario_Detected"] if "AI_Scenario_Detected" in df.columns else ""),
                )

        emit({"type": "done"})
        write_styled_excel(df, output_file)
        logger.info(f"Report saved: {output_file}")

        if _stats_enabled:
            duration = (datetime.now() - start_time).total_seconds()
            update_file_end(file_id, output_file, "SUCCESS",
                            total_rows, proc_rows, skip_rows,
                            unk_rows, fail_rows, duration)
            upsert_daily_stats(
                datetime.now().strftime("%Y-%m-%d"), app_key,
                total_rows, proc_rows, skip_rows,
                unk_rows, fail_rows, scenario_counts, "SUCCESS",
            )

        return df

    except Exception as e:
        logger.error(f"process_csv ERROR: {e}", exc_info=True)
        emit({"type": "error", "msg": str(e)})

        if _stats_enabled:
            duration = (datetime.now() - start_time).total_seconds()
            update_file_end(file_id, None, "FAILED",
                            total_rows, proc_rows, skip_rows,
                            unk_rows, fail_rows, duration,
                            error_message=str(e))
        raise

    finally:
        try:
            if not is_scrm:
                if cursor: cursor.close()
                if conn:   conn.close()
        except Exception:
            pass

