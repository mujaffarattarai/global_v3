# =============================================================
# config_utils.py
# Shared utility — loads .properties files into a dict
# =============================================================

def load_properties(file_path):
    props = {}
    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                if "=" in line:
                    key, value = line.split("=", 1)
                    props[key.strip()] = value.strip()
    return props
