#!/bin/bash
# =============================================================
# start.sh  — global_ai_agent (unified)
# Manages: Web Server (port 8008) + Batch Daemon + Dashboard (port 8009)
#
# Usage: ./start.sh [start|stop|restart|status|logs|logs-batch|logs-dashboard]
#python3 -c "import hashlib; print(hashlib.sha256('mujaffar123'.encode()).hexdigest())"
# =============================================================



export AGENT_USER_ADMIN=your_hashed_password
export AGENT_USER_MUJAFFAR=d985b30477881c458f4c71561800374c1483c4c19c07297849481afb035ab547

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$PROJECT_DIR/venv"

# ── Sub-service paths ─────────────────────────────────────────
BATCH_DIR="$PROJECT_DIR/batch"
LOG_DIR="$PROJECT_DIR/logs"
PID_DIR="$PROJECT_DIR/batch/pids"

WEB_PID="$PID_DIR/web_server.pid"
BATCH_PID="$PID_DIR/batch_processor.pid"
DASH_PID="$PID_DIR/dashboard_server.pid"

WEB_LOG="$LOG_DIR/web_server.log"
BATCH_LOG="$BATCH_DIR/logs/batch_processor.log"
DASH_LOG="$BATCH_DIR/logs/dashboard_server.log"

# ── Oracle instant client ─────────────────────────────────────
# ── Oracle instant client ───────────────────────────────────────────────
# Checks $PROJECT_DIR/instantclient_23_26 first (if you copied it here),
# then falls back to the original location in the old global_ai_agent dir.
INSTANTCLIENT="$PROJECT_DIR/instantclient_23_26"
if [ ! -d "$INSTANTCLIENT" ]; then
    INSTANTCLIENT="/home/postgres/global_ai_agent/instantclient_23_26"
fi
export LD_LIBRARY_PATH="$INSTANTCLIENT:$LD_LIBRARY_PATH"
export PYTHONPATH="$PROJECT_DIR:$PYTHONPATH"

# ── Colors ────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${CYAN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
err()  { echo -e "${RED}  ✘ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }

is_running() {
    local pid_file="$1"
    [ -f "$pid_file" ] && kill -0 "$(cat "$pid_file")" 2>/dev/null
}

get_pid() {
    [ -f "$1" ] && cat "$1" || echo "—"
}

# =============================================================
# START
# =============================================================
start() {
    echo ""
    log "Starting global_ai_agent (unified)..."
    echo ""

    mkdir -p "$LOG_DIR" "$PID_DIR" "$BATCH_DIR/logs"

    # ── Virtual env ───────────────────────────────────────────
    if [ ! -f "$VENV_DIR/bin/activate" ]; then
        err "Virtual env not found at: $VENV_DIR"
        err "Run: python -m venv $VENV_DIR && source $VENV_DIR/bin/activate && pip install -r requirements.txt"
        exit 1
    fi
    source "$VENV_DIR/bin/activate"
    ok "Virtual env activated"

    # ── Web server ────────────────────────────────────────────
    if is_running "$WEB_PID"; then
        warn "Web server already running (PID: $(get_pid $WEB_PID))"
    else
        cd "$PROJECT_DIR"
        nohup python -u global_app_server.py >> "$WEB_LOG" 2>&1 &
        echo $! > "$WEB_PID"
        sleep 2
        if is_running "$WEB_PID"; then
            ok "Web server started  (PID: $(get_pid $WEB_PID))"
            ok "URL: http://$(hostname -I | awk '{print $1}'):8010"
        else
            err "Web server failed to start — check: $WEB_LOG"
            exit 1
        fi
    fi

    echo ""

    # ── Batch processor ───────────────────────────────────────
    if is_running "$BATCH_PID"; then
        warn "Batch processor already running (PID: $(get_pid $BATCH_PID))"
    else
        cd "$BATCH_DIR"
        nohup python -u batch_processor.py >> "$BATCH_LOG" 2>&1 &
        echo $! > "$BATCH_PID"
        sleep 2
        if is_running "$BATCH_PID"; then
            ok "Batch processor started  (PID: $(get_pid $BATCH_PID))"
        else
            err "Batch processor failed to start — check: $BATCH_LOG"
            exit 1
        fi
    fi

    # ── Dashboard server ──────────────────────────────────────
    if is_running "$DASH_PID"; then
        warn "Dashboard already running (PID: $(get_pid $DASH_PID))"
    else
        cd "$BATCH_DIR"
        nohup python -u dashboard_server.py >> "$DASH_LOG" 2>&1 &
        echo $! > "$DASH_PID"
        sleep 2
        if is_running "$DASH_PID"; then
            ok "Dashboard started  (PID: $(get_pid $DASH_PID))"
            ok "URL: http://$(hostname -I | awk '{print $1}'):8012"
        else
            err "Dashboard failed to start — check: $DASH_LOG"
            exit 1
        fi
    fi

    echo ""
    log "All services started."
    echo ""
    status_summary
}

# =============================================================
# STOP
# =============================================================
stop_service() {
    local label="$1" pid_file="$2"
    if is_running "$pid_file"; then
        local pid; pid=$(cat "$pid_file")
        kill "$pid" 2>/dev/null; sleep 2
        kill -0 "$pid" 2>/dev/null && { kill -9 "$pid" 2>/dev/null; warn "$label force-killed (PID: $pid)"; } \
                                    || ok "$label stopped (PID: $pid)"
        rm -f "$pid_file"
    else
        warn "$label was not running"
    fi
}

stop() {
    echo ""
    log "Stopping all services..."
    echo ""
    stop_service "Web server"      "$WEB_PID"
    stop_service "Batch processor" "$BATCH_PID"
    stop_service "Dashboard"       "$DASH_PID"
    echo ""
    log "All services stopped."
    echo ""
}

restart() { stop; sleep 2; start; }

# =============================================================
# STATUS
# =============================================================
status_summary() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  global_ai_agent — Service Status${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

    _svc() {
        local label="$1" pid_file="$2" url="$3"
        if is_running "$pid_file"; then
            echo -e "  $label : ${GREEN}RUNNING${NC}  (PID: $(get_pid $pid_file))"
            [ -n "$url" ] && echo -e "  URL            : ${CYAN}$url${NC}"
        else
            echo -e "  $label : ${RED}STOPPED${NC}"
        fi
    }

    _svc "Web Server      " "$WEB_PID"   "http://$(hostname -I | awk '{print $1}'):8010"
    _svc "Batch Processor " "$BATCH_PID" ""
    _svc "Dashboard       " "$DASH_PID"  "http://$(hostname -I | awk '{print $1}'):8012"

    echo ""
    echo -e "  ${BLUE}Batch Input Folders — Pending Files:${NC}"

    # Standard apps
    for folder in telecom_digital skyc p2p esim ecrm; do
        p="$BATCH_DIR/input/$folder"
        [ -d "$p" ] && count=$(ls "$p"/*.csv 2>/dev/null | wc -l) || count=0
        echo -e "    $folder  →  ${YELLOW}$count CSV${NC}"
    done

    # SCRM zones
    for z in 1 2 3 4; do
        p="$BATCH_DIR/input/scrm/zone_${z}"
        [ -d "$p" ] && count=$(ls "$p"/*.csv 2>/dev/null | wc -l) || count=0
        echo -e "    scrm/zone_${z}  →  ${YELLOW}$count CSV${NC}"
    done

    echo ""
    today=$(date '+%Y%m%d')
    echo -e "  ${BLUE}Processed Today:${NC}"
    for folder in telecom_digital skyc p2p esim ecrm; do
        p="$BATCH_DIR/processed/$folder"
        [ -d "$p" ] && count=$(ls "$p"/*_${today}*.csv 2>/dev/null | wc -l) || count=0
        echo -e "    $folder  →  ${GREEN}$count${NC}"
    done
    for z in 1 2 3 4; do
        p="$BATCH_DIR/processed/scrm/zone_${z}"
        [ -d "$p" ] && count=$(ls "$p"/*_${today}*.csv 2>/dev/null | wc -l) || count=0
        echo -e "    scrm/zone_${z}  →  ${GREEN}$count${NC}"
    done

    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

status() { echo ""; status_summary; }

# =============================================================
# LOGS
# =============================================================
case "${1:-start}" in
    start)            start ;;
    stop)             stop ;;
    restart)          restart ;;
    status)           status ;;
    logs)             tail -f "$WEB_LOG" ;;
    logs-batch)       tail -f "$BATCH_LOG" ;;
    logs-dashboard)   tail -f "$DASH_LOG" ;;
    *)
        echo ""
        echo -e "${CYAN}Usage:${NC} ./start.sh [command]"
        echo ""
        echo "  start           — Start web server + batch + dashboard"
        echo "  stop            — Stop all services"
        echo "  restart         — Restart all services"
        echo "  status          — Show service status + folder counts"
        echo "  logs            — Tail web server log"
        echo "  logs-batch      — Tail batch processor log"
        echo "  logs-dashboard  — Tail dashboard log"
        echo ""
        exit 1
        ;;
esac
