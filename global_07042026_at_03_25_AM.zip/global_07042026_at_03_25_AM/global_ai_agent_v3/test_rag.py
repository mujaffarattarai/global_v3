# =============================================================
# test_rag.py
# Quick test to verify LlamaIndex RAG is working correctly.
#
# Usage:
#   python test_rag.py                          # tests all apps
#   python test_rag.py TELECOM_DIGITAL UNBLOCK  # tests one scenario
#   python test_rag.py TELECOM_DIGITAL UNBLOCK "customer wants unblock"
# =============================================================

import sys
import os
import logging

logging.basicConfig(
    level  = logging.INFO,
    format = "%(asctime)s - %(levelname)s - %(message)s"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from app_registry import get_app_config, _load_registry
from config_utils import load_properties
from rag_engine   import RAGEngine

# =============================================================
# DEFAULT TEST QUERIES per scenario
# These are typical ticket texts that should match SOP chunks
# =============================================================
DEFAULT_QUERIES = {
    "UNBLOCK":        "customer requesting unblock of number, sim is blocked",
    "FRC":            "first recharge not done, activation pending",
    "REFUND":         "refund not received, payment deducted but not credited",
    "CAF_SUBMISSION": "CAF not submitted, KYC verification pending",
    "SCRM_UNBLOCK":   "number blocked, customer requesting release",
    "ZONE_1":         "number blocked, customer requesting release",
    "ZONE_2":         "number blocked, customer requesting release",
    "ZONE_3":         "number blocked, customer requesting release",
    "ZONE_4":         "number blocked, customer requesting release",
}


def test_scenario(app_key, scenario_key, query=None):
    print(f"\n{'='*60}")
    print(f"  APP: {app_key}  |  SCENARIO: {scenario_key}")
    print(f"{'='*60}")

    try:
        cfg      = get_app_config(app_key, scenario_key)
        db_props = load_properties(cfg["db_config_path"])

        embed_url   = db_props.get("embedding.url")
        embed_model = db_props.get("embedding.model", "nomic-embed-text:v1.5")
        sop_file    = cfg["sop_file"]
        vector_file = cfg["vector_file"]

        print(f"  SOP file    : {sop_file}")
        print(f"  Vector file : {vector_file}")
        print(f"  Embed URL   : {embed_url}")
        print(f"  Embed model : {embed_model}")

        # Check index folder exists
        from rag_engine import _index_dir_from_vector_file
        index_dir = _index_dir_from_vector_file(vector_file)
        exists = os.path.exists(index_dir) and os.listdir(index_dir)
        print(f"  Index dir   : {index_dir}")
        print(f"  Index exists: {'✔ YES' if exists else '✘ NO — run global_indexer.py first'}")

        if not exists:
            print(f"  ✘ SKIPPED — no index found")
            return

        # Build RAG engine
        engine = RAGEngine(
            sop_file    = sop_file,
            embed_url   = embed_url,
            embed_model = embed_model,
            vector_file = vector_file,
        )

        # Use provided query or default
        test_query = query or DEFAULT_QUERIES.get(scenario_key, "customer issue")
        print(f"\n  Query: \"{test_query}\"")
        print(f"  Searching...")

        results = engine.search(
            query           = test_query,
            top_k           = 3,
            score_threshold = 0.0,  # show all results regardless of score
        )

        if not results:
            print(f"  ✘ No results returned")
        else:
            print(f"  ✔ {len(results)} result(s) found:\n")
            for i, (score, text, chunk_id, section) in enumerate(results, 1):
                print(f"  [{i}] Score: {round(score, 4)}")
                print(f"       Chunk: {chunk_id}")
                print(f"       Text preview: {text[:150].replace(chr(10), ' ')}...")
                print()

    except Exception as e:
        print(f"  ✘ ERROR: {e}")
        import traceback
        traceback.print_exc()


def test_all():
    registry = _load_registry()
    seen = set()

    for app_key, app_data in registry.items():
        for scenario_key in app_data.get("scenarios", {}).keys():
            try:
                cfg      = get_app_config(app_key, scenario_key)
                sop_file = cfg["sop_file"]
                if sop_file in seen:
                    continue
                seen.add(sop_file)
                test_scenario(app_key, scenario_key)
            except Exception as e:
                print(f"  ✘ ERROR {app_key}/{scenario_key}: {e}")


if __name__ == "__main__":
    args = sys.argv[1:]

    if len(args) == 0:
        print("Testing ALL apps and scenarios...")
        test_all()

    elif len(args) == 2:
        app_key, scenario_key = args[0].upper(), args[1].upper()
        test_scenario(app_key, scenario_key)

    elif len(args) >= 3:
        app_key, scenario_key = args[0].upper(), args[1].upper()
        query = " ".join(args[2:])
        test_scenario(app_key, scenario_key, query)

    else:
        print("Usage:")
        print("  python test_rag.py                              # test all")
        print("  python test_rag.py TELECOM_DIGITAL UNBLOCK      # test one")
        print("  python test_rag.py TELECOM_DIGITAL UNBLOCK 'your query here'")

    print(f"\n{'='*60}")
    print("  RAG test complete.")
    print(f"{'='*60}\n")

