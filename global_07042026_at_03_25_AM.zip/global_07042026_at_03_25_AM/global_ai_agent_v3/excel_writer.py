# =============================================================
# excel_writer.py
# Writes the final styled Excel output file.
#
# Imported by csv_processor.py
# =============================================================

import os
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


def write_styled_excel(df, output_file):
    """
    Writes a DataFrame to a styled .xlsx file.
    Red header row, borders on all cells, wrapped text.
    """
    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Report")
        ws = writer.sheets["Report"]

        header_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)
        wrap_align  = Alignment(wrap_text=True, vertical="top")
        thin_border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"),  bottom=Side(style="thin"),
        )

        for cell in ws[1]:
            cell.fill   = header_fill
            cell.font   = header_font
            cell.border = thin_border
            ws.column_dimensions[cell.column_letter].width = 35

        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = wrap_align
                cell.border    = thin_border
