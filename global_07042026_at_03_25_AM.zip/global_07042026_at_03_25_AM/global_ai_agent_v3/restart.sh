sh start.sh restart
