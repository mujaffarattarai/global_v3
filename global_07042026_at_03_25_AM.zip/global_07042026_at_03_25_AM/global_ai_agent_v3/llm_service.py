# =============================================================
# llm_service.py
# All LLM interaction logic.
#
# v3 change: 1 LLM call per ticket (was 2 in v2).
# Single prompt returns structured JSON + narrative together.
# Cuts LLM processing time per ticket roughly in half.
#
# Imported by csv_processor.py
# =============================================================

import re
import json
import logging
import requests

logger = logging.getLogger(__name__)


def generate_llm_response(summary, db_result, rule_output, rag_chunks,
                           llm_url, llm_model, llm_enabled,
                           db_parsed=None, emit=None):
    """
    Single LLM call that returns BOTH structured decision AND narrative.

    v2 made 2 separate HTTP calls (structured JSON + narrative).
    v3 combines them into 1 call — same output, half the wait time.

    Returns: (ai_result dict, narrative string, raw_llm string)
      ai_result = {"root_cause": ..., "status": ..., "action": ...}
      narrative = full human-readable resolution text
      raw_llm   = raw string from LLM (for debug column)
    """
    if not llm_enabled:
        return None, "", None

    if db_parsed is None:
        db_parsed = {}

    all_matched = rule_output.get("all_matched_details", [])
    matched_rules_text = "\n".join(
        f"  - [{r['rule_id']}] {r['description']}\n    Condition: {r['condition']}"
        for r in all_matched
    ) if all_matched else "  None"

    prompt = f"""You are a telecom support AI assistant.
You must return a response in two clearly separated parts.

PART 1 — DECISION (valid JSON only, no markdown):
{{
  "root_cause": "one sentence",
  "status": "one word or short phrase",
  "action": "one sentence recommended action"
}}

PART 2 — NARRATIVE (plain text, no JSON, no bullet points):
Write a resolution note starting with "Dear User," and ending with exactly:
"To know the latest status of any Order/Transaction/Refund/FRC/Unblock Please Use Neo Assist(https://neogold.myvi.in/cms/login). User access for Neo Assist can be created by raising a ticket to IT Service Desk (itsd.support@vodafoneidea.com). As this ticket does not require any action, hence we are cancelling this ticket."

RULES:
- Follow the Primary Rule as the FINAL authority
- Do NOT contradict the Primary Rule
- Base root cause on DATABASE RESULT only
- Base narrative on PRIMARY RULE decision only

TICKET SUMMARY:
{summary}

DATABASE RESULT:
{db_result}

KEY DB FACTS:
- MSISDN        : {db_parsed.get("MSISDN") or db_parsed.get("SELECTED_NUMBER") or "—"}
- ACCOUNT_STATUS: {db_parsed.get("ACCOUNT_STATUS") or db_parsed.get("ORDER_STATUS") or "—"}
- IS_UNBLOCKED  : {db_parsed.get("IS_UNBLOCKED") or "—"}
- BLOCK_REASON  : {db_parsed.get("BLOCK_REASON") or "—"}
- ZONE          : {db_parsed.get("ZONE") or "—"}
- OPS_COMMENTS  : {db_parsed.get("OPS_COMMENTS") or "—"}

ALL MATCHED RULES:
{matched_rules_text}

PRIMARY RULE: [{rule_output.get("rule_id")}] {rule_output.get("decision")}
CONDITION: {rule_output.get("reference")}

RAG CONTEXT:
{chr(10).join(rag_chunks) if rag_chunks else "N/A"}
"""

    if emit:
        emit({"type": "prompt_start", "label": "LLM Combined Prompt (1 call)"})
        for line in prompt.strip().splitlines():
            emit({"type": "prompt_line", "line": line})
        emit({"type": "prompt_end"})

    try:
        response = requests.post(
            llm_url,
            json={"model": llm_model, "prompt": prompt, "stream": False},
            timeout=120,
        )
        response.raise_for_status()
        raw = response.json().get("response", "").strip()

        if emit:
            emit({"type": "llm_response", "msg": raw[:200]})

        # ── Parse PART 1: JSON decision ───────────────────────
        ai_result = None
        json_match = re.search(r'\{[^{}]+\}', raw, re.DOTALL)
        if json_match:
            try:
                clean = re.sub(r"```(?:json)?|```", "", json_match.group()).strip()
                ai_result = json.loads(clean)
            except Exception:
                pass

        # ── Parse PART 2: Narrative ───────────────────────────
        narrative = ""
        if "Dear User," in raw:
            narrative = raw[raw.index("Dear User,"):].strip()
            if emit:
                emit({"type": "narrative_response", "msg": narrative[:200]})

        return ai_result, narrative, raw

    except Exception as e:
        logger.error(f"LLM Error: {e}")
        return None, "", None
