SELECT
  CASE
    WHEN caf.IS_UNBLOCKED = 'Y' THEN
         'Already Unblocked' || CHR(10) ||
         'LEAD_ID: ' || caf.LEAD_ID || CHR(10) ||
         'ORDER_CODE: ' || caf.ORDER_CODE || CHR(10) ||
         'SELECTED_NUMBER: ' || caf.SELECTED_NUMBER || CHR(10) ||
         'JOURNEY_TYPE: ' || caf.JOURNEY_TYPE || CHR(10) ||
         'LEAD_UPDATION_DATE: ' || caf.LEAD_UPDATION_DATE || CHR(10) ||
         'SEGMENT: ' || caf.SEGMENT || CHR(10) ||
         'PREMIUM_NUMBER_FEE: ' || caf.PREMIUM_NUMBER_FEE || CHR(10) ||
         'UNBLOCK_RESPONSE: ' || caf.UNBLOCK_RESPONSE || CHR(10) ||
         'OPS_COMMENTS: ' || caf.OPS_COMMENTS || CHR(10) ||
         'IS_UNBLOCKED: ' || caf.IS_UNBLOCKED || CHR(10) ||
         'Order Modified Date Is: ' || caf.ORDER_MODIFIED_DATE || CHR(10) ||
         'Lead Creation Date Is: ' || caf.LEAD_CREATION_DATE || CHR(10) ||
         'Order Status Is: ' || caf.ORDER_STATUS || CHR(10) ||
         'Payment Amount: ' || pay.AMOUNT || CHR(10) ||
         'Payment Response Code: ' || pay.RESPONSE_CODE || CHR(10) ||
         'FRC Call Time: ' || frc.FRC_CALL_TIME || CHR(10) ||
         'FRC Callback Status: ' || frc.FRC_CALLBACK_STATUS || CHR(10) ||
         'FRC Call Message: ' || frc.FRC_CALL_MESSAGE || CHR(10) ||
         'Refund Call Time: ' || refund.REFUND_CALL_TIME || CHR(10) ||
         'Refund Amount: ' || refund.AMOUNT || CHR(10) ||
         'Refund Response Code: ' || refund.REFUND_RESPONSE_CODE || CHR(10) ||
         'Refund Call Message: ' || refund.REFUND_CALL_MESSAGE
    ELSE
         'NOT Unblocked' || CHR(10) ||
         'LEAD_ID: ' || caf.LEAD_ID || CHR(10) ||
         'ORDER_CODE: ' || caf.ORDER_CODE || CHR(10) ||
         'SELECTED_NUMBER: ' || caf.SELECTED_NUMBER || CHR(10) ||
         'JOURNEY_TYPE: ' || caf.JOURNEY_TYPE || CHR(10) ||
         'LEAD_UPDATION_DATE: ' || caf.LEAD_UPDATION_DATE || CHR(10) ||
         'SEGMENT: ' || caf.SEGMENT || CHR(10) ||
         'PREMIUM_NUMBER_FEE: ' || caf.PREMIUM_NUMBER_FEE || CHR(10) ||
         'UNBLOCK_RESPONSE: ' || caf.UNBLOCK_RESPONSE || CHR(10) ||
         'OPS_COMMENTS: ' || caf.OPS_COMMENTS || CHR(10) ||
         'IS_UNBLOCKED: ' || caf.IS_UNBLOCKED || CHR(10) ||
         'Order Modified Date Is: ' || caf.ORDER_MODIFIED_DATE || CHR(10) ||
         'Lead Creation Date Is: ' || caf.LEAD_CREATION_DATE || CHR(10) ||
         'ORDER_STATUS: ' || caf.ORDER_STATUS || CHR(10) ||
         'Payment Amount: ' || pay.AMOUNT || CHR(10) ||
         'Payment Response Code: ' || pay.RESPONSE_CODE || CHR(10) ||
         'FRC Call Time: ' || frc.FRC_CALL_TIME || CHR(10) ||
         'FRC Callback Status: ' || frc.FRC_CALLBACK_STATUS || CHR(10) ||
         'FRC Call Message: ' || frc.FRC_CALL_MESSAGE || CHR(10) ||
         'Refund Call Time: ' || refund.REFUND_CALL_TIME || CHR(10) ||
         'Refund Amount: ' || refund.AMOUNT || CHR(10) ||
         'Refund Response Code: ' || refund.REFUND_RESPONSE_CODE || CHR(10) ||
         'Refund Call Message: ' || refund.REFUND_CALL_MESSAGE || CHR(10) ||
         '======================================='
  END AS msg
FROM idea_neo_caf caf
LEFT JOIN idea_neo_payment pay ON caf.LEAD_ID = pay.LEAD_ID
LEFT JOIN idea_neo_frc frc ON frc.ORDER_CODE = pay.ORDER_CODE
LEFT JOIN idea_neo_payment_refund refund ON refund.ORDER_CODE = pay.ORDER_CODE
WHERE caf.SELECTED_NUMBER = :1
ORDER BY caf.LEAD_CREATION_DATE DESC
FETCH FIRST 1 ROW ONLY