# =============================================================
# rag_engine.py
# RAG search using LlamaIndex with persistent storage.
#
# Storage strategy:
#   - Chunks stored in vectors/<name>_index/ folder on disk
#   - Built once, loaded instantly on every subsequent run
#   - Auto-rebuilds if index folder is missing or deleted
#   - SOP edited in Admin? Delete the _index folder → auto-rebuilds
#
# vector_file from apps_registry.yaml:
#   vectors/telecom_unblock.json  →  stored as  vectors/telecom_unblock_index/
#   apps/ecrm/rag_vectors_unblock.json  →  stored as  apps/ecrm/rag_vectors_unblock_index/
#
# Install:
#   pip install llama-index llama-index-embeddings-ollama
# =============================================================

import os
import logging

logger = logging.getLogger(__name__)


def _index_dir_from_vector_file(vector_file):
    """
    Derive the LlamaIndex persist directory from the vector_file path.
    Simply replaces .json with _index/

    Example:
      vectors/telecom_unblock.json  →  vectors/telecom_unblock_index
      apps/ecrm/rag_vectors_unblock.json  →  apps/ecrm/rag_vectors_unblock_index
    """
    base = vector_file.replace(".json", "")
    return base + "_index"


class RAGEngine:

    def __init__(self, sop_file, embed_url, embed_model, vector_file=None):
        """
        sop_file    : path to the .txt SOP file
        embed_url   : Ollama embedding URL e.g. http://10.94.92.10:11434/api/embeddings
        embed_model : embedding model e.g. nomic-embed-text:v1.5
        vector_file : path from apps_registry.yaml (used to derive storage folder)
                      If None, storage folder is derived from sop_file path.
        """
        self.sop_file    = sop_file
        self.embed_url   = embed_url
        self.embed_model = embed_model
        self._index      = None

        # Derive persist directory
        if vector_file:
            self.persist_dir = _index_dir_from_vector_file(vector_file)
        else:
            # Fallback: store next to the sop file
            base = os.path.splitext(sop_file)[0]
            self.persist_dir = base + "_index"

    def _get_embed_model(self):
        """Build OllamaEmbedding — strips /api/embeddings from URL if present."""
        from llama_index.embeddings.ollama import OllamaEmbedding

        base_url = self.embed_url
        for suffix in ["/api/embeddings", "/api/embed", "/api/generate"]:
            base_url = base_url.replace(suffix, "")
        base_url = base_url.rstrip("/")

        return OllamaEmbedding(
            model_name = self.embed_model,
            base_url   = base_url,
        )

    def _build_and_persist(self):
        """
        Build LlamaIndex from SOP file and save to disk.
        Called only when index folder does not exist.
        """
        from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, StorageContext

        logger.info(f"Building RAG index from: {self.sop_file}")
        logger.info(f"Will persist to: {self.persist_dir}")

        embed_model = self._get_embed_model()

        documents = SimpleDirectoryReader(
            input_files=[self.sop_file]
        ).load_data()

        os.makedirs(self.persist_dir, exist_ok=True)

        storage_context = StorageContext.from_defaults()

        self._index = VectorStoreIndex.from_documents(
            documents,
            embed_model     = embed_model,
            storage_context = storage_context,
            show_progress   = False,
        )

        # Persist to disk
        self._index.storage_context.persist(persist_dir=self.persist_dir)
        logger.info(f"RAG index built and saved: {self.persist_dir}")

    def _load_from_disk(self):
        """
        Load existing index from disk — fast, no embedding calls needed.
        """
        from llama_index.core import StorageContext, load_index_from_storage

        logger.info(f"Loading RAG index from disk: {self.persist_dir}")

        embed_model = self._get_embed_model()

        storage_context = StorageContext.from_defaults(
            persist_dir=self.persist_dir
        )
        self._index = load_index_from_storage(
            storage_context,
            embed_model=embed_model,
        )
        logger.info(f"RAG index loaded: {self.persist_dir}")

    def _ensure_index(self):
        """
        Load from disk if available, otherwise build and persist.
        Only runs once per RAGEngine instance (cached in self._index).
        """
        if self._index is not None:
            return

        if os.path.exists(self.persist_dir) and os.listdir(self.persist_dir):
            # Index already on disk — load it
            try:
                self._load_from_disk()
                return
            except Exception as e:
                logger.warning(f"Failed to load index from disk: {e} — rebuilding")

        # Build fresh and persist
        self._build_and_persist()

    def search(self, query, top_k=1, scenario=None, score_threshold=0.60):
        """
        Search the SOP for context relevant to the query.

        Returns list of (score, text, chunk_id, section) tuples.
        Returns empty list if nothing found above threshold.

        Parameters:
          query          : ticket text to search against
          top_k          : number of top results to return
          scenario       : ignored (LlamaIndex handles internally)
          score_threshold: minimum similarity score to include result
        """
        try:
            from llama_index.core import Settings
            from llama_index.core.llms import MockLLM

            self._ensure_index()

            # Use retriever only — no LLM needed for chunk retrieval
            # This avoids requiring OpenAI or any LLM package
            retriever = self._index.as_retriever(
                similarity_top_k = max(top_k, 3),
            )
            nodes = retriever.retrieve(query)

            results = []
            for i, node in enumerate(nodes):
                score = float(node.score) if node.score is not None else 0.0
                if score < score_threshold:
                    continue
                results.append((
                    score,
                    node.node.text,
                    f"CHUNK_{i+1}",
                    "SOP_SECTION",
                ))

            # Sort by score descending, return top_k
            results.sort(key=lambda x: x[0], reverse=True)
            return results[:top_k]

        except Exception as e:
            logger.error(f"RAG search error: {e}")
            return []

    def rebuild(self):
        """
        Force rebuild the index from scratch.
        Call this after SOP file is updated via Admin panel.
        """
        import shutil
        if os.path.exists(self.persist_dir):
            shutil.rmtree(self.persist_dir)
            logger.info(f"Deleted old index: {self.persist_dir}")
        self._index = None
        self._build_and_persist()
        logger.info(f"Index rebuilt: {self.persist_dir}")

