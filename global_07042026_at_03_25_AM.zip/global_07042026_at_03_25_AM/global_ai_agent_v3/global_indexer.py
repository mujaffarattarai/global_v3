# =============================================================
# global_indexer.py
# Builds LlamaIndex RAG indexes for any/all apps.
#
# Usage:
#   python global_indexer.py                         # index all
#   python global_indexer.py TELECOM_DIGITAL         # one app
#   python global_indexer.py TELECOM_DIGITAL UNBLOCK # one scenario
#
# What it does:
#   Reads SOP .txt file → builds LlamaIndex → saves to vectors/<name>_index/
#
# When to run:
#   - First time setup
#   - After editing a SOP file manually (not via Admin panel)
#   - Admin panel edit auto-rebuilds via RAGEngine.rebuild()
# =============================================================

import sys
import os

from app_registry import _load_registry, get_app_config
from config_utils import load_properties
from rag_engine   import RAGEngine


def index_scenario(app_key, scenario_key):
    """Build and persist LlamaIndex for one app/scenario."""
    cfg      = get_app_config(app_key, scenario_key)
    db_props = load_properties(cfg["db_config_path"])

    embed_url   = db_props.get("embedding.url")
    embed_model = db_props.get("embedding.model", "nomic-embed-text:v1.5")
    sop_file    = cfg["sop_file"]
    vector_file = cfg["vector_file"]

    if not embed_url:
        print(f"  ✘ No embedding.url in properties — skipping {app_key}/{scenario_key}")
        return

    if not os.path.exists(sop_file):
        print(f"  ✘ SOP file not found: {sop_file} — skipping")
        return

    print(f"  Indexing: {sop_file}")

    engine = RAGEngine(
        sop_file    = sop_file,
        embed_url   = embed_url,
        embed_model = embed_model,
        vector_file = vector_file,
    )

    # Force rebuild even if index already exists
    engine.rebuild()
    print(f"  ✔ Done → {engine.persist_dir}")


def index_all():
    registry = _load_registry()
    seen = set()  # skip duplicate sop_file (e.g. SCRM zones share same SOP)

    for app_key, app_data in registry.items():
        print(f"\n[APP] {app_key}")
        for scenario_key in app_data.get("scenarios", {}).keys():
            print(f"  [SCENARIO] {scenario_key}")
            try:
                cfg      = get_app_config(app_key, scenario_key)
                sop_file = cfg["sop_file"]

                # Skip duplicate SOPs (SCRM ZONE_1..4 all share same SOP)
                if sop_file in seen:
                    print(f"  → Skipped (same SOP already indexed)")
                    continue
                seen.add(sop_file)

                index_scenario(app_key, scenario_key)

            except Exception as e:
                print(f"  ✘ ERROR: {e}")


if __name__ == "__main__":
    args = sys.argv[1:]

    if len(args) == 0:
        print("Indexing ALL apps and scenarios...")
        index_all()

    elif len(args) == 1:
        app_key = args[0].upper()
        print(f"Indexing all scenarios for app: {app_key}")
        registry = _load_registry()
        seen = set()
        for scenario_key in registry.get(app_key, {}).get("scenarios", {}).keys():
            try:
                cfg = get_app_config(app_key, scenario_key)
                if cfg["sop_file"] in seen:
                    print(f"  → Skipped duplicate SOP for {scenario_key}")
                    continue
                seen.add(cfg["sop_file"])
                index_scenario(app_key, scenario_key)
            except Exception as e:
                print(f"  ✘ ERROR {scenario_key}: {e}")

    elif len(args) == 2:
        app_key, scenario_key = args[0].upper(), args[1].upper()
        print(f"Indexing {app_key} / {scenario_key}")
        index_scenario(app_key, scenario_key)

    else:
        print("Usage: python global_indexer.py [APP_KEY] [SCENARIO_KEY]")
