# Global AI Agent — Unified

Multi-application, multi-zone, AI-powered ticket processor.
Single project — web server, batch daemon, and dashboard all in one.

---

## Project Structure

```
global_ai_agent/
│
├── start.sh                    ← Single start/stop/status script
├── apps_registry.yaml          ← Master config — all apps, all zones
│
├── apps/                       ← DB configs per app
│   ├── telecom_digital.properties
│   ├── skyc_app.properties
│   ├── p2p.properties
│   ├── esim.properties
│   ├── ecrm.properties
│   └── scrm/                   ← SCRM: one file per zone
│       ├── scrm_zone1.properties
│       ├── scrm_zone2.properties
│       ├── scrm_zone3.properties
│       └── scrm_zone4.properties
│
├── queries/                    ← SQL files (shared per app/scenario)
├── sops/                       ← SOP documents (shared per scenario)
├── vectors/                    ← Auto-generated RAG vectors
├── rules/                      ← Rules engines per app
│   ├── telecom_rules.py
│   ├── skyc_rules.py
│   └── scrm_rules.py           ← Shared by all 4 SCRM zones
│
├── global_csv_processor.py     ← Unified processor (web + batch)
├── global_app_server.py        ← Web server  (port 8008)
├── app_registry.py             ← Registry loader (multi-zone aware)
├── rag_engine.py               ← RAG / cosine similarity
├── config_utils.py             ← .properties file loader
├── global_indexer.py           ← SOP → RAG vector builder
│
└── batch/                      ← Batch daemon lives here
    ├── batch_processor.py      ← Watchdog daemon
    ├── dashboard_server.py     ← Dashboard (port 8009)
    ├── stats_db.py             ← SQLite stats tracking
    ├── admin_engine.py         ← Admin panel backend
    │
    ├── input/                  ← Drop CSV files here
    │   ├── telecom_digital/
    │   ├── skyc/
    │   ├── p2p/
    │   ├── esim/
    │   ├── ecrm/
    │   └── scrm/
    │       ├── zone_1/         ← SCRM Zone 1 DB
    │       ├── zone_2/         ← SCRM Zone 2 DB
    │       ├── zone_3/         ← SCRM Zone 3 DB
    │       └── zone_4/         ← SCRM Zone 4 DB
    │
    ├── output/                 ← AI-enriched Excel files appear here
    ├── processed/              ← Archived CSVs (with timestamp)
    ├── failed/                 ← Failed CSVs + error logs
    └── db/
        └── batch_stats.db      ← SQLite processing history
```

---

## Setup

```bash
cd /home/postgres/global_ai_agent
python -m venv venv
source venv/bin/activate
pip install pandas openpyxl oracledb requests pyyaml watchdog flask
```

---

## Start / Stop

```bash
./start.sh start      # Start all 3 services
./start.sh stop       # Stop all
./start.sh restart    # Restart all
./start.sh status     # Show status + pending file counts
./start.sh logs              # Tail web server log
./start.sh logs-batch        # Tail batch processor log
./start.sh logs-dashboard    # Tail dashboard log
```

---

## SCRM — 4 Zone Setup

SCRM uses **4 separate Oracle databases**, one per zone.
All zones share the **same SQL, SOP, rules, and RAG vectors**.

### Configure zone DB credentials

Edit each zone's properties file:

```
apps/scrm/scrm_zone1.properties  ← Zone 1 DB
apps/scrm/scrm_zone2.properties  ← Zone 2 DB
apps/scrm/scrm_zone3.properties  ← Zone 3 DB
apps/scrm/scrm_zone4.properties  ← Zone 4 DB
```

Each file contains:
```
db.user=SCRM_ZONE1_USER
db.password=yourpassword
db.dsn=10.x.x.x:1521/scrmzone1
llm.enabled=true
llm.model=llama3.2:3b
llm.url=http://10.94.92.10:11434/api/generate
embedding.model=nomic-embed-text:v1.5
embedding.url=http://10.94.92.10:11434/api/embeddings
```

### Index SCRM SOPs (run once or after SOP changes)

```bash
python global_indexer.py SCRM ZONE_1   # indexes all zones (same SOP/vectors)
```

Since all zones share the same `sop_file` and `vector_file`, indexing any zone
builds the shared vector file used by all zones.

### Web mode

- Open http://server:8008
- Select **App: SCRM**
- Select **Scenario: Zone 1 / Zone 2 / Zone 3 / Zone 4**
- Upload CSV → Download AI-enriched Excel

### Batch mode

Drop CSV files into the correct zone folder:

```
batch/input/scrm/zone_1/myfile.csv   → processed against Zone 1 DB
batch/input/scrm/zone_2/myfile.csv   → processed against Zone 2 DB
batch/input/scrm/zone_3/myfile.csv   → processed against Zone 3 DB
batch/input/scrm/zone_4/myfile.csv   → processed against Zone 4 DB
```

Output Excel appears in the matching output folder:
```
batch/output/scrm/zone_1/myfile.xlsx
```

---

## Adding a New App

### Step 1 — Add to apps_registry.yaml

```yaml
NEW_APP:
  display_name: "New App"
  db_config: apps/new_app.properties
  scenarios:
    SCENARIO_A:
      display_name: "Scenario A"
      query_file: queries/new_app_scenario_a.sql
      sop_file: sops/new_app_scenario_a.txt
      vector_file: vectors/new_app_scenario_a.json
      rules_module: rules.new_app_rules
      rules_scenario: SCENARIO_A
```

### Step 2 — Create DB config

```
apps/new_app.properties
```

### Step 3 — Create SQL, SOP, rules files

### Step 4 — Index SOPs

```bash
python global_indexer.py NEW_APP
```

### Step 5 — Restart

```bash
./start.sh restart
```

### Step 6 — Batch folders (auto-created on daemon start)

```
batch/input/new_app/
```

---

## AI Output Columns

| Column | Description |
|---|---|
| AI_Scenario_Detected | Scenario matched from ticket content (batch only) |
| AI_Primary_Rule | Matched rule ID |
| AI_RAG_Context | Relevant SOP text (when no rule matched) |
| AI_RAG_Score | Cosine similarity score |
| AI_Root_Cause | LLM root cause |
| AI_Status | LLM status |
| AI_Action | LLM recommended action |
| AI_Narrative_Response | Human-readable resolution paragraph |
| AI_Confidence | Score 0–100 |
| AI_Skip_Reason | Why row was skipped (if applicable) |
