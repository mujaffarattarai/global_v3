# =============================================================
# rules/skyc_rules.py
# Rules for SKYC app — CAF Submission scenario.
#
# v3 changes:
#   - Rule class and val() imported from base_rules (no copy-paste)
#   - Lambda conditions replaced with named functions
#   - Unused 'scenario' field removed
#   - Duplicate 'condition' key removed from evaluate_rules() output
# =============================================================

from typing import Dict, Any
from rules.base_rules import Rule, val


# =============================================================
# CAF SUBMISSION — Named condition functions
# =============================================================

def is_caf_submitted_and_verified(r):
    return (
        val(r, "CAF_STATUS") == "SUBMITTED"
        and val(r, "VERIFICATION_STATUS") == "VERIFIED"
    )


def is_caf_submitted_pending_verification(r):
    return (
        val(r, "CAF_STATUS") == "SUBMITTED"
        and val(r, "VERIFICATION_STATUS") == "PENDING"
    )


def is_caf_rejected_document_mismatch(r):
    rejection_reason = str(r.get("REJECTION_REASON", "") or "").upper()
    return (
        val(r, "CAF_STATUS") == "REJECTED"
        or val(r, "VERIFICATION_STATUS") == "REJECTED"
    ) and "DOCUMENT_MISMATCH" in rejection_reason


def is_caf_rejected_kyc_failed(r):
    rejection_reason = str(r.get("REJECTION_REASON", "") or "").upper()
    return (
        val(r, "KYC_STATUS") == "FAILED"
        or "KYC_FAILED" in rejection_reason
    )


def is_caf_rejected_resubmission_required(r):
    return (
        val(r, "CAF_STATUS") == "REJECTED"
        or val(r, "VERIFICATION_STATUS") == "REJECTED"
    )


def is_caf_not_submitted(r):
    status = val(r, "CAF_STATUS")
    return status in ["DRAFT", None, ""]


def is_caf_in_progress(r):
    return val(r, "CAF_STATUS") == "IN_PROGRESS"


def is_caf_duplicate(r):
    return val(r, "CAF_STATUS") == "DUPLICATE"


def is_caf_expired(r):
    return val(r, "CAF_STATUS") == "EXPIRED"


def is_caf_on_hold(r):
    return val(r, "CAF_STATUS") == "ON_HOLD"


# =============================================================
# CAF SUBMISSION RULES
# =============================================================
CAF_RULES = [

    Rule("CAF_01", "CAF Submitted and Verified", 1,
         condition  = is_caf_submitted_and_verified,
         reference  = "CAF_STATUS = SUBMITTED AND VERIFICATION_STATUS = VERIFIED → Successfully submitted and verified, no action required"),

    Rule("CAF_02", "CAF Submitted - Pending Verification", 2,
         condition  = is_caf_submitted_pending_verification,
         reference  = "CAF_STATUS = SUBMITTED AND VERIFICATION_STATUS = PENDING → Verification in progress, wait for TAT completion"),

    Rule("CAF_03", "CAF Rejected - Document Mismatch", 3,
         condition  = is_caf_rejected_document_mismatch,
         reference  = "CAF_STATUS = REJECTED AND REJECTION_REASON contains DOCUMENT_MISMATCH → Agent must collect correct documents and resubmit"),

    Rule("CAF_04", "CAF Rejected - KYC Failed", 4,
         condition  = is_caf_rejected_kyc_failed,
         reference  = "KYC_STATUS = FAILED OR REJECTION_REASON contains KYC_FAILED → Customer must visit store with original documents for re-verification"),

    Rule("CAF_05", "CAF Rejected - Resubmission Required", 5,
         condition  = is_caf_rejected_resubmission_required,
         reference  = "CAF_STATUS = REJECTED → Check rejection reason, resolve issue and resubmit CAF"),

    Rule("CAF_06", "CAF Not Submitted - Action Required", 6,
         condition  = is_caf_not_submitted,
         reference  = "CAF_STATUS = DRAFT or NULL → CAF not yet submitted, agent must complete and submit"),

    Rule("CAF_07", "CAF In Progress - Wait for TAT", 7,
         condition  = is_caf_in_progress,
         reference  = "CAF_STATUS = IN_PROGRESS → Submission processing, wait for system update as per TAT (24-48 hours)"),

    Rule("CAF_08", "CAF Duplicate - No Action Required", 8,
         condition  = is_caf_duplicate,
         reference  = "CAF_STATUS = DUPLICATE → CAF already exists for this order, do not create another submission"),

    Rule("CAF_09", "CAF Expired - New CAF Required", 9,
         condition  = is_caf_expired,
         reference  = "CAF_STATUS = EXPIRED → Submission window expired, agent must initiate a new CAF"),

    Rule("CAF_10", "CAF On Hold - Customer Action Required", 10,
         condition  = is_caf_on_hold,
         reference  = "CAF_STATUS = ON_HOLD → Pending additional information, contact customer for missing details"),
]


# =============================================================
# RULE MAP & EVALUATOR
# =============================================================
RULE_MAP = {
    "CAF_SUBMISSION": CAF_RULES,
}


def evaluate_rules(scenario: str, data: Dict[str, Any]) -> Dict[str, Any]:
    scenario = scenario.upper()
    rules    = RULE_MAP.get(scenario, [])

    matched = sorted(
        [r for r in rules if r.evaluate(data)],
        key=lambda r: r.priority
    )

    if not matched:
        return {
            "primary_rule":        None,
            "rule_id":             None,
            "decision":            "No rule matched — check CAF_STATUS and VERIFICATION_STATUS",
            "matched_rules":       [],
            "reference":           None,
            "all_matched_details": []
        }

    primary = matched[0]
    return {
        "primary_rule":   primary.rule_id,
        "rule_id":        primary.rule_id,
        "decision":       primary.description,
        "reference":      primary.reference,
        "matched_rules":  [r.rule_id for r in matched],
        "all_matched_details": [
            {
                "rule_id":     r.rule_id,
                "description": r.description,
                "condition":   r.reference,
            }
            for r in matched
        ]
    }
