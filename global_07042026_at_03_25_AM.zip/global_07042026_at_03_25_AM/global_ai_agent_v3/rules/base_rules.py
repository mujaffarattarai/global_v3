# =============================================================
# rules/base_rules.py
# Shared base — Rule class and val() helper.
# All rules files import from here. Never copy-paste again.
# =============================================================


class Rule:
    def __init__(self, rule_id, description, priority, condition, reference=""):
        """
        rule_id     : unique ID e.g. "UB_01"
        description : human readable label e.g. "Number Already Unblocked"
        priority    : lower number = higher priority (1 wins over 2)
        condition   : a named function that takes a data dict and returns True/False
        reference   : human readable condition summary for reports
        """
        self.rule_id     = rule_id
        self.description = description
        self.priority    = priority
        self.condition   = condition
        self.reference   = reference

    def evaluate(self, data):
        try:
            return self.condition(data)
        except Exception:
            return False


def val(data, key):
    """
    Safe value extractor.
    Always returns uppercase stripped string for reliable comparisons.
    Returns None if key missing or value is None.
    """
    value = data.get(key)
    if isinstance(value, str):
        return value.strip().upper()
    return value
