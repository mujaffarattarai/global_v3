# =============================================================
# rules/telecom_rules.py
# Rules for Telecom Digital app (UNBLOCK / FRC / REFUND)
#
# v3 changes:
#   - Rule class and val() imported from base_rules (no copy-paste)
#   - Lambda conditions replaced with named functions (readable)
#   - Unused 'scenario' field removed from Rule constructor
#   - UB_05 and UB_06 merged into one rule
#   - Duplicate 'condition' key removed from evaluate_rules() output
# =============================================================

from typing import Dict, Any
from rules.base_rules import Rule, val


# =============================================================
# UNBLOCK — Named condition functions
# Each function name tells you exactly what it checks.
# =============================================================

def is_already_unblocked(r):
    return val(r, "IS_UNBLOCKED") == "Y"


def is_auto_unblocked_expired_tat(r):
    return (
        val(r, "ORDER_STATUS") == "EXPIRED"
        and val(r, "JOURNEY_TYPE") not in ("MNP", "NMNP")
    )


def is_expired_nmnp_not_eligible(r):
    return (
        val(r, "ORDER_STATUS") == "EXPIRED"
        and val(r, "JOURNEY_TYPE") == "NMNP"
    )


def is_eligible_for_manual_unblock(r):
    return (
        val(r, "JOURNEY_TYPE") == "NEW"
        and val(r, "IS_UNBLOCKED") in [None, "N"]
        and val(r, "ORDER_STATUS") not in [
            "EXPIRED", "ORDER_GENERATED", "SIM_ACTIVATED",
            "OUT_FOR_DELIVERY", "APPOINTMENT_CONFIRMED", "REVERT_TO_SUPERVISOR"
        ]
    )


def is_not_eligible_current_status(r):
    return val(r, "ORDER_STATUS") in [
        "SIM_ACTIVATED", "OUT_FOR_DELIVERY", "APPOINTMENT_CONFIRMED",
        "APPOINTMENT_RESCHEDULED", "REVERT_TO_SUPERVISOR", "PROSPECT",
        "B2B_SUCCESS", "ORDER_MIGRATED_OTP_FLOW", "VCON_ORDER_GENERATED"
    ]


# =============================================================
# UNBLOCK RULES
# =============================================================
UNBLOCK_RULES = [

    Rule("UB_01", "Number Already Unblocked", 1,
         condition  = is_already_unblocked,
         reference  = "IS_UNBLOCKED = Y"),

    Rule("UB_02", "Auto Unblocked - Expired as per TAT", 2,
         condition  = is_auto_unblocked_expired_tat,
         reference  = "ORDER_STATUS = EXPIRED AND JOURNEY_TYPE NOT IN (MNP, NMNP) → Auto unblock as per TAT"),

    Rule("UB_03", "Expired NMNP - Not Eligible for Unblocking", 3,
         condition  = is_expired_nmnp_not_eligible,
         reference  = "ORDER_STATUS = EXPIRED AND JOURNEY_TYPE = NMNP → Not eligible, expired MNP cannot be manually unblocked"),

    Rule("UB_04", "Eligible for Manual Unblocking", 4,
         condition  = is_eligible_for_manual_unblock,
         reference  = "JOURNEY_TYPE = NEW AND IS_UNBLOCKED = N AND ORDER_STATUS not in blocked list → Eligible for manual unblock"),

    # UB_05 + UB_06 merged — both said 'Not Eligible', now one rule
    Rule("UB_05", "Not Eligible - Current Transaction Status", 5,
         condition  = is_not_eligible_current_status,
         reference  = "ORDER_STATUS in [SIM_ACTIVATED, OUT_FOR_DELIVERY, APPOINTMENT_CONFIRMED, "
                      "APPOINTMENT_RESCHEDULED, REVERT_TO_SUPERVISOR, PROSPECT, B2B_SUCCESS, "
                      "ORDER_MIGRATED_OTP_FLOW, VCON_ORDER_GENERATED] → Not eligible for unblocking"),
]


# =============================================================
# FRC — Named condition functions
# =============================================================

def is_frc_successful(r):
    return val(r, "FRC_CALLBACK_STATUS") == "SUCCESS"


def is_frc_failed(r):
    return val(r, "FRC_CALLBACK_STATUS") == "FAILED"


# =============================================================
# FRC RULES
# =============================================================
FRC_RULES = [

    Rule("FRC_01", "FRC Successful", 1,
         condition  = is_frc_successful,
         reference  = "FRC_CALLBACK_STATUS = SUCCESS → FRC processed successfully, no action needed"),

    Rule("FRC_02", "FRC Failed - Retry Required", 2,
         condition  = is_frc_failed,
         reference  = "FRC_CALLBACK_STATUS = FAILED → Retry required or escalate to payment team"),
]


# =============================================================
# REFUND — Named condition functions
# =============================================================

def is_refund_successful(r):
    return val(r, "REFUND_RESPONSE_CODE") == "SUCCESS"


def is_refund_failed(r):
    return val(r, "REFUND_RESPONSE_CODE") == "FAILED"


# =============================================================
# REFUND RULES
# =============================================================
REFUND_RULES = [

    Rule("RF_01", "Refund Successful", 1,
         condition  = is_refund_successful,
         reference  = "REFUND_RESPONSE_CODE = SUCCESS → Refund processed successfully, no further action"),

    Rule("RF_02", "Refund Failed - Escalate", 2,
         condition  = is_refund_failed,
         reference  = "REFUND_RESPONSE_CODE = FAILED → Escalate to payment team for manual refund processing"),
]


# =============================================================
# RULE MAP & EVALUATOR
# =============================================================
RULE_MAP = {
    "UNBLOCK": UNBLOCK_RULES,
    "FRC":     FRC_RULES,
    "REFUND":  REFUND_RULES,
}


def evaluate_rules(scenario: str, data: Dict[str, Any]) -> Dict[str, Any]:
    scenario = scenario.upper()
    rules    = RULE_MAP.get(scenario, [])

    matched = sorted(
        [r for r in rules if r.evaluate(data)],
        key=lambda r: r.priority
    )

    if not matched:
        return {
            "primary_rule":        None,
            "rule_id":             None,
            "decision":            "No rule matched",
            "matched_rules":       [],
            "reference":           None,
            "all_matched_details": []
        }

    primary = matched[0]
    return {
        "primary_rule":   primary.rule_id,
        "rule_id":        primary.rule_id,
        "decision":       primary.description,
        "reference":      primary.reference,
        "matched_rules":  [r.rule_id for r in matched],
        "all_matched_details": [
            {
                "rule_id":     r.rule_id,
                "description": r.description,
                "condition":   r.reference,
            }
            for r in matched
        ]
    }
