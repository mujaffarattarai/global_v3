cd /AEM/.RSP/global_ai_agent_v3
python3.9 -m venv venv
source venv/bin/activate
which python
/AEM/.RSP/global_ai_agent_v3/venv/bin/python -m pip uninstall llama-index llama-index-core llama-index-embeddings-ollama -y
/AEM/.RSP/global_ai_agent_v3/venv/bin/python -m pip install --proxy http://10.94.147.19:8080 pandas openpyxl requests oracledb flask watchdog pyyaml pip install llama-index==0.10.68 llama-index-embeddings-ollama==0.1.3 

/AEM/.RSP/global_ai_agent_v3/venv/bin/python global_indexer.py
