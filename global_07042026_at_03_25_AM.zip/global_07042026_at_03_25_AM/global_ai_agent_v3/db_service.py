# =============================================================
# db_service.py
# All Oracle DB logic — query execution, result parsing,
# and SCRM multi-zone connection handling.
#
# Imported by csv_processor.py
# =============================================================

import logging
import oracledb

from config_utils import load_properties
from app_registry import get_app_config

logger = logging.getLogger(__name__)

# ── Oracle client — lazy init ──────────────────────────────────
_oracle_initialized = False


def ensure_oracle_client():
    """Initialize Oracle thick client once. Safe to call multiple times."""
    global _oracle_initialized
    if not _oracle_initialized:
        oracledb.init_oracle_client()
        _oracle_initialized = True


def load_sql(query_file):
    """Read SQL from file."""
    with open(query_file, "r", encoding="utf-8") as f:
        return f.read()


def run_query(cursor, sql, value, search_by):
    """
    Execute a query for a given identifier value.

    search_by: "MSISDN" or "ORDER_CODE"

    ORDER_CODE fix: replaces the MSISDN WHERE clause with ORDER_CODE clause.
    This is a known fragile point — v3 keeps it working but it's documented here.
    A better long-term fix is parameterized queries with named bind variables.
    """
    if search_by == "ORDER_CODE":
        sql = sql.replace(
            "WHERE caf.SELECTED_NUMBER = :1",
            "WHERE caf.ORDER_CODE = :1",
        )
    cursor.execute(sql, [value])
    row = cursor.fetchone()
    return row[0] if row else "NO DATA FOUND"


def parse_db_result(raw_text):
    """
    Converts raw DB result string into a dict for rules engine.

    Input:  "MSISDN: 9876543210\nACCOUNT_STATUS: ACTIVE\n..."
    Output: {"MSISDN": "9876543210", "ACCOUNT_STATUS": "ACTIVE", ...}
    """
    data = {}
    for line in raw_text.split("\n"):
        if ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip()
    return data


def scrm_first_match_zone(app_key, identifiers, base_sql):
    """
    SCRM multi-zone DB query.

    Tries each zone in order (ZONE_1 → ZONE_2 → ZONE_3 → ZONE_4).
    Stops at the first zone that returns actual data for the identifier.
    Falls back to last zone result if no zone has data.

    Returns: (zone_key, raw_solution)
    No open DB connections returned — each zone is fully closed before moving on.
    """
    from app_registry import _load_registry
    reg     = _load_registry()
    app_cfg = reg.get(app_key, {})
    zones   = app_cfg.get("zone_order",
              list(app_cfg.get("scenarios", {}).keys()))

    last_zone     = zones[-1] if zones else "ZONE_1"
    last_solution = "NO DATA FOUND IN ANY ZONE"

    for zone_key in zones:
        conn   = None
        cursor = None
        try:
            cfg      = get_app_config(app_key, zone_key)
            db_props = load_properties(cfg["db_config_path"])
            db_cfg   = {
                "user":     db_props["db.user"],
                "password": db_props["db.password"],
                "dsn":      db_props["db.dsn"],
            }
            ensure_oracle_client()
            conn   = oracledb.connect(**db_cfg)
            cursor = conn.cursor()

            parts = []
            found = False
            for search_by, value in identifiers:
                try:
                    result = run_query(cursor, base_sql, value, search_by)
                except Exception as e:
                    result = f"DB ERROR: {e}"
                parts.append(f"{search_by}: {value}\n{result}")
                if "NO DATA FOUND" not in result and "DB ERROR" not in result:
                    found = True

            raw_solution  = "\n\n".join(parts)
            last_zone     = zone_key
            last_solution = raw_solution

            if found:
                logger.info(f"SCRM zone match: {zone_key} has data")
                return zone_key, raw_solution
            else:
                logger.info(f"SCRM zone {zone_key}: NO DATA — trying next zone")

        except Exception as e:
            logger.warning(f"SCRM zone {zone_key} connection error: {e}")

        finally:
            try:
                if cursor: cursor.close()
            except Exception:
                pass
            try:
                if conn: conn.close()
            except Exception:
                pass

    logger.info(f"SCRM: no zone had data — returning result from {last_zone}")
    return last_zone, last_solution
