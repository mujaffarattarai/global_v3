# =============================================================
# app_registry.py
# Loads and validates apps_registry.yaml.
# Supports both single-DB apps and multi-zone apps (SCRM).
#
# For normal apps:   db_config lives at the app level
# For multi-zone:    db_config lives at the scenario level
# =============================================================

import yaml
import os

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
REGISTRY_FILE = os.path.join(BASE_DIR, "apps_registry.yaml")

_registry = None


def _load_registry():
    global _registry
    if _registry is None:
        with open(REGISTRY_FILE, "r") as f:
            data = yaml.safe_load(f)
        _registry = data.get("apps", {})
    return _registry


def reload_registry():
    """Force reload — call after admin edits to apps_registry.yaml."""
    global _registry
    _registry = None
    return _load_registry()


def get_all_apps():
    """Returns dict of app_key -> display_name."""
    reg = _load_registry()
    return {k: v.get("display_name", k) for k, v in reg.items()}


def get_scenarios_for_app(app_key):
    """Returns dict of scenario_key -> display_name for a given app."""
    reg = _load_registry()
    app = reg.get(app_key, {})
    scenarios = app.get("scenarios", {})
    return {k: v.get("display_name", k) for k, v in scenarios.items()}


def is_multi_zone(app_key):
    """Returns True if app uses per-scenario DB connections (e.g. SCRM)."""
    reg = _load_registry()
    app = reg.get(app_key, {})
    return bool(app.get("multi_zone", False))


def get_app_config(app_key, scenario_key):
    """
    Returns full resolved config dict for a given app + scenario.

    For normal apps:
      - db_config_path resolved from app-level db_config
    For multi-zone apps (SCRM):
      - db_config_path resolved from scenario-level db_config

    Always returns:
      app_key, app_display_name, scenario_key, scenario_display_name,
      db_config_path, query_file, sop_file, vector_file,
      rules_module, rules_scenario, multi_zone
    """
    reg = _load_registry()

    app = reg.get(app_key)
    if not app:
        raise ValueError(f"App '{app_key}' not found in registry.")

    scenario = app.get("scenarios", {}).get(scenario_key)
    if not scenario:
        raise ValueError(f"Scenario '{scenario_key}' not found for app '{app_key}'.")

    multi_zone = bool(app.get("multi_zone", False))

    # ── Resolve db_config_path ────────────────────────────────
    # Multi-zone: each scenario has its own db_config
    # Normal:     app-level db_config shared by all scenarios
    if multi_zone:
        raw_db_cfg = scenario.get("db_config")
        if not raw_db_cfg:
            raise ValueError(
                f"Multi-zone app '{app_key}' scenario '{scenario_key}' "
                f"is missing 'db_config' in apps_registry.yaml"
            )
    else:
        raw_db_cfg = app.get("db_config")
        if not raw_db_cfg:
            raise ValueError(f"App '{app_key}' is missing 'db_config' in apps_registry.yaml")

    db_config_path = (raw_db_cfg if os.path.isabs(raw_db_cfg)
                      else os.path.join(BASE_DIR, raw_db_cfg))

    def resolve(rel):
        if not rel:
            return None
        return rel if os.path.isabs(rel) else os.path.join(BASE_DIR, rel)

    return {
        "app_key":               app_key,
        "app_display_name":      app.get("display_name", app_key),
        "scenario_key":          scenario_key,
        "scenario_display_name": scenario.get("display_name", scenario_key),
        "db_config_path":        db_config_path,
        "query_file":            resolve(scenario.get("query_file")),
        "sop_file":              resolve(scenario.get("sop_file")),
        "vector_file":           resolve(scenario.get("vector_file")),
        "rules_module":          scenario.get("rules_module"),
        "rules_scenario":        scenario.get("rules_scenario", scenario_key),
        "multi_zone":            multi_zone,
    }

