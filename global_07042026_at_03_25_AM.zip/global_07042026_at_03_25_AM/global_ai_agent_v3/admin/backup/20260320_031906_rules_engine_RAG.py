# =============================================================
# rules/telecom_rules.py
# Rules for Telecom Digital app (UNBLOCK / FRC / REFUND)
# To add a new app: create rules/<newapp>_rules.py with same pattern
# =============================================================

from typing import Dict, Any, List, Callable


class Rule:
    def __init__(self, rule_id, scenario, description, priority, condition, reference=""):
        self.rule_id = rule_id
        self.scenario = scenario
        self.description = description
        self.priority = priority
        self.condition = condition
        self.reference = reference

    def evaluate(self, data):
        try:
            return self.condition(data)
        except Exception:
            return False


def val(data, key):
    value = data.get(key)
    if isinstance(value, str):
        return value.strip().upper()
    return value


# ==========================================================
# UNBLOCK RULES
# ==========================================================
UNBLOCK_RULES = [
    Rule("UB_01", "UNBLOCK", "Number Already Unblocked", 3,
         lambda r: val(r, "IS_UNBLOCKED") == "Y",
         "IS_UNBLOCKED = Y"),

    Rule("UB_02", "UNBLOCK", "Auto Unblocked - Expired as per TAT", 2,
         lambda r: val(r, "ORDER_STATUS") == "EXPIRED"
                   and val(r, "JOURNEY_TYPE") not in ("MNP", "NMNP"),
         "ORDER_STATUS = EXPIRED AND JOURNEY_TYPE NOT IN (MNP, NMNP) → Auto unblock as per TAT"),

    Rule("UB_03", "UNBLOCK", "Expired NMNP - Not Eligible for Unblocking", 1,
         lambda r: val(r, "ORDER_STATUS") == "EXPIRED"
                   and val(r, "JOURNEY_TYPE") == "NMNP",
         "ORDER_STATUS = EXPIRED AND JOURNEY_TYPE = NMNP → Not eligible, expired MNP cannot be manually unblocked"),

    Rule("UB_04", "UNBLOCK", "Eligible for Manual Unblocking", 4,
         lambda r: val(r, "JOURNEY_TYPE") == "NEW"
                   and val(r, "IS_UNBLOCKED") in [None, "N"]
                   and val(r, "ORDER_STATUS") not in [
                       "EXPIRED", "ORDER_GENERATED", "SIM_ACTIVATED",
                       "OUT_FOR_DELIVERY", "APPOINTMENT_CONFIRMED", "REVERT_TO_SUPERVISOR"
                   ],
         "JOURNEY_TYPE = NEW AND IS_UNBLOCKED = N AND ORDER_STATUS not in blocked list → Eligible for manual unblock"),

    Rule("UB_05", "UNBLOCK", "Not Eligible - Current Transaction Status", 5,
         lambda r: val(r, "ORDER_STATUS") in [
             "SIM_ACTIVATED", "OUT_FOR_DELIVERY", "APPOINTMENT_CONFIRMED",
             "APPOINTMENT_RESCHEDULED", "REVERT_TO_SUPERVISOR", "PROSPECT",
             "B2B_SUCCESS", "ORDER_MIGRATED_OTP_FLOW"
         ],
         "ORDER_STATUS in [SIM_ACTIVATED, OUT_FOR_DELIVERY, APPOINTMENT_CONFIRMED, APPOINTMENT_RESCHEDULED, REVERT_TO_SUPERVISOR, PROSPECT, B2B_SUCCESS, ORDER_MIGRATED_OTP_FLOW] → Not eligible for unblocking"),

    Rule("UB_06", "UNBLOCK", "Not Eligible - Current Transaction Status", 6,
         lambda r: val(r, "ORDER_STATUS") in [
             "VCON_ORDER_GENERATED"
         ],
         "ORDER_STATUS in [VCON_ORDER_GENERATED] → Not eligible for unblocking"),

]

# ==========================================================
# FRC RULES
# ==========================================================
FRC_RULES = [
    Rule("FRC_01", "FRC", "FRC Successful", 1,
         lambda r: val(r, "FRC_CALLBACK_STATUS") == "SUCCESS",
         "FRC_CALLBACK_STATUS = SUCCESS → FRC processed successfully, no action needed"),

    Rule("FRC_02", "FRC", "FRC Failed - Retry Required", 2,
         lambda r: val(r, "FRC_CALLBACK_STATUS") == "FAILED",
         "FRC_CALLBACK_STATUS = FAILED → Retry required or escalate to payment team"),
]

# ==========================================================
# REFUND RULES
# ==========================================================
REFUND_RULES = [
    Rule("RF_01", "REFUND", "Refund Successful", 1,
         lambda r: val(r, "REFUND_RESPONSE_CODE") == "SUCCESS",
         "REFUND_RESPONSE_CODE = SUCCESS → Refund processed successfully, no further action"),

    Rule("RF_02", "REFUND", "Refund Failed - Escalate", 2,
         lambda r: val(r, "REFUND_RESPONSE_CODE") == "FAILED",
         "REFUND_RESPONSE_CODE = FAILED → Escalate to payment team for manual refund processing"),
]

# ==========================================================
# RULE MAP & EVALUATOR
# ==========================================================
RULE_MAP = {
    "UNBLOCK": UNBLOCK_RULES,
    "FRC": FRC_RULES,
    "REFUND": REFUND_RULES,
}


def evaluate_rules(scenario: str, data: Dict[str, Any]) -> Dict[str, Any]:
    scenario = scenario.upper()
    rules = RULE_MAP.get(scenario, [])
    matched = sorted(
        [r for r in rules if r.evaluate(data)],
        key=lambda r: r.priority
    )
    if not matched:
        return {
            "primary_rule": None,
            "rule_id": None,
            "decision": "No rule matched",
            "matched_rules": [],
            "reference": None,
            "condition": None,
            "all_matched_details": []
        }
    primary = matched[0]
    return {
        "primary_rule":  primary.rule_id,
        "rule_id":       primary.rule_id,
        "decision":      primary.description,
        "reference":     primary.reference,
        "condition":     primary.reference,
        "matched_rules": [r.rule_id for r in matched],
        "all_matched_details": [
            {
                "rule_id":     r.rule_id,
                "description": r.description,
                "condition":   r.reference,
            }
            for r in matched
        ]
    }

