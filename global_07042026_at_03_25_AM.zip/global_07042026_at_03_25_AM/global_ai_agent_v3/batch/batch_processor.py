# =============================================================
# batch/batch_processor.py
# Watchdog daemon — monitors batch/input/<app>/ for CSV files.
#
# v3 change: WATCH_TARGETS is no longer hardcoded.
# It is built dynamically from apps_registry.yaml at startup.
# Adding a new app via Admin panel is now enough — no need to
# also edit this file manually.
# =============================================================

import os
import sys
import time
import shutil
import logging
import threading
from datetime import datetime
from logging.handlers import RotatingFileHandler

from watchdog.observers import Observer
from watchdog.events    import FileSystemEventHandler

# ── Add project root to path ──────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from csv_processor import process_csv

# ── Batch subdirectory ────────────────────────────────────────
BATCH_DIR     = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR     = os.path.join(BATCH_DIR, "input")
OUTPUT_DIR    = os.path.join(BATCH_DIR, "output")
PROCESSED_DIR = os.path.join(BATCH_DIR, "processed")
FAILED_DIR    = os.path.join(BATCH_DIR, "failed")
LOGS_DIR      = os.path.join(BATCH_DIR, "logs")

POLL_INTERVAL    = 10
_processing_lock = threading.Lock()
_in_progress     = set()


# =============================================================
# LOGGING
# =============================================================
def setup_logging():
    os.makedirs(LOGS_DIR, exist_ok=True)
    log_file  = os.path.join(LOGS_DIR, "batch_processor.log")
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )
    fh = RotatingFileHandler(log_file, maxBytes=10 * 1024 * 1024, backupCount=5)
    fh.setFormatter(formatter)
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(fh)
    root.addHandler(ch)
    return logging.getLogger(__name__)


logger = setup_logging()


# =============================================================
# DYNAMIC WATCH TARGETS
# Reads apps_registry.yaml to build the watch list.
# Each app gets its own input folder under batch/input/<app_key_lower>/
# SCRM gets one folder per zone: batch/input/scrm/zone_1/ etc.
# =============================================================
def build_watch_targets():
    """
    Build WATCH_TARGETS dynamically from apps_registry.yaml.

    Returns list of (watch_path, app_key, scenario_key) tuples.
    scenario_key=None means auto-detect per row (non-SCRM apps).
    SCRM zones get their own subfolder and explicit scenario_key.
    """
    from app_registry import _load_registry
    registry = _load_registry()

    targets = []

    for app_key, app_data in registry.items():
        app_folder = app_key.lower()
        is_scrm    = app_key.upper() == "SCRM"

        if is_scrm:
            # SCRM: one subfolder per zone
            for zone_key in app_data.get("scenarios", {}).keys():
                zone_folder = zone_key.lower().replace("zone_", "zone_")
                watch_path  = os.path.join(INPUT_DIR, "scrm", zone_folder)
                targets.append((watch_path, app_key, zone_key))
                logger.info(f"Watch target: {watch_path} → app={app_key} zone={zone_key}")
        else:
            # Standard apps: one folder per app
            watch_path = os.path.join(INPUT_DIR, app_folder)
            targets.append((watch_path, app_key, None))
            logger.info(f"Watch target: {watch_path} → app={app_key}")

    return targets


# =============================================================
# PATH HELPERS
# =============================================================
def _relative_subfolder(watch_path):
    return os.path.relpath(watch_path, INPUT_DIR)

def _output_path(watch_path, base_name):
    rel = _relative_subfolder(watch_path)
    return os.path.join(OUTPUT_DIR, rel, f"{base_name}.xlsx")

def _processed_path(watch_path, base_name, timestamp):
    rel = _relative_subfolder(watch_path)
    return os.path.join(PROCESSED_DIR, rel, f"{base_name}_{timestamp}.csv")

def _failed_path(watch_path, base_name, timestamp):
    rel = _relative_subfolder(watch_path)
    return os.path.join(FAILED_DIR, rel, f"{base_name}_{timestamp}.csv")

def _error_log_path(watch_path, base_name, timestamp):
    rel = _relative_subfolder(watch_path)
    return os.path.join(FAILED_DIR, rel, f"{base_name}_{timestamp}_error.log")


# =============================================================
# FOLDER INIT
# =============================================================
def init_folders(watch_targets):
    for watch_path, _, _ in watch_targets:
        rel = _relative_subfolder(watch_path)
        for base in [INPUT_DIR, OUTPUT_DIR, PROCESSED_DIR, FAILED_DIR]:
            path = os.path.join(base, rel)
            os.makedirs(path, exist_ok=True)
            logger.info(f"Folder ready: {path}")


# =============================================================
# FILE PROCESSOR
# =============================================================
def process_file(csv_path, watch_path, app_key, scenario_key):
    file_name  = os.path.basename(csv_path)
    base_name  = os.path.splitext(file_name)[0]
    timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S")

    output_path    = _output_path(watch_path, base_name)
    processed_path = _processed_path(watch_path, base_name, timestamp)
    failed_path    = _failed_path(watch_path, base_name, timestamp)
    error_log_path = _error_log_path(watch_path, base_name, timestamp)

    logger.info("=" * 60)
    logger.info(f"PROCESSING START | app={app_key} | file={file_name}")
    logger.info(f"  Input  : {csv_path}")
    logger.info(f"  Output : {output_path}")
    logger.info("=" * 60)

    start_time = datetime.now()

    try:
        process_csv(
            input_csv    = csv_path,
            output_file  = output_path,
            app_key      = app_key,
            scenario_key = scenario_key,
        )

        duration = (datetime.now() - start_time).total_seconds()
        os.makedirs(os.path.dirname(processed_path), exist_ok=True)
        shutil.move(csv_path, processed_path)

        logger.info("=" * 60)
        logger.info(f"PROCESSING SUCCESS | app={app_key} | {file_name} | {duration:.1f}s")
        logger.info(f"  Output   : {output_path}")
        logger.info(f"  Archived : {processed_path}")
        logger.info("=" * 60)

    except Exception as e:
        duration = (datetime.now() - start_time).total_seconds()

        logger.error("=" * 60)
        logger.error(f"PROCESSING FAILED | app={app_key} | {file_name} | {duration:.1f}s")
        logger.error(f"  Error : {e}")
        logger.error("=" * 60, exc_info=True)

        try:
            os.makedirs(os.path.dirname(failed_path), exist_ok=True)
            shutil.move(csv_path, failed_path)
        except Exception as mv_err:
            logger.error(f"Could not move to failed/: {mv_err}")

        try:
            with open(error_log_path, "w") as f:
                f.write(f"File      : {file_name}\n")
                f.write(f"App       : {app_key}\n")
                f.write(f"Timestamp : {timestamp}\n")
                f.write(f"Duration  : {duration:.1f}s\n")
                f.write(f"Error     : {str(e)}\n\n")
                import traceback
                f.write(traceback.format_exc())
        except Exception as log_err:
            logger.error(f"Could not write error log: {log_err}")

    finally:
        with _processing_lock:
            _in_progress.discard(csv_path)


# =============================================================
# WATCHDOG EVENT HANDLER
# =============================================================
class CSVEventHandler(FileSystemEventHandler):

    def __init__(self, watch_path, app_key, scenario_key):
        self.watch_path   = watch_path
        self.app_key      = app_key
        self.scenario_key = scenario_key
        super().__init__()

    def on_created(self, event):
        if not event.is_directory:
            self._handle_file(event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            self._handle_file(event.dest_path)

    def _handle_file(self, file_path):
        if not file_path.lower().endswith(".csv"):
            return

        time.sleep(2)

        if not os.path.exists(file_path):
            logger.warning(f"File disappeared: {file_path}")
            return
        if os.path.getsize(file_path) == 0:
            logger.warning(f"Empty file ignored: {file_path}")
            return

        with _processing_lock:
            if file_path in _in_progress:
                return
            _in_progress.add(file_path)

        logger.info(f"New CSV: {file_path} | app={self.app_key}")

        thread = threading.Thread(
            target = process_file,
            args   = (file_path, self.watch_path, self.app_key, self.scenario_key),
            name   = f"proc-{os.path.basename(file_path)}",
            daemon = True,
        )
        thread.start()


# =============================================================
# SCAN EXISTING FILES ON STARTUP
# =============================================================
def scan_existing_files(watch_targets):
    logger.info("Scanning for existing CSV files...")
    found = 0

    for watch_path, app_key, scenario_key in watch_targets:
        if not os.path.exists(watch_path):
            continue

        for file_name in sorted(os.listdir(watch_path)):
            if not file_name.lower().endswith(".csv"):
                continue

            file_path = os.path.join(watch_path, file_name)
            if os.path.getsize(file_path) == 0:
                continue

            found += 1
            logger.info(f"Found existing file: {file_path}")

            with _processing_lock:
                _in_progress.add(file_path)

            thread = threading.Thread(
                target = process_file,
                args   = (file_path, watch_path, app_key, scenario_key),
                name   = f"startup-{file_name}",
                daemon = True,
            )
            thread.start()
            time.sleep(1)

    if found == 0:
        logger.info("No existing CSV files found — watching for new arrivals")
    else:
        logger.info(f"Queued {found} existing file(s) for processing")


# =============================================================
# MAIN
# =============================================================
def main():
    logger.info("=" * 60)
    logger.info("  global_ai_agent v3 — Batch Processor Daemon")
    logger.info(f"  Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"  Base    : {BASE_DIR}")
    logger.info(f"  Inputs  : {INPUT_DIR}")
    logger.info("=" * 60)

    from stats_db import init_db
    init_db()

    # Build watch targets dynamically from registry
    watch_targets = build_watch_targets()
    logger.info(f"Watch targets loaded: {len(watch_targets)} folder(s)")

    init_folders(watch_targets)
    scan_existing_files(watch_targets)

    observer = Observer()
    for watch_path, app_key, scenario_key in watch_targets:
        handler = CSVEventHandler(watch_path, app_key, scenario_key)
        observer.schedule(handler, path=watch_path, recursive=False)
        logger.info(f"Watching: {watch_path} → app={app_key}")

    observer.start()
    logger.info("Daemon running. Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(POLL_INTERVAL)
            if int(time.time()) % 300 < POLL_INTERVAL:
                active = threading.active_count() - 2
                logger.info(f"Health check — active threads: {active}")
    except KeyboardInterrupt:
        logger.info("Shutdown signal received...")
        observer.stop()

    observer.join()
    logger.info("Batch processor daemon stopped.")


if __name__ == "__main__":
    main()
