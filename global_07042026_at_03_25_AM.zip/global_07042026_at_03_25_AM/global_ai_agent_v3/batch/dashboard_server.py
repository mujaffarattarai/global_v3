# =============================================================
# dashboard_server.py
# Flask dashboard for global_ai_agent_batch
# Port: 8011
# =============================================================

import os
import sys
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request, send_file, abort

# ── Standard deployment paths ──────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_DIR = os.path.dirname(os.path.abspath(__file__))
AGENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Project root (BASE_DIR) contains global_csv_processor.py
# BATCH_DIR is a subfolder — do NOT add it ahead of BASE_DIR
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from admin_engine import (
    list_apps, get_app_detail, onboard_app,
    update_scenario_rules, run_rag_indexer
)

from stats_db import (
    init_db,
    get_today_summary,
    get_daily_summary,
    get_files_by_date,
    get_scenario_trend,
    get_all_time_totals,
    get_scenario_breakdown_by_date,
    get_live_progress,
    get_results_by_file,
    get_recent_files,
)

# ── Oracle client initialisation ─────────────────────────────
try:
    import oracledb
    oracledb.init_oracle_client()
    print("Oracle client initialised")
except Exception as _oe:
    print(f"Oracle client init skipped: {_oe}")

# ── Logging ───────────────────────────────────────────────────
logging.basicConfig(
    level  = logging.INFO,
    format = "%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)

# ── Flask app ─────────────────────────────────────────────────
app = Flask(
    __name__,
    template_folder = os.path.join(BASE_DIR, "templates"),
    static_folder   = os.path.join(BASE_DIR, "static"),
    static_url_path = "/static"
)


# =============================================================
# ROUTES
# =============================================================

@app.route("/")
def dashboard():
    """Main dashboard page."""
    return render_template("dashboard.html")


@app.route("/api/summary/today")
def api_today():
    """Today's summary cards."""
    try:
        data = get_today_summary()
        # Calculate success rate
        total = data.get("total_rows") or 0
        processed = data.get("processed_rows") or 0
        data["success_rate"] = round((processed / total * 100), 1) if total > 0 else 0
        return jsonify({"status": "ok", "data": data})
    except Exception as e:
        logger.error(f"API today error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/summary/alltime")
def api_alltime():
    """All-time totals."""
    try:
        data = get_all_time_totals()
        total = data.get("total_rows") or 0
        processed = data.get("processed_rows") or 0
        data["success_rate"] = round((processed / total * 100), 1) if total > 0 else 0
        return jsonify({"status": "ok", "data": data})
    except Exception as e:
        logger.error(f"API alltime error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/daily")
def api_daily():
    """Day-wise summary table — last N days."""
    try:
        days = int(request.args.get("days", 7))
        rows = get_daily_summary(days)

        # Add success rate per day
        for r in rows:
            total     = r.get("total_rows") or 0
            processed = r.get("processed_rows") or 0
            r["success_rate"] = round((processed / total * 100), 1) if total > 0 else 0

        return jsonify({"status": "ok", "data": rows})
    except Exception as e:
        logger.error(f"API daily error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/files/<process_date>")
def api_files_by_date(process_date):
    """Drill down — files processed on a specific date."""
    try:
        rows = get_files_by_date(process_date)

        # Format duration
        for r in rows:
            secs = r.get("duration_seconds") or 0
            mins = int(secs // 60)
            secs_rem = int(secs % 60)
            r["duration_fmt"] = f"{mins}m {secs_rem}s" if mins > 0 else f"{secs_rem}s"

            # Success rate per file
            total     = r.get("total_rows") or 0
            processed = r.get("processed_rows") or 0
            r["success_rate"] = round((processed / total * 100), 1) if total > 0 else 0

        return jsonify({"status": "ok", "data": rows, "date": process_date})
    except Exception as e:
        logger.error(f"API files error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/trend")
def api_trend():
    """Scenario trend for chart — last N days."""
    try:
        days = int(request.args.get("days", 7))
        rows = get_scenario_trend(days)
        return jsonify({"status": "ok", "data": rows})
    except Exception as e:
        logger.error(f"API trend error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/scenario/<process_date>")
def api_scenario_by_date(process_date):
    """Scenario breakdown for a specific date."""
    try:
        data = get_scenario_breakdown_by_date(process_date)
        return jsonify({"status": "ok", "data": data, "date": process_date})
    except Exception as e:
        logger.error(f"API scenario error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500



@app.route("/api/apps")
def api_apps():
    """Returns list of available app input folders for the upload dropdown."""
    try:
        input_dir = os.path.join(BATCH_DIR, "input")
        apps = [d for d in sorted(os.listdir(input_dir))
                if os.path.isdir(os.path.join(input_dir, d))]
        return jsonify({"status": "ok", "apps": apps})
    except Exception as e:
        logger.error(f"API apps error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/upload", methods=["POST"])
def api_upload():
    try:
        if "file" not in request.files:
            return jsonify({"status": "error", "msg": "No file provided"}), 400
        file    = request.files["file"]
        app_key = request.form.get("app_key", "").strip().lower()
        if not file.filename:
            return jsonify({"status": "error", "msg": "No file selected"}), 400
        if not file.filename.lower().endswith(".csv"):
            return jsonify({"status": "error", "msg": "Only .csv files are allowed"}), 400
        input_dir    = os.path.join(BATCH_DIR, "input")
        allowed_apps = [d for d in os.listdir(input_dir)
                        if os.path.isdir(os.path.join(input_dir, d))]
        if app_key not in allowed_apps:
            return jsonify({"status": "error",
                "msg": f"Unknown app folder. Available: {', '.join(allowed_apps)}"}), 400
        file_name = os.path.basename(file.filename)
        save_path = os.path.join(input_dir, app_key, file_name)
        file.save(save_path)
        file_size_kb = round(os.path.getsize(save_path) / 1024, 1)
        logger.info(f"File uploaded: {save_path} ({file_size_kb} KB)")
        return jsonify({"status": "ok",
            "msg": f"'{file_name}' uploaded to input/{app_key}/ — daemon will process it shortly.",
            "file_name": file_name, "app_key": app_key, "size_kb": file_size_kb})
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/download/<app_key>/<file_name>")
def api_download(app_key, file_name):
    """
    Download XLSX output file.
    app_key   : e.g. TELECOM_DIGITAL  (converted to lowercase for folder)
    file_name : e.g. ticket.xlsx
    """
    try:
        # Security — prevent path traversal
        file_name  = os.path.basename(file_name)
        app_folder = app_key.lower().replace("_", "_")

        output_path = os.path.join(
            BATCH_DIR, "output", app_folder, file_name
        )

        if not os.path.exists(output_path):
            logger.warning(f"Download requested but file not found: {output_path}")
            abort(404)

        logger.info(f"Download: {output_path}")
        return send_file(
            output_path,
            as_attachment       = True,
            download_name       = file_name,
            mimetype            = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        logger.error(f"Download error: {e}")
        abort(500)



@app.route("/api/vikyapedia", methods=["POST"])
def api_vikyapedia():
    """
    Vi-Ky-Pedia — single ticket test endpoint.
    Runs full pipeline: DB → Rules → RAG → LLM
    Body JSON:
      app_key  : e.g. "TELECOM_DIGITAL"
      summary  : ticket summary text
      notes    : ticket notes text
      msisdn   : optional — auto-extracted from summary+notes if blank
    """
    import importlib
    import re
    import oracledb

    # ── Ensure Oracle client is initialised ───────────────────
    try:
        oracledb.init_oracle_client()
    except Exception:
        pass  # already initialised or thick mode not needed

    try:
        body        = request.get_json() or {}
        app_key     = body.get("app_key", "").strip().upper()
        summary     = body.get("summary", "").strip()
        notes       = body.get("notes",   "").strip()
        msisdn_hint = body.get("msisdn",  "").strip()

        if not app_key:
            return jsonify({"status": "error", "msg": "app_key is required"}), 400
        if not summary and not notes:
            return jsonify({"status": "error", "msg": "summary or notes is required"}), 400

        # ── v3 imports ────────────────────────────────────────
        from csv_processor import (
            detect_scenario, extract_identifiers,
            load_rules_evaluator, calculate_confidence,
            MSISDN_REGEX, ORDER_CODE_REGEX,
        )
        from db_service   import ensure_oracle_client, load_sql, run_query, parse_db_result
        from llm_service  import generate_llm_response
        from rag_engine   import RAGEngine
        from config_utils import load_properties
        from app_registry import get_app_config

        start_time = datetime.now()

        # ── Step 1: Detect scenario ───────────────────────────
        fake_row = {"Summary*": summary, "Notes": notes,
                    "Resolution": "", "Attachment": ""}
        scenario_key, skip_reason = detect_scenario(fake_row)

        if not scenario_key:
            return jsonify({
                "status":   "error",
                "msg":      f"Could not detect scenario from text. {skip_reason}",
                "detected": "UNKNOWN"
            }), 400

        # ── Step 2: Extract identifiers ───────────────────────
        combined_text = summary + " " + notes

        msisdns     = re.findall(MSISDN_REGEX, combined_text)
        order_codes = re.findall(ORDER_CODE_REGEX, combined_text)

        if msisdn_hint:
            if re.match(r"^[6-9]\d{9}$", msisdn_hint):
                msisdns = [msisdn_hint] + msisdns
            else:
                order_codes = [msisdn_hint] + order_codes

        msisdns     = list(dict.fromkeys(msisdns))
        order_codes = list(dict.fromkeys(order_codes))

        identifiers = (
            [("MSISDN", m)     for m in msisdns] +
            [("ORDER_CODE", o) for o in order_codes]
        )

        if not identifiers:
            return jsonify({
                "status":            "error",
                "msg":               "No MSISDN or Order Code found in summary/notes.",
                "scenario_detected": scenario_key
            }), 400

        # ── Step 3: Load app config ───────────────────────────
        cfg      = get_app_config(app_key, scenario_key)
        db_props = load_properties(cfg["db_config_path"])

        db_config = {
            "user":     db_props["db.user"],
            "password": db_props["db.password"],
            "dsn":      db_props["db.dsn"],
        }

        llm_enabled = db_props.get("llm.enabled", "false").lower() == "true"
        llm_model   = db_props.get("llm.model",   "llama3.2:3b")
        llm_url     = db_props.get("llm.url")
        embed_url   = db_props.get("embedding.url")
        embed_model = db_props.get("embedding.model")

        sql            = load_sql(cfg["query_file"])
        evaluate_rules = load_rules_evaluator(cfg["rules_module"])
        rules_scenario = cfg["rules_scenario"]
        rag_engine     = RAGEngine(cfg["sop_file"], embed_url, embed_model)

        # ── Step 4: DB Query ──────────────────────────────────
        ensure_oracle_client()
        conn   = oracledb.connect(**db_config)
        cursor = conn.cursor()

        results = []
        try:
            for search_by, value in identifiers:
                try:
                    result = run_query(cursor, sql, value, search_by)
                except Exception as e:
                    result = f"DB ERROR: {e}"
                results.append(f"{search_by}: {value}\n{result}")
        finally:
            cursor.close()
            conn.close()

        raw_solution = "\n\n".join(results)
        structured   = parse_db_result(raw_solution)

        # ── Step 5: Rules engine ──────────────────────────────
        rule_output  = evaluate_rules(rules_scenario, structured)
        rule_matched = bool(rule_output.get("primary_rule"))

        # ── Step 6: RAG or skip ───────────────────────────────
        rag_chunks, rag_refs, rag_score = [], [], 0.0
        rag_used = False

        if rule_matched:
            rag_status = "SKIPPED — Rule matched"
        else:
            rag_used    = True
            rag_results = rag_engine.search(
                summary + raw_solution, top_k=1, scenario=rules_scenario
            )
            if rag_results:
                rag_score = float(rag_results[0][0])
                for score, text, chunk_id, section in rag_results:
                    rag_chunks.append(text)
                    rag_refs.append(f"{chunk_id} ({section})")
            rag_status = f"Score: {round(rag_score, 4)} | Ref: {rag_refs[0] if rag_refs else '—'}"

        # ── Step 7: Single LLM call (structured + narrative) ──
        ai_result, narrative, raw_llm = generate_llm_response(
            summary, raw_solution, rule_output, rag_chunks,
            llm_url, llm_model, llm_enabled, db_parsed=structured
        )

        # ── Step 8: Confidence (out of 100) ───────────────────
        confidence = calculate_confidence(rule_matched, ai_result, rag_score)

        duration = round((datetime.now() - start_time).total_seconds(), 2)

        return jsonify({
            "status":            "ok",
            "scenario_detected": scenario_key,
            "identifiers_found": [f"{s}: {v}" for s, v in identifiers],
            "rule_matched":      rule_matched,
            "rule_id":           rule_output.get("primary_rule") or "—",
            "rule_decision":     rule_output.get("decision")     or "No rule matched",
            "rule_reference":    rule_output.get("reference")    or "—",
            "rag_used":          rag_used,
            "rag_status":        rag_status,
            "rag_score":         round(rag_score, 4),
            "rag_reference":     rag_refs[0] if rag_refs else "—",
            "root_cause":        ai_result.get("root_cause", "—") if ai_result else "—",
            "ai_status":         ai_result.get("status",     "—") if ai_result else "—",
            "ai_action":         ai_result.get("action",     "—") if ai_result else "—",
            "confidence":        confidence,
            "narrative":         narrative,
            "duration_sec":      duration
        })

    except Exception as e:
        logger.error(f"Vi-Ky-Pedia error: {e}", exc_info=True)
        return jsonify({"status": "error", "msg": str(e)}), 500



# =============================================================
# ADMIN ROUTES
# =============================================================

@app.route("/api/admin/apps")
def admin_list_apps():
    """List all registered apps."""
    try:
        apps = list_apps()
        return jsonify({"status": "ok", "apps": apps})
    except Exception as e:
        logger.error(f"Admin list apps error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/app/<app_key>")
def admin_get_app(app_key):
    """Get full detail for an app."""
    try:
        detail = get_app_detail(app_key.upper())
        if not detail:
            return jsonify({"status": "error", "msg": f"App {app_key} not found"}), 404
        return jsonify({"status": "ok", "data": detail})
    except Exception as e:
        logger.error(f"Admin get app error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/onboard", methods=["POST"])
def admin_onboard():
    """
    Onboard a new application.
    Full pipeline: create files, update registry, index RAG.
    """
    try:
        payload = request.get_json()
        if not payload:
            return jsonify({"status": "error", "msg": "No payload provided"}), 400

        app_key = payload.get("app_key", "").strip()
        if not app_key:
            return jsonify({"status": "error", "msg": "app_key is required"}), 400

        if not payload.get("scenarios"):
            return jsonify({"status": "error", "msg": "At least one scenario is required"}), 400

        logger.info(f"Onboarding app: {app_key}")
        result = onboard_app(payload)

        status_code = 200 if result["success"] else 500
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"Admin onboard error: {e}", exc_info=True)
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/update-rules", methods=["POST"])
def admin_update_rules():
    """Update rules for a managed scenario."""
    try:
        payload      = request.get_json()
        app_key      = payload.get("app_key", "").upper()
        scenario_key = payload.get("scenario_key", "").upper()
        rules        = payload.get("rules", [])

        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        update_scenario_rules(app_key, scenario_key, rules)
        return jsonify({"status": "ok", "msg": f"Rules updated for {app_key}/{scenario_key}"})

    except Exception as e:
        logger.error(f"Admin update rules error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/reindex", methods=["POST"])
def admin_reindex():
    """Re-run RAG indexer for a scenario."""
    try:
        payload      = request.get_json()
        app_key      = payload.get("app_key", "").upper()
        scenario_key = payload.get("scenario_key", "").upper()
        sop_content  = payload.get("sop", "")

        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        ok, msg = run_rag_indexer(app_key, scenario_key, sop_content)
        return jsonify({"status": "ok" if ok else "error", "msg": msg})

    except Exception as e:
        logger.error(f"Admin reindex error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


# =============================================================
# ADMIN EDIT ROUTES  (SOP · Rules · Services)
# =============================================================

@app.route("/api/admin/read-sop", methods=["GET"])
def admin_read_sop():
    """Read SOP text for a given app/scenario."""
    try:
        app_key      = request.args.get("app_key",      "").upper()
        scenario_key = request.args.get("scenario_key", "").upper()
        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        sop_path = os.path.join(
            AGENT_DIR, "apps", app_key.lower(),
            f"rag_documents_{scenario_key.lower()}.txt"
        )
        if not os.path.exists(sop_path):
            return jsonify({"status": "ok", "content": "", "path": sop_path, "exists": False})

        with open(sop_path, "r", encoding="utf-8") as f:
            content = f.read()

        stat      = os.stat(sop_path)
        file_size = stat.st_size
        modified  = datetime.fromtimestamp(stat.st_mtime).strftime("%d %b %Y %H:%M")

        # Count backups
        backup_dir   = os.path.join(AGENT_DIR, "apps", app_key.lower(), "backups")
        backup_count = len([f for f in os.listdir(backup_dir)
                            if f.startswith(f"rag_documents_{scenario_key.lower()}")
                            ]) if os.path.exists(backup_dir) else 0

        return jsonify({
            "status":       "ok",
            "content":      content,
            "path":         sop_path,
            "exists":       True,
            "modified":     modified,
            "size_bytes":   file_size,
            "backup_count": backup_count
        })
    except Exception as e:
        logger.error(f"Admin read-sop error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/save-sop", methods=["POST"])
def admin_save_sop():
    """Save SOP text, create backup, and re-index RAG."""
    try:
        payload      = request.get_json()
        app_key      = payload.get("app_key",      "").upper()
        scenario_key = payload.get("scenario_key", "").upper()
        content      = payload.get("content",      "")
        reindex      = payload.get("reindex", True)

        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        app_dir  = os.path.join(AGENT_DIR, "apps", app_key.lower())
        sop_path = os.path.join(app_dir, f"rag_documents_{scenario_key.lower()}.txt")

        # Create backup before saving
        backup_dir = os.path.join(app_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        if os.path.exists(sop_path):
            ts          = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(backup_dir,
                          f"rag_documents_{scenario_key.lower()}_{ts}.txt")
            import shutil
            shutil.copy2(sop_path, backup_path)
            logger.info(f"SOP backup created: {backup_path}")

        # Save new content
        with open(sop_path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.info(f"SOP saved: {sop_path}")

        # Re-index RAG
        rag_msg = "RAG re-index skipped"
        if reindex:
            ok, rag_msg = run_rag_indexer(app_key, scenario_key, content)
            if not ok:
                return jsonify({"status": "warning", "msg": f"SOP saved but RAG failed: {rag_msg}"})

        return jsonify({"status": "ok", "msg": f"SOP saved and {rag_msg}"})

    except Exception as e:
        logger.error(f"Admin save-sop error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/read-rules", methods=["GET"])
def admin_read_rules():
    """Read rules engine Python file for a given app/scenario."""
    try:
        app_key      = request.args.get("app_key",      "").upper()
        scenario_key = request.args.get("scenario_key", "").upper()
        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        rules_path = os.path.join(
            AGENT_DIR, "apps", app_key.lower(),
            f"rules_engine_{scenario_key.lower()}.py"
        )
        if not os.path.exists(rules_path):
            return jsonify({"status": "ok", "content": "", "path": rules_path, "exists": False})

        with open(rules_path, "r", encoding="utf-8") as f:
            content = f.read()

        stat     = os.stat(rules_path)
        modified = datetime.fromtimestamp(stat.st_mtime).strftime("%d %b %Y %H:%M")

        # Count backups
        backup_dir   = os.path.join(AGENT_DIR, "apps", app_key.lower(), "backups")
        backup_count = len([f for f in os.listdir(backup_dir)
                            if f.startswith(f"rules_engine_{scenario_key.lower()}")
                            ]) if os.path.exists(backup_dir) else 0

        # Also return meta rules if available (for visual builder)
        meta_rules = []
        meta_path  = os.path.join(AGENT_DIR, "apps", app_key.lower(), "admin_meta.json")
        if os.path.exists(meta_path):
            import json as _json
            with open(meta_path) as mf:
                meta = _json.load(mf)
            meta_rules = meta.get("scenarios", {}).get(scenario_key, {}).get("rules", [])

        return jsonify({
            "status":       "ok",
            "content":      content,
            "path":         rules_path,
            "exists":       True,
            "modified":     modified,
            "backup_count": backup_count,
            "meta_rules":   meta_rules
        })
    except Exception as e:
        logger.error(f"Admin read-rules error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/save-rules", methods=["POST"])
def admin_save_rules():
    """Save rules engine file (raw code) with backup."""
    try:
        payload      = request.get_json()
        app_key      = payload.get("app_key",      "").upper()
        scenario_key = payload.get("scenario_key", "").upper()
        content      = payload.get("content",      "")

        if not app_key or not scenario_key:
            return jsonify({"status": "error", "msg": "app_key and scenario_key required"}), 400

        app_dir    = os.path.join(AGENT_DIR, "apps", app_key.lower())
        rules_path = os.path.join(app_dir, f"rules_engine_{scenario_key.lower()}.py")

        # Backup first
        backup_dir = os.path.join(app_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        if os.path.exists(rules_path):
            ts          = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(backup_dir,
                          f"rules_engine_{scenario_key.lower()}_{ts}.py")
            import shutil
            shutil.copy2(rules_path, backup_path)
            logger.info(f"Rules backup created: {backup_path}")

        with open(rules_path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.info(f"Rules saved: {rules_path}")

        return jsonify({"status": "ok", "msg": f"Rules engine saved: {rules_path}"})

    except Exception as e:
        logger.error(f"Admin save-rules error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/list-backups", methods=["GET"])
def admin_list_backups():
    """List backups for an app/scenario."""
    try:
        app_key      = request.args.get("app_key",      "").upper()
        scenario_key = request.args.get("scenario_key", "").upper()
        file_type    = request.args.get("type", "sop")   # sop | rules

        backup_dir = os.path.join(AGENT_DIR, "apps", app_key.lower(), "backups")
        if not os.path.exists(backup_dir):
            return jsonify({"status": "ok", "backups": []})

        prefix = f"rag_documents_{scenario_key.lower()}" if file_type == "sop" \
                 else f"rules_engine_{scenario_key.lower()}"

        backups = []
        for fname in sorted(os.listdir(backup_dir), reverse=True):
            if fname.startswith(prefix):
                fpath = os.path.join(backup_dir, fname)
                stat  = os.stat(fpath)
                backups.append({
                    "filename": fname,
                    "size":     stat.st_size,
                    "modified": datetime.fromtimestamp(
                                    stat.st_mtime).strftime("%d %b %Y %H:%M")
                })

        return jsonify({"status": "ok", "backups": backups})
    except Exception as e:
        logger.error(f"Admin list-backups error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/admin/run-service", methods=["POST"])
def admin_run_service():
    """Run a shell script command (start/stop/restart/status)."""
    import subprocess
    import re
    import threading

    def strip_ansi(text):
        """Remove ANSI escape codes from shell output."""
        return re.sub(r'\x1b\[[0-9;]*m', '', text)

    try:
        payload = request.get_json()
        action  = payload.get("action", "").lower()

        ALLOWED_ACTIONS = {"start", "stop", "restart", "status"}
        if action not in ALLOWED_ACTIONS:
            return jsonify({"status": "error", "msg": f"Invalid action: {action}"}), 400

        script = os.path.join(BATCH_DIR, "start_batch.sh")
        if not os.path.exists(script):
            return jsonify({"status": "error", "msg": f"Script not found: {script}"}), 404

        # For stop/restart — only touch the batch_processor, never the dashboard
        # Running start_batch.sh stop would kill our own server process
        if action in ("stop", "restart"):
            lines = []

            # Stop only batch_processor.py (not dashboard_server.py)
            stop_result = subprocess.run(
                ["pkill", "-f", "batch_processor.py"],
                capture_output=True, text=True
            )
            lines.append("[INFO] Batch processor stopped" if stop_result.returncode == 0
                         else "[INFO] Batch processor was not running")

            if action == "restart":
                import time
                time.sleep(1)
                # Start batch processor in background
                log_file = os.path.join(BATCH_DIR, "logs", "batch_processor.log")
                venv_python = os.path.join(
                    "/home/postgres/global_ai_agent/venv", "bin", "python"
                )
                python_bin = venv_python if os.path.exists(venv_python) else "python3"
                subprocess.Popen(
                    [python_bin, os.path.join(BATCH_DIR, "batch_processor.py")],
                    cwd    = BATCH_DIR,
                    stdout = open(log_file, "a"),
                    stderr = subprocess.STDOUT
                )
                lines.append("[INFO] Batch processor restarted")

            output       = "\n".join(lines)
            return_code  = 0

        else:
            # start / status — safe to run normally
            result = subprocess.run(
                ["bash", script, action],
                capture_output = True,
                text           = True,
                timeout        = 30,
                cwd            = BATCH_DIR
            )
            output      = strip_ansi((result.stdout or "") + (result.stderr or ""))
            return_code = result.returncode

        return jsonify({
            "status":      "ok",
            "action":      action,
            "return_code": return_code,
            "output":      output.strip()
        })

    except subprocess.TimeoutExpired:
        return jsonify({"status": "error", "msg": "Script timed out (>30s)"}), 500
    except Exception as e:
        logger.error(f"Admin run-service error: {e}")
        return jsonify({"status": "error", "msg": str(e)}), 500



# =============================================================
# LIVE PROGRESS API
# =============================================================
@app.route("/api/live")
def api_live():
    """Returns currently running files with row-level progress."""
    try:
        return jsonify({"status": "ok", "data": get_live_progress()})
    except Exception as e:
        return jsonify({"status": "error", "msg": str(e)}), 500


# =============================================================
# RESULTS API
# =============================================================
@app.route("/api/results/files")
def api_results_files():
    """Returns list of recent completed files for results picker."""
    try:
        return jsonify({"status": "ok", "data": get_recent_files(limit=30)})
    except Exception as e:
        return jsonify({"status": "error", "msg": str(e)}), 500


@app.route("/api/results/<int:file_id>")
def api_results_by_file(file_id):
    """Returns paginated ticket results for a given file."""
    try:
        page      = int(request.args.get("page",      1))
        page_size = int(request.args.get("page_size", 50))
        search    = request.args.get("search", "").strip()
        data      = get_results_by_file(file_id, page, page_size, search)
        return jsonify({"status": "ok", **data})
    except Exception as e:
        return jsonify({"status": "error", "msg": str(e)}), 500


# =============================================================
# MAIN
# =============================================================
if __name__ == "__main__":
    init_db()
    logger.info("Dashboard server starting on port 8011...")
    app.run(host="0.0.0.0", port=8011, debug=False)



