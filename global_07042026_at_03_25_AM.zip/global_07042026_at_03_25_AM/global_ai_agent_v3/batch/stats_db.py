# =============================================================
# stats_db.py
# SQLite helper for global_ai_agent_batch
# Tables:
#   batch_files   — one row per CSV file
#   batch_rows    — one row per ticket row (stats only)
#   batch_daily   — pre-aggregated daily summary
#   batch_live    — live progress per active file (updated per row)
#   batch_results — full ticket results for dashboard view
# =============================================================

import sqlite3
import os
import logging
from datetime import datetime, date

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_DIR   = os.path.join(BASE_DIR, "db")
DB_PATH  = os.path.join(DB_DIR, "batch_stats.db")


def get_connection():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    conn = get_connection()
    try:
        cur = conn.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_files (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                file_name        TEXT    NOT NULL,
                app_key          TEXT    NOT NULL,
                input_path       TEXT,
                output_path      TEXT,
                status           TEXT    NOT NULL,
                total_rows       INTEGER DEFAULT 0,
                processed_rows   INTEGER DEFAULT 0,
                skipped_rows     INTEGER DEFAULT 0,
                unknown_rows     INTEGER DEFAULT 0,
                failed_rows      INTEGER DEFAULT 0,
                process_date     TEXT    NOT NULL,
                process_time     TEXT    NOT NULL,
                process_datetime TEXT    NOT NULL,
                duration_seconds REAL    DEFAULT 0,
                error_message    TEXT
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_rows (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id           INTEGER NOT NULL,
                file_name         TEXT    NOT NULL,
                app_key           TEXT    NOT NULL,
                scenario_detected TEXT,
                rule_matched      INTEGER DEFAULT 0,
                rag_used          INTEGER DEFAULT 0,
                confidence        INTEGER DEFAULT 0,
                row_status        TEXT,
                process_date      TEXT    NOT NULL,
                process_datetime  TEXT    NOT NULL,
                FOREIGN KEY (file_id) REFERENCES batch_files(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_daily (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                process_date           TEXT    NOT NULL,
                app_key                TEXT    NOT NULL,
                total_files            INTEGER DEFAULT 0,
                total_rows             INTEGER DEFAULT 0,
                processed_rows         INTEGER DEFAULT 0,
                skipped_rows           INTEGER DEFAULT 0,
                unknown_rows           INTEGER DEFAULT 0,
                failed_rows            INTEGER DEFAULT 0,
                unblock_count          INTEGER DEFAULT 0,
                frc_count              INTEGER DEFAULT 0,
                refund_count           INTEGER DEFAULT 0,
                caf_count              INTEGER DEFAULT 0,
                unknown_scenario_count INTEGER DEFAULT 0,
                success_files          INTEGER DEFAULT 0,
                failed_files           INTEGER DEFAULT 0,
                UNIQUE(process_date, app_key)
            )
        """)

        # Live progress — one row per active file, updated per ticket row
        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_live (
                file_id        INTEGER PRIMARY KEY,
                file_name      TEXT    NOT NULL,
                app_key        TEXT    NOT NULL,
                total_rows     INTEGER DEFAULT 0,
                current_row    INTEGER DEFAULT 0,
                current_ticket TEXT,
                current_msisdn TEXT,
                current_zone   TEXT,
                current_rule   TEXT,
                status         TEXT    DEFAULT 'RUNNING',
                started_at     TEXT    NOT NULL,
                last_updated   TEXT    NOT NULL
            )
        """)

        # Full ticket results for dashboard view
        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_results (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id              INTEGER NOT NULL,
                file_name            TEXT    NOT NULL,
                app_key              TEXT    NOT NULL,
                process_date         TEXT    NOT NULL,
                ticket_number        TEXT,
                summary              TEXT,
                notes                TEXT,
                solution             TEXT,
                ai_zone_found        TEXT,
                ai_primary_rule      TEXT,
                ai_root_cause        TEXT,
                ai_status            TEXT,
                ai_action            TEXT,
                ai_narrative         TEXT,
                ai_confidence        INTEGER DEFAULT 0,
                ai_scenario_detected TEXT,
                FOREIGN KEY (file_id) REFERENCES batch_files(id)
            )
        """)

        conn.commit()
        logger.info("SQLite DB initialized successfully at: %s", DB_PATH)
    except Exception as e:
        logger.error("DB init error: %s", e)
        raise
    finally:
        conn.close()


# =============================================================
# batch_files
# =============================================================
def insert_file_start(file_name, app_key, input_path):
    now  = datetime.now()
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO batch_files
                (file_name, app_key, input_path, status,
                 process_date, process_time, process_datetime)
            VALUES (?, ?, ?, 'IN_PROGRESS', ?, ?, ?)
        """, (
            file_name, app_key, input_path,
            now.strftime("%Y-%m-%d"),
            now.strftime("%H:%M:%S"),
            now.strftime("%Y-%m-%d %H:%M:%S")
        ))
        conn.commit()
        file_id = cur.lastrowid

        conn.execute("""
            INSERT OR REPLACE INTO batch_live
                (file_id, file_name, app_key, total_rows, current_row,
                 status, started_at, last_updated)
            VALUES (?, ?, ?, 0, 0, 'RUNNING', ?, ?)
        """, (file_id, file_name, app_key,
              now.strftime("%Y-%m-%d %H:%M:%S"),
              now.strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()

        logger.info("DB: File started — id=%s name=%s", file_id, file_name)
        return file_id
    finally:
        conn.close()


def update_file_end(file_id, output_path, status,
                    total_rows, processed_rows, skipped_rows,
                    unknown_rows, failed_rows, duration_seconds,
                    error_message=None):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE batch_files SET
                output_path=?, status=?, total_rows=?,
                processed_rows=?, skipped_rows=?, unknown_rows=?,
                failed_rows=?, duration_seconds=?, error_message=?
            WHERE id=?
        """, (
            output_path, status, total_rows, processed_rows,
            skipped_rows, unknown_rows, failed_rows,
            round(duration_seconds, 2), error_message, file_id
        ))
        conn.execute("""
            UPDATE batch_live SET status=?, last_updated=?
            WHERE file_id=?
        """, (status, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), file_id))
        conn.commit()
        logger.info("DB: File ended — id=%s status=%s rows=%s", file_id, status, total_rows)
    finally:
        conn.close()


# =============================================================
# batch_live — live progress
# =============================================================
def upsert_live_progress(file_id, file_name, app_key, total_rows,
                         current_row, current_ticket="",
                         current_msisdn="", current_zone="", current_rule=""):
    now  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_connection()
    try:
        conn.execute("""
            INSERT OR REPLACE INTO batch_live
                (file_id, file_name, app_key, total_rows, current_row,
                 current_ticket, current_msisdn, current_zone, current_rule,
                 status, started_at, last_updated)
            VALUES (?,?,?,?,?,?,?,?,?,'RUNNING',
                COALESCE((SELECT started_at FROM batch_live WHERE file_id=?),?),?)
        """, (
            file_id, file_name, app_key, total_rows, current_row,
            str(current_ticket or "")[:80],
            str(current_msisdn or ""),
            str(current_zone   or ""),
            str(current_rule   or ""),
            file_id, now, now
        ))
        conn.commit()
    except Exception as e:
        logger.warning("Live progress update failed: %s", e)
    finally:
        conn.close()


def get_live_progress():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT file_id, file_name, app_key, total_rows, current_row,
                   current_ticket, current_msisdn, current_zone, current_rule,
                   status, started_at, last_updated
            FROM batch_live
            WHERE status = 'RUNNING'
            ORDER BY started_at DESC
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# =============================================================
# batch_results — full ticket results
# =============================================================
def insert_result_row(file_id, file_name, app_key,
                      ticket_number, summary, notes, solution,
                      ai_zone_found, ai_primary_rule,
                      ai_root_cause, ai_status, ai_action,
                      ai_narrative, ai_confidence, ai_scenario_detected):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO batch_results
                (file_id, file_name, app_key, process_date,
                 ticket_number, summary, notes, solution,
                 ai_zone_found, ai_primary_rule, ai_root_cause,
                 ai_status, ai_action, ai_narrative,
                 ai_confidence, ai_scenario_detected)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            file_id, file_name, app_key,
            date.today().strftime("%Y-%m-%d"),
            str(ticket_number or "")[:100],
            str(summary       or "")[:500],
            str(notes         or "")[:500],
            str(solution      or "")[:500],
            str(ai_zone_found        or ""),
            str(ai_primary_rule      or ""),
            str(ai_root_cause        or "")[:300],
            str(ai_status            or ""),
            str(ai_action            or "")[:300],
            str(ai_narrative         or ""),
            int(ai_confidence        or 0),
            str(ai_scenario_detected or ""),
        ))
        conn.commit()
    except Exception as e:
        logger.warning("insert_result_row failed: %s", e)
    finally:
        conn.close()


def get_results_by_file(file_id, page=1, page_size=50, search=""):
    conn   = get_connection()
    offset = (page - 1) * page_size
    try:
        if search:
            p = f"%{search}%"
            rows = conn.execute("""
                SELECT ticket_number, summary, notes, solution,
                       ai_zone_found, ai_primary_rule, ai_root_cause,
                       ai_status, ai_action, ai_narrative,
                       ai_confidence, ai_scenario_detected
                FROM batch_results
                WHERE file_id=?
                  AND (ticket_number LIKE ? OR summary LIKE ?
                       OR notes LIKE ? OR ai_narrative LIKE ?)
                ORDER BY id LIMIT ? OFFSET ?
            """, (file_id, p, p, p, p, page_size, offset)).fetchall()
            total = conn.execute("""
                SELECT COUNT(*) FROM batch_results
                WHERE file_id=?
                  AND (ticket_number LIKE ? OR summary LIKE ?
                       OR notes LIKE ? OR ai_narrative LIKE ?)
            """, (file_id, p, p, p, p)).fetchone()[0]
        else:
            rows = conn.execute("""
                SELECT ticket_number, summary, notes, solution,
                       ai_zone_found, ai_primary_rule, ai_root_cause,
                       ai_status, ai_action, ai_narrative,
                       ai_confidence, ai_scenario_detected
                FROM batch_results
                WHERE file_id=?
                ORDER BY id LIMIT ? OFFSET ?
            """, (file_id, page_size, offset)).fetchall()
            total = conn.execute(
                "SELECT COUNT(*) FROM batch_results WHERE file_id=?",
                (file_id,)
            ).fetchone()[0]

        return {"rows": [dict(r) for r in rows],
                "total": total, "page": page, "page_size": page_size}
    finally:
        conn.close()


def get_recent_files(limit=20):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT id, file_name, app_key, status,
                   total_rows, processed_rows,
                   process_date, process_time, duration_seconds
            FROM batch_files
            WHERE status IN ('SUCCESS','PARTIAL','FAILED')
            ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# =============================================================
# Standard queries
# =============================================================
def insert_row_stat(file_id, file_name, app_key, scenario_detected,
                    rule_matched, rag_used, confidence, row_status):
    now  = datetime.now()
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO batch_rows
                (file_id, file_name, app_key, scenario_detected,
                 rule_matched, rag_used, confidence, row_status,
                 process_date, process_datetime)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            file_id, file_name, app_key, scenario_detected,
            1 if rule_matched else 0, 1 if rag_used else 0,
            confidence, row_status,
            now.strftime("%Y-%m-%d"),
            now.strftime("%Y-%m-%d %H:%M:%S")
        ))
        conn.commit()
    finally:
        conn.close()


def upsert_daily_stats(process_date, app_key,
                       total_rows, processed_rows, skipped_rows,
                       unknown_rows, failed_rows,
                       scenario_counts, file_status):
    conn = get_connection()
    try:
        existing = conn.execute("""
            SELECT id FROM batch_daily WHERE process_date=? AND app_key=?
        """, (process_date, app_key)).fetchone()

        if existing:
            conn.execute("""
                UPDATE batch_daily SET
                    total_files=total_files+1, total_rows=total_rows+?,
                    processed_rows=processed_rows+?, skipped_rows=skipped_rows+?,
                    unknown_rows=unknown_rows+?, failed_rows=failed_rows+?,
                    unblock_count=unblock_count+?, frc_count=frc_count+?,
                    refund_count=refund_count+?, caf_count=caf_count+?,
                    unknown_scenario_count=unknown_scenario_count+?,
                    success_files=success_files+?, failed_files=failed_files+?
                WHERE process_date=? AND app_key=?
            """, (
                total_rows, processed_rows, skipped_rows, unknown_rows, failed_rows,
                scenario_counts.get("UNBLOCK",0), scenario_counts.get("FRC",0),
                scenario_counts.get("REFUND",0), scenario_counts.get("CAF_SUBMISSION",0),
                scenario_counts.get("UNKNOWN",0),
                1 if file_status=="SUCCESS" else 0,
                1 if file_status=="FAILED"  else 0,
                process_date, app_key
            ))
        else:
            conn.execute("""
                INSERT INTO batch_daily
                    (process_date, app_key, total_files, total_rows, processed_rows,
                     skipped_rows, unknown_rows, failed_rows, unblock_count, frc_count,
                     refund_count, caf_count, unknown_scenario_count,
                     success_files, failed_files)
                VALUES (?,?,1,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                process_date, app_key, total_rows, processed_rows, skipped_rows,
                unknown_rows, failed_rows,
                scenario_counts.get("UNBLOCK",0), scenario_counts.get("FRC",0),
                scenario_counts.get("REFUND",0), scenario_counts.get("CAF_SUBMISSION",0),
                scenario_counts.get("UNKNOWN",0),
                1 if file_status=="SUCCESS" else 0,
                1 if file_status=="FAILED"  else 0
            ))
        conn.commit()
        logger.info("DB: Daily stats updated — date=%s app=%s", process_date, app_key)
    finally:
        conn.close()


def get_daily_summary(days=7):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT process_date,
                   SUM(total_files) AS total_files, SUM(total_rows) AS total_rows,
                   SUM(processed_rows) AS processed_rows, SUM(skipped_rows) AS skipped_rows,
                   SUM(unknown_rows) AS unknown_rows, SUM(failed_rows) AS failed_rows,
                   SUM(success_files) AS success_files, SUM(failed_files) AS failed_files,
                   SUM(unblock_count) AS unblock_count, SUM(frc_count) AS frc_count,
                   SUM(refund_count) AS refund_count, SUM(caf_count) AS caf_count,
                   SUM(unknown_scenario_count) AS unknown_scenario_count
            FROM batch_daily WHERE process_date >= date('now',?)
            GROUP BY process_date ORDER BY process_date DESC
        """, (f"-{days} days",)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_files_by_date(process_date):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT id, file_name, app_key, status, total_rows, processed_rows,
                   skipped_rows, unknown_rows, failed_rows,
                   process_time, duration_seconds, error_message
            FROM batch_files WHERE process_date=? ORDER BY process_time DESC
        """, (process_date,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_today_summary():
    today = date.today().strftime("%Y-%m-%d")
    conn  = get_connection()
    try:
        row = conn.execute("""
            SELECT COUNT(*) AS total_files, SUM(total_rows) AS total_rows,
                   SUM(processed_rows) AS processed_rows, SUM(skipped_rows) AS skipped_rows,
                   SUM(unknown_rows) AS unknown_rows, SUM(failed_rows) AS failed_rows,
                   SUM(CASE WHEN status='SUCCESS' THEN 1 ELSE 0 END) AS success_files,
                   SUM(CASE WHEN status='FAILED'  THEN 1 ELSE 0 END) AS failed_files
            FROM batch_files WHERE process_date=?
        """, (today,)).fetchone()
        return dict(row) if row else {}
    finally:
        conn.close()


def get_scenario_breakdown_by_date(process_date):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT unblock_count, frc_count, refund_count,
                   caf_count, unknown_scenario_count
            FROM batch_daily WHERE process_date=?
        """, (process_date,)).fetchone()
        return dict(row) if row else {}
    finally:
        conn.close()


def get_scenario_trend(days=7):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT process_date,
                   SUM(unblock_count) AS unblock_count, SUM(frc_count) AS frc_count,
                   SUM(refund_count) AS refund_count, SUM(caf_count) AS caf_count,
                   SUM(unknown_scenario_count) AS unknown_scenario_count
            FROM batch_daily WHERE process_date >= date('now',?)
            GROUP BY process_date ORDER BY process_date ASC
        """, (f"-{days} days",)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_all_time_totals():
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT COUNT(*) AS total_files, SUM(total_rows) AS total_rows,
                   SUM(processed_rows) AS processed_rows,
                   SUM(failed_rows) AS failed_rows, SUM(unknown_rows) AS unknown_rows
            FROM batch_files WHERE status != 'IN_PROGRESS'
        """).fetchone()
        return dict(row) if row else {}
    finally:
        conn.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    init_db()
    print(f"Database initialized at: {DB_PATH}")

