# =============================================================
# admin_engine.py
# Handles all file generation for new app onboarding
# Called by dashboard_server.py admin endpoints
# =============================================================

import os
import sys
import json
import yaml
import shutil
import logging
import subprocess
from datetime import datetime

logger = logging.getLogger(__name__)

# ── Standard deployment paths ──────────────────────────────────
# Deployment base: /home/postgres
# Batch module:    /home/postgres/global_ai_agent_batch
# Agent module:    /home/postgres/global_ai_agent
BATCH_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR  = os.path.dirname(BATCH_DIR)
AGENT_DIR = BASE_DIR
APPS_DIR  = os.path.join(BASE_DIR, "apps")
REGISTRY  = os.path.join(BASE_DIR, "apps_registry.yaml")

if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)





# ── Startup path validation ────────────────────────────────────
def _validate_paths():
    """Fail loudly at startup if required deployment paths are missing."""
    missing = []
    for label, path in [
        ("BATCH_DIR (global_ai_agent_batch)", BATCH_DIR),
        ("AGENT_DIR (global_ai_agent)",       AGENT_DIR),
        ("APPS_DIR  (global_ai_agent/apps)",  APPS_DIR),
    ]:
        if not os.path.exists(path):
            missing.append(f"  {label}  →  {path}")
    if missing:
        raise RuntimeError(
            "\n[admin_engine] Startup failed — required paths not found:\n" +
            "\n".join(missing) +
            "\nExpected deployment layout:"
            "\n  /home/postgres/global_ai_agent_batch/   ← this module"
            "\n  /home/postgres/global_ai_agent/         ← agent module"
            "\n  /home/postgres/global_ai_agent/apps/    ← app configs"
        )


_validate_paths()


# =============================================================
# REGISTRY HELPERS
# =============================================================

def load_registry():
    """Load apps_registry.yaml as dict, stripping the top-level 'apps:' wrapper."""
    if not os.path.exists(REGISTRY):
        return {}
    with open(REGISTRY, "r") as f:
        data = yaml.safe_load(f) or {}
    return data.get("apps", data)


def save_registry(data):
    """Save dict to apps_registry.yaml, always writing under 'apps:' wrapper."""
    with open(REGISTRY, "w") as f:
        yaml.dump({"apps": data}, f, default_flow_style=False, sort_keys=False)


def _get_scenario_dict(app_entry):
    """
    Handles both YAML structures:
      - New format: app_entry has a nested 'scenarios:' key
      - Old flat format: app_entry keys ARE the scenario names
    Returns the scenario dict {SCENARIO_KEY: {...}, ...}
    """
    if "scenarios" in app_entry and isinstance(app_entry["scenarios"], dict):
        return app_entry["scenarios"]
    # Flat format — filter out known non-scenario keys
    non_scenario_keys = {"display_name", "db_config", "db_config_path"}
    return {k: v for k, v in app_entry.items() if k not in non_scenario_keys}


def list_apps():
    """
    Returns list of all registered apps with their scenarios.
    Also marks which apps were created via admin (have admin_meta.json).
    Handles both nested 'scenarios:' format and flat format.
    """
    registry = load_registry()
    apps = []

    for app_key, app_entry in registry.items():
        app_folder    = app_key.lower()
        meta_path     = os.path.join(APPS_DIR, app_folder, "admin_meta.json")
        is_managed    = os.path.exists(meta_path)

        scenario_dict = _get_scenario_dict(app_entry)
        scenario_list = list(scenario_dict.keys())

        apps.append({
            "app_key":        app_key,
            "scenarios":      scenario_list,
            "is_managed":     is_managed,
            "scenario_count": len(scenario_list)
        })

    return apps


def get_app_detail(app_key):
    """
    Returns full detail for an app including meta if managed.
    Handles both nested 'scenarios:' format and flat format.
    """
    registry = load_registry()
    app_key  = app_key.upper()

    if app_key not in registry:
        return None

    app_entry  = registry[app_key]
    app_folder = app_key.lower()
    meta_path  = os.path.join(APPS_DIR, app_folder, "admin_meta.json")
    is_managed = os.path.exists(meta_path)

    meta = {}
    if is_managed:
        with open(meta_path) as f:
            meta = json.load(f)

    # Read properties file — support both 'db_config' and 'db_config_path' key names
    db_config_rel = app_entry.get("db_config") or app_entry.get("db_config_path", "")
    props_path    = os.path.join(AGENT_DIR, db_config_rel) if db_config_rel \
                    else os.path.join(APPS_DIR, f"{app_folder}.properties")

    props = {}
    if os.path.exists(props_path):
        with open(props_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    props[k.strip()] = v.strip()

    # Get scenarios — handles both formats
    scenario_dict = _get_scenario_dict(app_entry)

    scenarios = {}
    for scenario_key, scen_entry in scenario_dict.items():
        scen_folder = os.path.join(APPS_DIR, app_folder)
        scen_meta   = meta.get("scenarios", {}).get(scenario_key, {})

        sql_path    = os.path.join(scen_folder, f"{scenario_key.lower()}.sql")
        sql_content = open(sql_path).read() if os.path.exists(sql_path) else ""

        # Prefer registry-defined sop_file, fallback to legacy naming convention
        _sop_from_registry = scen_entry.get("sop_file", "")
        if _sop_from_registry:
            sop_path = os.path.join(AGENT_DIR, _sop_from_registry) \
               if not os.path.isabs(_sop_from_registry) else _sop_from_registry
        else:
            sop_path = os.path.join(scen_folder, f"rag_documents_{scenario_key.lower()}.txt")
        sop_content = open(sop_path).read() if os.path.exists(sop_path) else ""

        scenarios[scenario_key] = {
            "keywords":   scen_meta.get("keywords", []),
            "sql":        sql_content,
            "sop":        sop_content,
            "rules":      scen_meta.get("rules", []),
            "is_managed": bool(scen_meta)
        }

    return {
        "app_key":    app_key,
        "is_managed": is_managed,
        "props":      props,
        "scenarios":  scenarios
    }


# =============================================================
# RULE BUILDER → PYTHON CODE GENERATOR
# =============================================================

def build_condition_code(groups, group_operator="OR"):
    """
    Converts rule builder JSON groups into a Python lambda condition string.

    groups = [
      {
        "operator": "AND",
        "conditions": [
          {"field": "ORDER_STATUS", "op": "equals",  "value": "EXPIRED"},
          {"field": "JOURNEY_TYPE", "op": "equals",  "value": "NMNP"}
        ]
      },
      ...
    ]
    group_operator = "OR" (how groups are joined)
    """

    def single_condition(cond):
        field  = cond["field"]
        op     = cond["op"]
        value  = cond.get("value", "")
        values = cond.get("values", [])  # for "in" operator

        if op == "equals":
            return f'val(r, "{field}") == "{value.upper()}"'
        elif op == "not_equals":
            return f'val(r, "{field}") != "{value.upper()}"'
        elif op == "in":
            vals = json.dumps([v.upper() for v in values])
            return f'val(r, "{field}") in {vals}'
        elif op == "not_in":
            vals = json.dumps([v.upper() for v in values])
            return f'val(r, "{field}") not in {vals}'
        elif op == "is_empty":
            return f'val(r, "{field}") in [None, "", "NONE", "NULL"]'
        elif op == "is_not_empty":
            return f'val(r, "{field}") not in [None, "", "NONE", "NULL"]'
        elif op == "contains":
            return f'("{value.upper()}" in (val(r, "{field}") or ""))'
        else:
            return f'val(r, "{field}") == "{value.upper()}"'

    group_parts = []
    for group in groups:
        conditions = group.get("conditions", [])
        if not conditions:
            continue
        op     = group.get("operator", "AND").lower()
        joiner = f" {op} "
        parts  = [single_condition(c) for c in conditions]
        if len(parts) == 1:
            group_parts.append(parts[0])
        else:
            group_parts.append(f"({joiner.join(parts)})")

    if not group_parts:
        return "True"

    join_op = f" {group_operator.lower()} "
    if len(group_parts) == 1:
        return group_parts[0]
    return f"({join_op.join(group_parts)})"


def build_reference_string(groups, group_operator="OR"):
    """Builds a human-readable reference string from rule groups."""
    parts = []
    for group in groups:
        conditions = group.get("conditions", [])
        op         = group.get("operator", "AND")
        cond_parts = []
        for c in conditions:
            field = c["field"]
            cop   = c["op"].upper().replace("_", " ")
            val   = c.get("value", "") or ",".join(c.get("values", []))
            cond_parts.append(f"{field} {cop} {val}")
        parts.append(f"({f' {op} '.join(cond_parts)})")
    return f" {group_operator} ".join(parts)


def generate_rules_engine(app_key, scenario_key, rules):
    """
    Generates a complete rules_engine.py content from rule builder JSON.

    rules = [
      {
        "rule_id": "UB_01",
        "description": "Already Unblocked",
        "priority": 1,
        "group_operator": "OR",
        "groups": [ ... ]
      }
    ]
    """
    scenario_upper = scenario_key.upper()
    var_name       = f"{scenario_upper}_RULES"

    lines = [
        "# =============================================================",
        f"# rules_engine.py — {app_key} / {scenario_key}",
        f"# Auto-generated by Vi-Ky-Pedia Admin on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "# DO NOT EDIT MANUALLY — use Admin tab to modify",
        "# =============================================================",
        "",
        "from typing import Dict, Any, List, Callable",
        "",
        "",
        "class Rule:",
        "    def __init__(self, rule_id, scenario, description, priority,",
        "                 condition, reference=''):",
        "        self.rule_id     = rule_id",
        "        self.scenario    = scenario",
        "        self.description = description",
        "        self.priority    = priority",
        "        self.condition   = condition",
        "        self.reference   = reference",
        "",
        "    def evaluate(self, data):",
        "        try:",
        "            return self.condition(data)",
        "        except Exception:",
        "            return False",
        "",
        "",
        "def val(data, key):",
        "    value = data.get(key)",
        "    if isinstance(value, str):",
        "        return value.strip().upper()",
        "    return value",
        "",
        "",
        f"{var_name}: List[Rule] = [",
    ]

    for rule in rules:
        rule_id     = rule["rule_id"]
        description = rule["description"]
        priority    = rule.get("priority", 99)
        groups      = rule.get("groups", [])
        group_op    = rule.get("group_operator", "OR")

        condition_code = build_condition_code(groups, group_op)
        reference      = build_reference_string(groups, group_op)

        lines += [
            f"    # {rule_id} — {description}",
            f"    Rule(",
            f"        rule_id     = \"{rule_id}\",",
            f"        scenario    = \"{scenario_upper}\",",
            f"        description = \"{description}\",",
            f"        priority    = {priority},",
            f"        condition   = lambda r: {condition_code},",
            f"        reference   = \"{reference}\"",
            f"    ),",
            "",
        ]

    lines += [
        "]",
        "",
        "",
        "RULE_MAP = {",
        f"    \"{scenario_upper}\": {var_name}",
        "}",
        "",
        "",
        "def evaluate_rules(scenario: str, data: Dict[str, Any]) -> Dict[str, Any]:",
        "    scenario = scenario.upper()",
        "    rules    = RULE_MAP.get(scenario, [])",
        "    matched  = []",
        "",
        "    for rule in rules:",
        "        if rule.evaluate(data):",
        "            matched.append(rule)",
        "",
        "    matched = sorted(matched, key=lambda r: r.priority)",
        "",
        "    if not matched:",
        "        return {",
        "            \"primary_rule\":  None,",
        "            \"decision\":      \"No rule matched\",",
        "            \"matched_rules\": [],",
        "            \"reference\":     None",
        "        }",
        "",
        "    primary = matched[0]",
        "    return {",
        "        \"primary_rule\":  primary.rule_id,",
        "        \"decision\":      primary.description,",
        "        \"matched_rules\": [r.rule_id for r in matched],",
        "        \"reference\":     primary.reference",
        "    }",
    ]

    return "\n".join(lines)


# =============================================================
# PROPERTIES FILE GENERATOR
# =============================================================

def generate_properties(config):
    """Generates .properties file content from config dict."""
    lines = [
        f"# Auto-generated by Vi-Ky-Pedia Admin — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "# Database",
        f"db.user={config.get('db_user', '')}",
        f"db.password={config.get('db_password', '')}",
        f"db.dsn={config.get('db_dsn', '')}",
        "",
        "# LLM",
        f"llm.enabled={config.get('llm_enabled', 'true')}",
        f"llm.model={config.get('llm_model', 'llama3.2:3b')}",
        f"llm.url={config.get('llm_url', '')}",
        "",
        "# Embedding",
        f"embedding.url={config.get('embedding_url', '')}",
        f"embedding.model={config.get('embedding_model', 'nomic-embed-text:v1.5')}",
    ]
    return "\n".join(lines)


# =============================================================
# INLINE RAG INDEXER (fallback when index_rag.py not found)
# =============================================================

def _run_inline_indexer(app_key, scenario_key, sop_path, vector_path):
    """
    Runs RAG indexing directly in-process using the RAG engine.
    Used as fallback when external indexer script is not found.
    """
    try:
        # Read properties to get embedding config
        app_folder = app_key.lower()
        props_path = os.path.join(APPS_DIR, f"{app_folder}.properties")

        embed_url   = None
        embed_model = "nomic-embed-text:v1.5"

        if os.path.exists(props_path):
            with open(props_path) as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("embedding.url="):
                        embed_url = line.split("=", 1)[1].strip()
                    elif line.startswith("embedding.model="):
                        embed_model = line.split("=", 1)[1].strip()

        if not embed_url:
            return False, "Embedding URL not configured in properties file — cannot index RAG"

        import requests
        import re
        import math

        def embed_text(text):
            resp = requests.post(
                embed_url,
                json={"model": embed_model, "prompt": text},
                timeout=120
            )
            resp.raise_for_status()
            return resp.json()["embedding"]

        # Parse SOP document into chunks
        with open(sop_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        vectors          = []
        current_scenario = scenario_key.upper()
        current_section  = None
        buffer           = []
        chunk_counter    = 1

        for line in lines:
            stripped = line.strip()

            # Detect scenario headers
            for scen_name in ["UNBLOCK", "FRC", "REFUND", "CAF", "PAYMENT"]:
                if scen_name in stripped.upper() and "SOP" in stripped.upper():
                    current_scenario = scen_name
                    break

            # Detect numbered section like 1.1, 1.2
            match = re.match(r"^\d+\.\d+\s+(.+)", stripped)
            if match:
                if buffer and current_section:
                    chunk_text = "\n".join(buffer)
                    embedding  = embed_text(chunk_text)
                    vectors.append({
                        "chunk_id":  f"CHUNK_{chunk_counter}",
                        "section":   current_section,
                        "scenario":  current_scenario,
                        "text":      chunk_text,
                        "embedding": embedding
                    })
                    chunk_counter += 1
                    buffer = []
                current_section = stripped
                continue

            if stripped.startswith("=") or stripped.startswith("SECTION"):
                continue

            if stripped:
                buffer.append(stripped)

        # Save last chunk
        if buffer and current_section:
            chunk_text = "\n".join(buffer)
            embedding  = embed_text(chunk_text)
            vectors.append({
                "chunk_id":  f"CHUNK_{chunk_counter}",
                "section":   current_section,
                "scenario":  current_scenario,
                "text":      chunk_text,
                "embedding": embedding
            })

        import json as json_mod
        with open(vector_path, "w", encoding="utf-8") as f:
            json_mod.dump(vectors, f, indent=2)

        logger.info(f"Inline RAG indexed: {len(vectors)} chunks → {vector_path}")
        return True, f"RAG indexed inline — {len(vectors)} chunks created"

    except Exception as e:
        logger.error(f"Inline indexer error: {e}", exc_info=True)
        return False, f"Inline RAG indexer failed: {str(e)}"


# =============================================================
# RAG INDEXER
# =============================================================

def run_rag_indexer(app_key, scenario_key, sop_text):
    """
    Writes SOP text to file and rebuilds LlamaIndex.
    Called by Admin panel after SOP is saved.
    Returns (success, message)
    """
    app_folder = app_key.lower()
    scen_lower = scenario_key.lower()
    app_dir    = os.path.join(APPS_DIR, app_folder)
    sop_path   = os.path.join(app_dir, f"rag_documents_{scen_lower}.txt")
    vector_path = os.path.join(app_dir, f"rag_vectors_{scen_lower}.json")

    # Step 1: Write updated SOP text to file
    os.makedirs(app_dir, exist_ok=True)
    with open(sop_path, "w", encoding="utf-8") as f:
        f.write(sop_text)
    logger.info(f"SOP saved: {sop_path}")

    # Step 2: Get embedding config from properties file
    props_path = os.path.join(APPS_DIR, f"{app_folder}.properties")
    # For multi-zone apps (SCRM) properties are inside the app folder
    if not os.path.exists(props_path):
        props_path = os.path.join(app_dir, f"{app_folder}_zone1.properties")

    embed_url   = None
    embed_model = "nomic-embed-text:v1.5"

    if os.path.exists(props_path):
        with open(props_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("embedding.url="):
                    embed_url = line.split("=", 1)[1].strip()
                elif line.startswith("embedding.model="):
                    embed_model = line.split("=", 1)[1].strip()

    if not embed_url:
        return False, "embedding.url not found in properties file — cannot rebuild RAG index"

    # Step 3: Rebuild LlamaIndex using RAGEngine.rebuild()
    try:
        sys.path.insert(0, AGENT_DIR)
        from rag_engine import RAGEngine

        engine = RAGEngine(
            sop_file    = sop_path,
            embed_url   = embed_url,
            embed_model = embed_model,
            vector_file = vector_path,
        )
        engine.rebuild()

        logger.info(f"LlamaIndex rebuilt: {engine.persist_dir}")
        return True, f"RAG index rebuilt successfully → {engine.persist_dir}"

    except Exception as e:
        logger.error(f"RAG rebuild error: {e}", exc_info=True)
        return False, f"RAG rebuild failed: {str(e)}"


# =============================================================
# KEYWORD UPDATER
# =============================================================

def update_scenario_keywords(app_key, scenario_key, keywords):
    """
    Updates SCENARIO_KEYWORDS in global_csv_processor.py (batch).
    """
    processor_path = os.path.join(BASE_DIR, "global_csv_processor.py")

    with open(processor_path, "r") as f:
        content = f.read()

    scenario_upper = scenario_key.upper()
    kw_list        = json.dumps(keywords)

    # Check if scenario already exists in keywords dict
    if f'"{scenario_upper}":' in content:
        logger.info(f"Keywords for {scenario_upper} already exist — skipping")
        return True

    # Add new scenario keywords before closing brace of SCENARIO_KEYWORDS
    new_entry = f'\n    "{scenario_upper}": {kw_list},\n'

    replaced = False
    for pattern in [
        "}\n\n\ndef matches_scenario_keywords",
        "}\n\ndef matches_scenario_keywords",
        "}\n\n\n\ndef matches_scenario_keywords",
    ]:
        if pattern in content:
            content = content.replace(pattern, new_entry + pattern)
            replaced = True
            break

    if not replaced:
        import re
        match = re.search(r'(SCENARIO_KEYWORDS\s*=\s*\{.*?\})', content, re.DOTALL)
        if match:
            old_block = match.group(1)
            new_block = old_block.rstrip('}') + new_entry + '}'
            content   = content.replace(old_block, new_block)
            replaced  = True

    if not replaced:
        logger.warning(f"Could not add keywords for {scenario_upper} — pattern not found")
        return False

    with open(processor_path, "w") as f:
        f.write(content)

    logger.info(f"Keywords added for {scenario_upper}")
    return True


# =============================================================
# BATCH PROCESSOR APP FOLDER MAP UPDATER
# =============================================================

def update_app_folder_map(app_key):
    """
    Adds app_key to APP_FOLDER_MAP in batch_processor.py.
    """
    processor_path = os.path.join(BATCH_DIR, "batch_processor.py")

    with open(processor_path, "r") as f:
        content = f.read()

    app_folder = app_key.lower()
    app_upper  = app_key.upper()

    # Already exists?
    if f'"{app_folder}":' in content:
        logger.info(f"App {app_folder} already in APP_FOLDER_MAP")
        return True

    new_entry = f'    "{app_folder}":     "{app_upper}",\n'

    replaced = False
    for pattern in [
        "}\n\n# Polling interval",
        "}\n# Polling interval",
        "}\n\n\n# Polling interval",
    ]:
        if pattern in content:
            content = content.replace(pattern, new_entry + pattern)
            replaced = True
            break

    if not replaced:
        import re
        match = re.search(r'(APP_FOLDER_MAP\s*=\s*\{.*?\})', content, re.DOTALL)
        if match:
            old_block = match.group(1)
            new_block = old_block.rstrip('}') + new_entry + '}'
            content   = content.replace(old_block, new_block)
            replaced  = True

    if not replaced:
        logger.warning(f"Could not add {app_folder} to APP_FOLDER_MAP — pattern not found")
        return False

    with open(processor_path, "w") as f:
        f.write(content)

    logger.info(f"App {app_folder} added to APP_FOLDER_MAP")
    return True


# =============================================================
# FOLDER CREATOR
# =============================================================

def create_app_folders(app_key):
    """Creates input/output/processed/failed folders for the app."""
    app_folder = app_key.lower()
    for base in ["input", "output", "processed", "failed"]:
        path = os.path.join(BATCH_DIR, base, app_folder)
        os.makedirs(path, exist_ok=True)
        logger.info(f"Folder created: {path}")


# =============================================================
# REGISTRY UPDATER
# =============================================================

def update_registry(app_key, scenario_key, app_folder, scen_lower):
    """Adds or updates app/scenario entry in apps_registry.yaml."""
    registry   = load_registry()
    app_upper  = app_key.upper()
    scen_upper = scenario_key.upper()

    if app_upper not in registry:
        registry[app_upper] = {
            "display_name": app_upper,
            "db_config":    f"apps/{app_folder}.properties",
            "scenarios":    {}
        }

    # Ensure scenarios key exists (handles migration from flat format)
    if "scenarios" not in registry[app_upper]:
        registry[app_upper]["scenarios"] = {}

    registry[app_upper]["scenarios"][scen_upper] = {
        "display_name":  scen_upper,
        "query_file":    f"apps/{app_folder}/{scen_lower}.sql",
        "sop_file":      f"apps/{app_folder}/rag_documents_{scen_lower}.txt",
        "vector_file":   f"apps/{app_folder}/rag_vectors_{scen_lower}.json",
        "rules_module":  f"apps.{app_folder}.rules_engine_{scen_lower}",
        "rules_scenario": scen_upper,
    }

    save_registry(registry)
    logger.info(f"Registry updated: {app_upper}/{scen_upper}")


# =============================================================
# MAIN ONBOARDING FUNCTION
# =============================================================

def onboard_app(payload):
    """
    Full onboarding pipeline.

    payload = {
        "app_key": "COLLECTIONS",
        "db_user": "...", "db_password": "...", "db_dsn": "...",
        "llm_enabled": "true", "llm_model": "...",
        "llm_url": "...", "embedding_url": "...", "embedding_model": "...",
        "scenarios": [
            {
                "scenario_key": "PAYMENT_FOLLOWUP",
                "keywords": ["payment", "followup", "due"],
                "sql": "SELECT ... FROM ...",
                "sop": "Section 1.1 ...",
                "rules": [ ... ]
            }
        ]
    }

    Returns {"success": True/False, "steps": [...], "errors": [...]}
    """
    steps  = []
    errors = []

    app_key    = payload["app_key"].upper().replace(" ", "_")
    app_folder = app_key.lower()
    app_dir    = os.path.join(APPS_DIR, app_folder)

    # ── Validate required fields before starting ──────────────
    validation_errors = []
    if not payload.get("db_user"):
        validation_errors.append("DB User is required")
    if not payload.get("db_dsn"):
        validation_errors.append("DB DSN is required")
    if not payload.get("llm_url"):
        validation_errors.append("LLM URL is required — e.g. http://10.94.92.10:11434/api/generate")
    if not payload.get("embedding_url"):
        validation_errors.append("Embedding URL is required — e.g. http://10.94.92.10:11434/api/embeddings")
    if not payload.get("scenarios"):
        validation_errors.append("At least one scenario is required")
    else:
        for scen in payload["scenarios"]:
            if not scen.get("scenario_key"):
                validation_errors.append("All scenarios must have a Scenario Key")
            if not scen.get("keywords"):
                validation_errors.append(f"Scenario '{scen.get('scenario_key','?')}' must have at least one keyword")
            if not scen.get("sql"):
                validation_errors.append(f"Scenario '{scen.get('scenario_key','?')}' must have a SQL query")
            if not scen.get("sop"):
                validation_errors.append(f"Scenario '{scen.get('scenario_key','?')}' must have SOP content for RAG indexing")

    if validation_errors:
        return {
            "success": False,
            "app_key": app_key,
            "steps":   ["✘ Validation failed — please fix the following:"] + [f"  • {e}" for e in validation_errors],
            "errors":  validation_errors
        }

    try:
        # ── Step 1: Create app directory ──────────────────────
        os.makedirs(app_dir, exist_ok=True)
        steps.append(f"✔ App directory created: apps/{app_folder}/")

        # ── Step 2: Write .properties file ────────────────────
        props_content = generate_properties(payload)
        props_path    = os.path.join(APPS_DIR, f"{app_folder}.properties")
        with open(props_path, "w") as f:
            f.write(props_content)
        steps.append(f"✔ Properties file created: apps/{app_folder}.properties")

        # ── Step 3: Create batch input/output folders ──────────
        create_app_folders(app_key)
        steps.append(f"✔ Batch folders created: input/output/processed/failed/{app_folder}/")

        # ── Step 4: Update APP_FOLDER_MAP in batch_processor ──
        update_app_folder_map(app_key)
        steps.append(f"✔ batch_processor.py updated with {app_folder}")

        # ── Step 5: Process each scenario ─────────────────────
        meta_scenarios = {}

        for scen in payload.get("scenarios", []):
            scenario_key = scen["scenario_key"].upper().replace(" ", "_")
            scen_lower   = scenario_key.lower()
            keywords     = scen.get("keywords", [])
            sql_content  = scen.get("sql", "")
            sop_content  = scen.get("sop", "")
            rules        = scen.get("rules", [])

            steps.append(f"  ── Scenario: {scenario_key} ──")

            # SQL file
            sql_path = os.path.join(app_dir, f"{scen_lower}.sql")
            with open(sql_path, "w") as f:
                f.write(sql_content)
            steps.append(f"  ✔ SQL file created: apps/{app_folder}/{scen_lower}.sql")

            # Rules engine
            rules_content = generate_rules_engine(app_key, scenario_key, rules)
            rules_path    = os.path.join(app_dir, f"rules_engine_{scen_lower}.py")
            with open(rules_path, "w") as f:
                f.write(rules_content)

            # Create __init__.py if missing
            init_path = os.path.join(app_dir, "__init__.py")
            if not os.path.exists(init_path):
                open(init_path, "w").close()

            steps.append(f"  ✔ Rules engine created: {len(rules)} rules")

            # Keywords
            update_scenario_keywords(app_key, scenario_key, keywords)
            steps.append(f"  ✔ Keywords added: {keywords}")

            # Registry
            update_registry(app_key, scenario_key, app_folder, scen_lower)
            steps.append(f"  ✔ Registry updated")

            # RAG indexing
            if sop_content.strip():
                ok, msg = run_rag_indexer(app_key, scenario_key, sop_content)
                if ok:
                    steps.append(f"  ✔ RAG indexed: {msg}")
                else:
                    errors.append(f"  ⚠ RAG indexing failed: {msg}")
                    steps.append(f"  ⚠ RAG skipped — {msg}")
            else:
                steps.append(f"  ⚠ No SOP content — RAG skipped")

            # Store scenario meta for admin_meta.json
            meta_scenarios[scenario_key] = {
                "keywords": keywords,
                "rules":    rules
            }

        # ── Step 6: Save admin_meta.json ───────────────────────
        meta = {
            "app_key":    app_key,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "created_by": "Vi-Ky-Pedia Admin",
            "scenarios":  meta_scenarios
        }
        meta_path = os.path.join(app_dir, "admin_meta.json")
        with open(meta_path, "w") as f:
            json.dump(meta, f, indent=2)
        steps.append(f"✔ Admin metadata saved")

        steps.append(f"✔ App '{app_key}' onboarded successfully!")

        return {
            "success": True,
            "app_key": app_key,
            "steps":   steps,
            "errors":  errors
        }

    except Exception as e:
        logger.error(f"Onboarding error: {e}", exc_info=True)
        errors.append(str(e))
        return {
            "success": False,
            "app_key": app_key,
            "steps":   steps,
            "errors":  errors
        }


# =============================================================
# UPDATE SCENARIO (add rules/keywords to existing managed app)
# =============================================================

def update_scenario_rules(app_key, scenario_key, rules):
    """Updates rules for a managed scenario."""
    app_folder = app_key.lower()
    scen_lower = scenario_key.lower()
    app_dir    = os.path.join(APPS_DIR, app_folder)
    rules_path = os.path.join(app_dir, f"rules_engine_{scen_lower}.py")

    rules_content = generate_rules_engine(app_key, scenario_key, rules)
    with open(rules_path, "w") as f:
        f.write(rules_content)

    # Update meta
    meta_path = os.path.join(app_dir, "admin_meta.json")
    if os.path.exists(meta_path):
        with open(meta_path) as f:
            meta = json.load(f)
        meta["scenarios"].setdefault(scenario_key.upper(), {})["rules"] = rules
        meta["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(meta_path, "w") as f:
            json.dump(meta, f, indent=2)

    logger.info(f"Rules updated: {app_key}/{scenario_key}")
    return True

