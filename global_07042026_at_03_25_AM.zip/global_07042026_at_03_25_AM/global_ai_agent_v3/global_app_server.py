# =============================================================
# global_app_server.py
# Web server — dynamic dropdown + live progress streaming + Admin Panel
#
# v3 changes:
#   - Passwords loaded from environment variables (no hardcoding)
#   - Hardcoded dashboard IP removed — reads hostname dynamically
# =============================================================

import os
import re
import cgi
import json
import queue
import shutil
import signal
import secrets
import hashlib
import subprocess
import threading
import tempfile
import uuid
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler

from app_registry import get_all_apps, get_scenarios_for_app
from csv_processor import process_csv

PORT       = 8010
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(BASE_DIR, "admin", "backup")
os.makedirs(BACKUP_DIR, exist_ok=True)

# =============================================================
# USER CONFIG — loaded from environment variables
#
# Set these before starting the server:
#   export AGENT_USER_ADMIN=your_hashed_password
#   export AGENT_USER_MUJAFFAR=your_hashed_password
#
# To generate a hash:
#   python3 -c "import hashlib; print(hashlib.sha256('yourpassword'.encode()).hexdigest())"
#
# Fallback: if env var not set, that user simply won't exist.
# =============================================================

def _hash(pw):
    return hashlib.sha256(pw.encode()).hexdigest()


def _load_users():
    """
    Loads users from environment variables.
    Format: AGENT_USER_<USERNAME>=<sha256_hash>
    Example: AGENT_USER_ADMIN=abc123...
    """
    users = {}
    for key, value in os.environ.items():
        if key.startswith("AGENT_USER_") and value:
            username = key[len("AGENT_USER_"):].lower()
            users[username] = value  # value should already be a sha256 hash
    return users


USERS = _load_users()

if not USERS:
    # Safety fallback — warn loudly, do not silently allow blank login
    import sys
    print("=" * 60)
    print("WARNING: No AGENT_USER_* environment variables found.")
    print("No users can log in. Set at least one:")
    print("  export AGENT_USER_ADMIN=$(python3 -c \"import hashlib; print(hashlib.sha256('yourpassword'.encode()).hexdigest())\")")
    print("=" * 60)

# Active sessions: token -> username
_sessions      = {}
_sessions_lock = threading.Lock()

SOPS_DIR  = os.path.join(BASE_DIR, "sops")
RULES_DIR = os.path.join(BASE_DIR, "rules")


# =============================================================
# SESSION HELPERS
# =============================================================
def _create_session(username):
    token = secrets.token_hex(32)
    with _sessions_lock:
        _sessions[token] = username
    return token


def _get_session(cookie_header):
    """Extract username from session cookie, or None if not logged in."""
    if not cookie_header:
        return None
    for part in cookie_header.split(";"):
        part = part.strip()
        if part.startswith("session="):
            token = part[len("session="):]
            with _sessions_lock:
                return _sessions.get(token)
    return None


def _destroy_session(cookie_header):
    if not cookie_header:
        return
    for part in cookie_header.split(";"):
        part = part.strip()
        if part.startswith("session="):
            token = part[len("session="):]
            with _sessions_lock:
                _sessions.pop(token, None)


def get_editable_files():
    """Dynamically build editable files map from sops/ and rules/ folders."""
    files = {}

    if os.path.isdir(SOPS_DIR):
        for fn in sorted(os.listdir(SOPS_DIR)):
            if fn.endswith(".txt"):
                files[f"sops/{fn}"] = os.path.join(SOPS_DIR, fn)

    if os.path.isdir(RULES_DIR):
        for fn in sorted(os.listdir(RULES_DIR)):
            if fn.endswith(".py") and not fn.startswith("__"):
                files[f"rules/{fn}"] = os.path.join(RULES_DIR, fn)

    return files


SERVICES = {
    "Module_Installation.sh":  os.path.join(BASE_DIR, "Module_Installation.sh"),
    "start_app_ai_RAG_NEW.sh": os.path.join(BASE_DIR, "start_app_ai_RAG_NEW.sh"),
    "Index_SOP_Creator.sh":    os.path.join(BASE_DIR, "Index_SOP_Creator.sh"),
}

_progress_queues = {}
_progress_lock   = threading.Lock()


# =============================================================
# ADMIN API HELPERS
# =============================================================

def _get_running_pid(script_name):
    try:
        result = subprocess.run(
            ["pgrep", "-f", script_name],
            capture_output=True, text=True
        )
        pids = result.stdout.strip().split()
        return int(pids[0]) if pids else None
    except Exception:
        return None


def _api_get_services():
    svcs = []
    for name in SERVICES:
        pid = _get_running_pid(name)
        svcs.append({"name": name, "running": pid is not None, "pid": pid})
    return {"services": svcs}


def _api_service_action(body):
    action = body.get("action")
    name   = body.get("name")
    if name not in SERVICES:
        return {"ok": False, "error": f"Unknown service: {name}"}

    script_path = SERVICES[name]

    if action == "start":
        if not os.path.exists(script_path):
            return {"ok": False, "error": f"Script not found: {script_path}"}
        proc = subprocess.Popen(
            ["bash", script_path],
            cwd=BASE_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return {"ok": True, "pid": proc.pid,
                "msg": f"Started {name} with PID {proc.pid}"}

    elif action == "stop":
        pid = _get_running_pid(name)
        if not pid:
            return {"ok": False, "error": "Service not running"}
        try:
            os.kill(pid, signal.SIGKILL)
            return {"ok": True, "msg": f"Stopped {name} (PID {pid})"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    return {"ok": False, "error": "Unknown action"}


def _resolve_filename(name):
    files = get_editable_files()
    if name in files:
        return name, files[name]
    for k, v in files.items():
        if os.path.basename(k) == name or os.path.basename(k) == os.path.basename(name):
            return k, v
    return None, None


def _api_get_file(name):
    key, path = _resolve_filename(name)
    if not path or not os.path.exists(path):
        return {"ok": False, "error": f"File not found: {name}"}
    with open(path, "r", encoding="utf-8") as f:
        return {"ok": True, "content": f.read(), "resolved": key}


def _api_save_file(name, content):
    key, path = _resolve_filename(name)
    if not path:
        return {"ok": False, "error": f"Unknown file: {name}. Available: {list(get_editable_files().keys())}"}

    ts     = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe   = (key or name).replace("/", "_")
    bkname = f"{ts}_{safe}"
    bkpath = os.path.join(BACKUP_DIR, bkname)
    if os.path.exists(path):
        shutil.copy2(path, bkpath)

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    reload_ok  = False
    reload_msg = "File saved. Restart server or re-index to apply changes."
    if name.endswith(".py"):
        try:
            module_name = "rules." + os.path.splitext(os.path.basename(name))[0]
            import importlib
            mod = importlib.import_module(module_name)
            importlib.reload(mod)
            reload_ok  = True
            reload_msg = f"Saved & hot-reloaded {module_name} successfully."
        except Exception as e:
            reload_msg = f"Saved but reload failed: {e}"
    elif name.endswith(".txt"):
        reload_msg = "SOP saved. Run Index_SOP_Creator.sh to rebuild RAG vectors."

    return {"ok": True, "backup": bkname,
            "reload_ok": reload_ok, "reload_msg": reload_msg}


def _api_get_backups():
    bks = []
    for fn in sorted(os.listdir(BACKUP_DIR), reverse=True):
        fp = os.path.join(BACKUP_DIR, fn)
        ct = datetime.fromtimestamp(os.path.getctime(fp)).strftime("%Y-%m-%d %H:%M:%S")
        parts = fn.split("_", 2)
        original = parts[2] if len(parts) >= 3 else fn
        bks.append({"filename": fn, "original": original, "created": ct})
    return {"backups": bks}


def _api_restore_backup(name):
    path = os.path.join(BACKUP_DIR, name)
    if not os.path.exists(path):
        return {"ok": False, "error": "Backup not found"}
    with open(path, "r", encoding="utf-8") as f:
        return {"ok": True, "content": f.read()}


def _get_dashboard_url():
    """Build dashboard URL dynamically — no hardcoded IPs."""
    try:
        import socket
        hostname = socket.gethostbyname(socket.gethostname())
    except Exception:
        hostname = "10.94.240.150"
    return f"http://{hostname}:8011/"


def build_html(username=""):
    all_apps          = get_all_apps()
    scenario_map      = {k: get_scenarios_for_app(k) for k in all_apps}
    scenario_map_json = json.dumps(scenario_map)

    app_options_html = "\n".join(
        f'<option value="{k}">{v}</option>' for k, v in all_apps.items()
    )
    first_app = list(all_apps.keys())[0]
    scenario_options_html = "\n".join(
        f'<option value="{k}">{v}</option>'
        for k, v in get_scenarios_for_app(first_app).items()
    )
    user_badge = f'''
    <div style="display:flex;align-items:center;gap:10px;">
      <span style="background:rgba(255,255,255,0.2);color:#fff;font-size:12px;font-weight:600;
                   padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.35);">
        &#128100; {username}
      </span>
      <a href="/logout" style="text-decoration:none;">
        <span style="background:rgba(255,255,255,0.15);color:#fff;font-size:12px;font-weight:600;
                     padding:5px 12px;border-radius:20px;border:1px solid rgba(255,255,255,0.25);
                     cursor:pointer;">&#10006; Logout</span>
      </a>
    </div>''' if username else ""

    dashboard_url = _get_dashboard_url()

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Digital AI Ticket Analyzer</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:"Segoe UI",Arial,sans-serif;background:linear-gradient(135deg,#f0f4f8,#e8edf2);min-height:100vh}}
  .header{{background:linear-gradient(90deg,#e60000,#b30000);color:#fff;padding:16px 32px;
           display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(0,0,0,.18)}}
  .header-title{{font-size:26px;font-weight:800;letter-spacing:1px;flex:1;text-align:center}}
  .header-sub{{font-size:13px;opacity:.85;text-align:center;margin-top:2px}}
  .logo{{height:60px;object-fit:contain}}
  .container{{max-width:860px;margin:40px auto;padding:0 20px}}
  .card{{background:#fff;border-radius:14px;box-shadow:0 8px 28px rgba(0,0,0,.09);padding:36px 40px;margin-bottom:24px}}
  .card-title{{font-size:20px;font-weight:700;color:#333;margin-bottom:6px}}
  .card-subtitle{{font-size:14px;color:#888;margin-bottom:28px}}
  .form-group{{margin-bottom:22px}}
  label{{display:block;font-weight:600;font-size:14px;color:#444;margin-bottom:7px}}
  select,input[type="file"]{{width:100%;padding:11px 14px;border:1.5px solid #ddd;border-radius:8px;
    font-size:14px;color:#333;background:#fafafa;cursor:pointer}}
  select:focus,input[type="file"]:focus{{outline:none;border-color:#e60000}}
  .badge{{display:inline-block;background:#fff4f4;color:#e60000;border:1px solid #ffcccc;
          border-radius:20px;padding:3px 12px;font-size:12px;font-weight:600;margin-bottom:18px}}
  button{{width:100%;padding:14px;background:linear-gradient(90deg,#e60000,#cc0000);color:#fff;
          border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;margin-top:8px}}
  button:hover{{background:linear-gradient(90deg,#c00,#900)}}
  button:disabled{{background:#ccc;cursor:not-allowed}}
  hr.divider{{border:none;border-top:1.5px solid #f0f0f0;margin:24px 0}}
  .info-row{{display:flex;gap:16px;margin-top:20px}}
  .info-box{{flex:1;background:#f8f9fb;border-radius:8px;padding:14px 16px;font-size:13px;
             color:#666;border-left:3px solid #e60000}}
  .info-box strong{{color:#333;display:block;margin-bottom:3px}}

  #progressPanel{{display:none}}
  .progress-header{{display:flex;align-items:center;gap:10px;margin-bottom:14px}}
  .progress-title{{font-size:16px;font-weight:700;color:#333}}
  .pulse{{width:10px;height:10px;border-radius:50%;background:#e60000;animation:pulse 1.2s infinite}}
  @keyframes pulse{{0%,100%{{opacity:1;transform:scale(1)}}50%{{opacity:.4;transform:scale(.7)}}}}
  .progress-bar-wrap{{background:#f0f0f0;border-radius:20px;height:10px;margin-bottom:16px;overflow:hidden}}
  .progress-bar{{height:100%;border-radius:20px;background:linear-gradient(90deg,#e60000,#ff6b6b);
                 width:0%;transition:width .4s ease}}
  .stat-row{{display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap}}
  .stat-box{{flex:1;min-width:120px;background:#f8f9fb;border-radius:8px;padding:10px 14px;
             text-align:center;border-top:3px solid #e60000}}
  .stat-num{{font-size:22px;font-weight:800;color:#e60000}}
  .stat-label{{font-size:11px;color:#888;margin-top:2px}}
  #logBox{{background:#1a1a2e;color:#00ff88;font-family:"Courier New",monospace;font-size:12px;
           border-radius:8px;padding:14px;height:300px;overflow-y:auto;line-height:1.6}}
  .log-row{{color:#adf;font-weight:600}}
  .log-db{{color:#ffd700}}
  .log-rag{{color:#87ceeb}}
  .log-llm{{color:#ff9f43}}
  .log-done{{color:#00ff88;font-weight:700}}
  .log-err{{color:#ff6b6b}}
  .log-info{{color:#ccc}}
  .log-prompt_head{{color:#e60000;font-weight:700;letter-spacing:1px}}
  .log-prompt_line{{color:#d0d0d0;padding-left:12px;font-size:11px}}
  .log-llm_resp{{color:#ff9f43;font-weight:600}}
  .log-narrative{{color:#98fb98;font-style:italic}}
  footer{{text-align:center;margin-top:24px;font-size:13px;color:#aaa;padding-bottom:30px}}
</style>
</head>
<body>
<div class="header">
  <img src="/static/logo_right.png"  class="logo" onerror="this.style.display='none'">
  <div>
    <div class="header-title">Digital AI Ticket Analyzer</div>
    <div class="header-sub">Vi-Ky-Pedia</div>
  </div>
  <div style="display:flex;align-items:center;gap:10px;">
    <a href="/admin" target="_blank" style="text-decoration:none;">
      <span style="background:rgba(255,255,255,0.2);color:#fff;font-size:13px;font-weight:700;
                   padding:7px 16px;border-radius:20px;border:1px solid rgba(255,255,255,0.4);
                   display:flex;align-items:center;gap:6px;cursor:pointer;letter-spacing:.3px;">
        &#9881; Admin
      </span>
    </a>
    <a href="{dashboard_url}" target="_blank" style="text-decoration:none;">
      <span style="background:rgba(255,255,255,0.2);color:#fff;font-size:13px;font-weight:700;
                   padding:7px 16px;border-radius:20px;border:1px solid rgba(255,255,255,0.4);
                   display:flex;align-items:center;gap:6px;cursor:pointer;letter-spacing:.3px;">
        &#9881; Batch Processor
      </span>
    </a>
    {user_badge}
    <img src="/static/logo_right.png" class="logo" onerror="this.style.display='none'">
  </div>
</div>

<div class="container">
  <div class="card" id="uploadCard">
    <div class="card-title">Analyze Support Tickets</div>
    <div class="card-subtitle">Select application, scenario, upload CSV &rarr; get AI-enriched Excel report</div>
    <span class="badge">&bull; {len(all_apps)} App(s) Configured</span>
    <div class="form-group">
      <label>Application</label>
      <select id="appSelect" onchange="updateScenarios()">
        {app_options_html}
      </select>
    </div>
    <div class="form-group">
      <label>Scenario</label>
      <select id="scenarioSelect">
        {scenario_options_html}
      </select>
    </div>
    <hr class="divider">
    <div class="form-group">
      <label>Upload Ticket CSV File</label>
      <input type="file" id="csvFile" accept=".csv" required>
    </div>
    <button id="runBtn" onclick="startAnalysis()">&#9654; Run AI Analysis</button>
    <div class="info-row">
      <div class="info-box">
        <strong>What happens?</strong>
        Tickets matched to DB records, rules engine applied, RAG SOP context retrieved, LLM generates decision.
      </div>
      <div class="info-box">
        <strong>Output</strong>
        Styled Excel with AI_Primary_Rule, AI_Action, AI_Status, AI_Narrative, AI_Confidence columns added.
      </div>
    </div>
  </div>

  <div class="card" id="progressPanel">
    <div class="progress-header">
      <div class="pulse" id="pulseIcon"></div>
      <div class="progress-title" id="progressTitle">Processing tickets...</div>
      <button id="togglePrompts" onclick="togglePromptView()"
        style="width:auto;padding:6px 14px;font-size:12px;margin:0;margin-left:auto;background:#333;border-radius:6px">
        👁 Show Prompts
      </button>
    </div>
    <div class="progress-bar-wrap">
      <div class="progress-bar" id="progressBar"></div>
    </div>
    <div class="stat-row">
      <div class="stat-box"><div class="stat-num" id="statTotal">0</div><div class="stat-label">Total Rows</div></div>
      <div class="stat-box"><div class="stat-num" id="statDone">0</div><div class="stat-label">Processed</div></div>
      <div class="stat-box"><div class="stat-num" id="statPct">0%</div><div class="stat-label">Complete</div></div>
      <div class="stat-box"><div class="stat-num" id="statElapsed">0s</div><div class="stat-label">Elapsed</div></div>
    </div>
    <div id="logBox"><span class="log-info">Waiting for server...</span></div>
  </div>
</div>

<footer>Global AI Ticket Analyzer v3 &nbsp;|&nbsp; Internal Use Only</footer>

<script>
const scenarioMap = {scenario_map_json};
function updateScenarios(){{
  const appKey=document.getElementById("appSelect").value;
  const sel=document.getElementById("scenarioSelect");
  sel.innerHTML="";
  Object.entries(scenarioMap[appKey]||{{}}).forEach(([k,v])=>{{
    const o=document.createElement("option");o.value=k;o.text=v;sel.appendChild(o);
  }});
}}
let elapsedTimer=null;
function startAnalysis(){{
  const fileInput=document.getElementById("csvFile");
  if(!fileInput.files.length){{alert("Please select a CSV file.");return;}}
  const appKey=document.getElementById("appSelect").value;
  const scenarioKey=document.getElementById("scenarioSelect").value;
  const file=fileInput.files[0];
  document.getElementById("progressPanel").style.display="block";
  document.getElementById("runBtn").disabled=true;
  document.getElementById("runBtn").textContent="⏳ Processing...";
  document.getElementById("progressTitle").textContent="Processing: "+appKey+" / "+scenarioKey;
  document.getElementById("logBox").innerHTML="";
  appendLog("info","Uploading "+file.name+" ...");
  const startTime=Date.now();
  elapsedTimer=setInterval(()=>{{
    document.getElementById("statElapsed").textContent=Math.floor((Date.now()-startTime)/1000)+"s";
  }},1000);
  const fd=new FormData();
  fd.append("app_key",appKey);
  fd.append("scenario_key",scenarioKey);
  fd.append("file",file);
  let jobId=null;
  fetch("/upload",{{method:"POST",body:fd}})
    .then(r=>{{
      if(!r.ok) throw new Error("Server error "+r.status);
      jobId=r.headers.get("X-Job-Id");
      if(jobId) listenProgress(jobId);
      return r.blob();
    }})
    .then(blob=>{{
      clearInterval(elapsedTimer);
      appendLog("done","✅ Done! Downloading Excel...");
      document.getElementById("pulseIcon").style.background="#00c851";
      document.getElementById("progressTitle").textContent="✅ Complete!";
      document.getElementById("progressBar").style.width="100%";
      document.getElementById("runBtn").disabled=false;
      document.getElementById("runBtn").textContent="▶ Run AI Analysis";
      const url=URL.createObjectURL(blob);
      const a=document.createElement("a");
      a.href=url;a.download=appKey+"_"+scenarioKey+"_output.xlsx";a.click();
    }})
    .catch(err=>{{
      clearInterval(elapsedTimer);
      appendLog("err","❌ Error: "+err.message);
      document.getElementById("runBtn").disabled=false;
      document.getElementById("runBtn").textContent="▶ Run AI Analysis";
    }});
}}
function listenProgress(jobId){{
  const es=new EventSource("/progress?job_id="+jobId);
  es.onmessage=function(e){{
    const d=JSON.parse(e.data);
    if(d.type==="total"){{
      document.getElementById("statTotal").textContent=d.value;
      appendLog("info","Total rows: "+d.value);
    }} else if(d.type==="row"){{
      const pct=d.total>0?Math.round((d.done/d.total)*100):0;
      document.getElementById("statDone").textContent=d.done;
      document.getElementById("statPct").textContent=pct+"%";
      document.getElementById("progressBar").style.width=pct+"%";
      appendLog("row","Row "+d.done+"/"+d.total+" | Ticket: "+(d.ticket||"—")+" | MSISDN: "+(d.msisdn||"—")+" | Rule: "+(d.rule||"—"));
    }} else if(d.type==="db"){{
      appendLog("db","  ↳ DB: "+d.msg);
    }} else if(d.type==="rag"){{
      appendLog("rag","  ↳ RAG score: "+d.score+" → "+d.ref);
    }} else if(d.type==="llm"){{
      appendLog("llm","  ↳ LLM: "+d.msg);
    }} else if(d.type==="done"){{
      appendLog("done","✅ All rows processed.");
      es.close();
    }} else if(d.type==="error"){{
      appendLog("err","❌ "+d.msg);
      es.close();
    }} else if(d.type==="prompt_start"){{
      appendLog("prompt_head","━━━━ "+d.label+" ━━━━");
    }} else if(d.type==="prompt_line"){{
      appendLog("prompt_line", d.line);
    }} else if(d.type==="prompt_end"){{
      appendLog("prompt_head","━━━━ END PROMPT ━━━━");
    }} else if(d.type==="llm_response"){{
      appendLog("llm_resp","  ◀ LLM RESPONSE: "+d.msg);
    }} else if(d.type==="narrative_response"){{
      appendLog("narrative","  ◀ NARRATIVE: "+d.msg);
    }}
  }};
  es.onerror=function(){{es.close();}};
}}
function appendLog(cls,msg){{
  const box=document.getElementById("logBox");
  const line=document.createElement("div");
  line.className="log-"+cls;
  if(cls==="prompt_head"||cls==="prompt_line") line.classList.add("prompt-content");
  line.textContent="["+new Date().toLocaleTimeString()+"] "+msg;
  box.appendChild(line);
  box.scrollTop=box.scrollHeight;
}}

let showPrompts=false;
function togglePromptView(){{
  showPrompts=!showPrompts;
  document.getElementById("togglePrompts").textContent=showPrompts?"🙈 Hide Prompts":"👁 Show Prompts";
  document.querySelectorAll(".prompt-content").forEach(el=>{{
    el.style.display=showPrompts?"block":"none";
  }});
}}
</script>
</body>
</html>"""


def build_admin_html():
    admin_path = os.path.join(BASE_DIR, "static", "admin.html")
    with open(admin_path, "r", encoding="utf-8") as f:
        html = f.read()

    files = get_editable_files()
    sop_files   = {k: v for k, v in files.items() if k.startswith("sops/")}
    rules_files = {k: v for k, v in files.items() if k.startswith("rules/")}

    service_opts = "\n".join(
        f'<option value="{k}">{k}</option>' for k in SERVICES
    )
    html = re.sub(
        r'(<select[^>]+id="qs"[^>]*>).*?(</select>)',
        f'\\1\n<option value="">-- Select a service --</option>\n{service_opts}\n\\2',
        html, flags=re.DOTALL
    )

    sop_opts = "\n".join(
        f'<option value="{k}">{os.path.basename(k)}</option>'
        for k in sop_files
    )
    rules_opts = "\n".join(
        f'<option value="{k}">{os.path.basename(k)}</option>'
        for k in rules_files
    )

    sop_selector = f'''
<div style="margin-bottom:10px;">
  <label style="font-size:12px;font-weight:600;color:#6c757d;">Select SOP File</label>
  <select id="sop-file-select" onchange="switchFile('txt', this.value)"
    style="width:100%;padding:8px 12px;border:1.5px solid #dee2e6;border-radius:6px;
           font-size:13px;margin-top:4px;cursor:pointer;">
    {sop_opts}
  </select>
</div>'''

    rules_selector = f'''
<div style="margin-bottom:10px;">
  <label style="font-size:12px;font-weight:600;color:#6c757d;">Select Rules File</label>
  <select id="rules-file-select" onchange="switchFile('py', this.value)"
    style="width:100%;padding:8px 12px;border:1.5px solid #dee2e6;border-radius:6px;
           font-size:13px;margin-top:4px;cursor:pointer;">
    {rules_opts}
  </select>
</div>'''

    html = html.replace(
        '<textarea class="editor" id="ed-txt"',
        sop_selector + '<textarea class="editor" id="ed-txt"'
    )
    html = html.replace(
        '<textarea class="editor" id="ed-py"',
        rules_selector + '<textarea class="editor" id="ed-py"'
    )

    switch_js = '''
function switchFile(t, fname) {
  var fn = fname || (t === 'txt'
    ? document.getElementById('sop-file-select').value
    : document.getElementById('rules-file-select').value);
  setSt(t, 'Loading...', 'var(--text-muted)');
  fetch('/api/file?name=' + encodeURIComponent(fn))
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) {
        document.getElementById('ed-' + t).value = d.content;
        cc(t);
        setSt(t, 'Loaded: ' + fn, 'var(--success)');
      } else {
        setSt(t, 'Error: ' + d.error, '#dc3545');
      }
    });
}
'''
    fn_replacement = """var fn = t === 'txt'
      ? (document.getElementById('sop-file-select') ? document.getElementById('sop-file-select').value : 'sops/telecom_unblock.txt')
      : (document.getElementById('rules-file-select') ? document.getElementById('rules-file-select').value : 'rules/telecom_rules.py');"""

    html = re.sub(
        r"var fn\s*=\s*t\s*===\s*['\"]txt['\"]\s*\?[^;]+;",
        fn_replacement,
        html
    )

    html = html.replace("</script>", switch_js + "\n</script>", 1)
    html = html.replace(
        "RAG AI Agent &middot; /home/postgres/AI_AGENT/admin/",
        f"RAG AI Agent &middot; {BASE_DIR}/"
    )

    return html


# =============================================================
# HTTP HANDLER
# =============================================================
class Handler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        path   = urlparse(self.path).path
        cookie = self.headers.get("Cookie", "")
        user   = _get_session(cookie)

        if path.startswith("/static/"):
            file_path = path.lstrip("/")
            try:
                with open(os.path.join(BASE_DIR, file_path), "rb") as f:
                    self.send_response(200)
                    ct = "image/png" if file_path.endswith(".png") else "image/jpeg"
                    self.send_header("Content-Type", ct)
                    self.end_headers()
                    self.wfile.write(f.read())
            except FileNotFoundError:
                self.send_error(404)
            return

        if path == "/login":
            self._serve_login()
            return

        if path == "/logout":
            _destroy_session(cookie)
            self._redirect("/login")
            return

        if not user:
            self._redirect("/login")
            return

        if path == "/progress":
            self._handle_progress()
            return

        if path == "/admin":
            try:
                self._html(build_admin_html())
            except Exception as e:
                self._html(f"<pre>Admin error: {e}</pre>")
            return

        if path == "/api/service":
            self._json(_api_get_services())
            return

        if path == "/api/backups":
            self._json(_api_get_backups())
            return

        if path == "/api/file":
            params = parse_qs(urlparse(self.path).query)
            name   = params.get("name", [None])[0]
            self._json(_api_get_file(name) if name else {"ok": False, "error": "Missing name"})
            return

        if path == "/api/backup/download":
            params  = parse_qs(urlparse(self.path).query)
            name    = params.get("name", [None])[0]
            if not name:
                self.send_error(400)
                return
            bk_path = os.path.join(BACKUP_DIR, name)
            if not os.path.exists(bk_path):
                self.send_error(404)
                return
            with open(bk_path, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", f'attachment; filename="{name}"')
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/api/backup/restore":
            params = parse_qs(urlparse(self.path).query)
            name   = params.get("name", [None])[0]
            self._json(_api_restore_backup(name) if name else {"ok": False, "error": "Missing name"})
            return

        self._html(build_html(user))

    def do_POST(self):
        path = urlparse(self.path).path

        if path == "/login":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            uname  = body.get("username", "").strip()
            pw     = body.get("password", "").strip()
            stored = USERS.get(uname)
            if stored and stored == _hash(pw):
                token = _create_session(uname)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Set-Cookie",
                    f"session={token}; Path=/; HttpOnly; SameSite=Strict")
                self.end_headers()
                self.wfile.write(json.dumps({"ok": True, "user": uname}).encode())
            else:
                self._json({"ok": False, "error": "Invalid username or password"})
            return

        cookie = self.headers.get("Cookie", "")
        if not _get_session(cookie):
            self._json({"ok": False, "error": "Not authenticated"})
            return

        if path == "/api/service":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            self._json(_api_service_action(body))
            return

        if path == "/api/file":
            length  = int(self.headers.get("Content-Length", 0))
            body    = json.loads(self.rfile.read(length))
            self._json(_api_save_file(body.get("name", ""), body.get("content", "")))
            return

        if path == "/upload":
            self._handle_upload()
            return

        self.send_error(404)

    def _serve_login(self):
        login_path = os.path.join(BASE_DIR, "static", "login.html")
        with open(login_path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(data)

    def _redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def _html(self, html):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def _json(self, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body)

    def _handle_progress(self):
        params = parse_qs(urlparse(self.path).query)
        job_id = params.get("job_id", [None])[0]
        if not job_id:
            self.send_error(400)
            return

        self.send_response(200)
        self.send_header("Content-Type",  "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection",    "keep-alive")
        self.end_headers()

        with _progress_lock:
            q = _progress_queues.get(job_id)

        if not q:
            self._sse({"type": "error", "msg": "Job not found"})
            return

        while True:
            try:
                msg = q.get(timeout=120)
                self._sse(msg)
                if msg.get("type") in ("done", "error"):
                    break
            except queue.Empty:
                break

        with _progress_lock:
            _progress_queues.pop(job_id, None)

    def _sse(self, data):
        try:
            self.wfile.write(("data: " + json.dumps(data) + "\n\n").encode())
            self.wfile.flush()
        except Exception:
            pass

    def _handle_upload(self):
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                "REQUEST_METHOD": "POST",
                "CONTENT_TYPE": self.headers.get("Content-Type"),
            }
        )

        app_key      = form.getvalue("app_key",      "")
        scenario_key = form.getvalue("scenario_key", "")
        file_item    = form["file"]

        if not app_key or not scenario_key or not file_item.filename:
            self.send_error(400, "Missing fields")
            return

        job_id = str(uuid.uuid4())
        q = queue.Queue()
        with _progress_lock:
            _progress_queues[job_id] = q

        fd, input_path = tempfile.mkstemp(suffix=".csv")
        with os.fdopen(fd, "wb") as f:
            f.write(file_item.file.read())

        output_path = input_path.replace(".csv", "_output.xlsx")

        try:
            process_csv(input_path, output_path, app_key, scenario_key,
                        progress_queue=q)

            self.send_response(200)
            self.send_header(
                "Content-Type",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="{app_key}_{scenario_key}_output.xlsx"'
            )
            self.send_header("X-Job-Id", job_id)
            self.end_headers()

            with open(output_path, "rb") as f:
                self.wfile.write(f.read())

        except Exception as e:
            q.put({"type": "error", "msg": str(e)})
            self.send_error(500, str(e))

        finally:
            if os.path.exists(input_path):
                os.remove(input_path)
            if os.path.exists(output_path):
                os.remove(output_path)


# =============================================================
# START
# =============================================================
if __name__ == "__main__":
    print(f"Global AI Ticket Analyzer v3 running on http://0.0.0.0:{PORT}")
    print(f"Admin Panel: http://0.0.0.0:{PORT}/admin")
    print(f"Loaded apps: {list(get_all_apps().keys())}")
    print(f"Users loaded: {list(USERS.keys()) or 'NONE — set AGENT_USER_* env vars!'}")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
