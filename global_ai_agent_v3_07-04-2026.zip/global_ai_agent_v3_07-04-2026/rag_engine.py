# =============================================================
# rag_engine.py
# RAG search using LlamaIndex.
#
# v3 change: replaces the custom cosine similarity implementation
# with LlamaIndex. Output is identical — code is much simpler.
#
# LlamaIndex handles:
#   - Loading SOP documents
#   - Chunking
#   - Generating embeddings (via Ollama)
#   - Similarity search
#
# Install: pip install llama-index llama-index-embeddings-ollama
# =============================================================

import logging
import os

logger = logging.getLogger(__name__)


class RAGEngine:

    def __init__(self, sop_file, embed_url, embed_model):
        """
        sop_file    : path to the .txt SOP file for this app/scenario
        embed_url   : Ollama embedding URL e.g. http://localhost:11434
        embed_model : embedding model e.g. nomic-embed-text:v1.5

        Index is built in memory on first use.
        No separate indexing step needed — LlamaIndex handles it automatically.
        """
        self.sop_file    = sop_file
        self.embed_url   = embed_url
        self.embed_model = embed_model
        self._index      = None

    def _build_index(self):
        """Build LlamaIndex in memory from the SOP file."""
        from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
        from llama_index.embeddings.ollama import OllamaEmbedding

        # Point to the folder containing the SOP file
        sop_dir = os.path.dirname(self.sop_file)
        sop_filename = os.path.basename(self.sop_file)

        # Extract just the Ollama base URL (without /api/embeddings)
        base_url = self.embed_url.replace("/api/embeddings", "").replace("/api/embed", "")

        embed_model = OllamaEmbedding(
            model_name  = self.embed_model,
            base_url    = base_url,
        )

        documents = SimpleDirectoryReader(
            input_files=[self.sop_file]
        ).load_data()

        self._index = VectorStoreIndex.from_documents(
            documents,
            embed_model=embed_model,
        )
        logger.info(f"RAG index built from: {self.sop_file}")

    def search(self, query, top_k=1, scenario=None, score_threshold=0.60):
        """
        Search the SOP for context relevant to the query.

        Returns list of (score, text, chunk_id, section) tuples.
        Returns empty list if nothing found above threshold.

        Note: scenario and score_threshold filtering are best-effort
        with LlamaIndex — it returns the most similar chunks by default.
        """
        try:
            if self._index is None:
                self._build_index()

            query_engine = self._index.as_query_engine(similarity_top_k=top_k)
            response     = query_engine.query(query)

            results = []
            for i, node in enumerate(response.source_nodes):
                score = node.score if node.score is not None else 0.0
                if score < score_threshold:
                    continue
                results.append((
                    float(score),
                    node.text,
                    f"CHUNK_{i+1}",
                    "SOP_SECTION"
                ))

            return results

        except Exception as e:
            logger.error(f"RAG search error: {e}")
            return []
