cd /AEM/.RSP/global_ai_agent_v3
python3.9 -m venv venv
source venv/bin/activate
which python
/AEM/.RSP/global_ai_agent_v3/venv/bin/python -m pip install --proxy http://10.94.147.19:8080 pandas openpyxl requests oracledb flask watchdog pyyaml
