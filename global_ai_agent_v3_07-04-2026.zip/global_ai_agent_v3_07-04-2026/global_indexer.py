# =============================================================
# global_indexer.py
# Run this to (re)build RAG vectors for any/all apps.
#
# Usage:
#   python global_indexer.py                        # index all
#   python global_indexer.py TELECOM_DIGITAL        # one app
#   python global_indexer.py TELECOM_DIGITAL UNBLOCK # one scenario
# =============================================================

import json
import re
import sys
import os
import requests

from app_registry import _load_registry, get_app_config
from config_utils import load_properties

EMBED_TIMEOUT = 120


def generate_embedding(text, embed_url, embed_model):
    response = requests.post(
        embed_url,
        json={"model": embed_model, "prompt": text},
        timeout=EMBED_TIMEOUT
    )
    response.raise_for_status()
    return response.json()["embedding"]


def index_sop(sop_file, vector_file, embed_url, embed_model):
    """Parse a SOP text file and generate embeddings for each section chunk."""

    print(f"  Indexing: {sop_file}")

    with open(sop_file, "r", encoding="utf-8") as f:
        lines = f.readlines()

    vectors = []
    current_scenario = None
    current_section_title = None
    buffer = []
    chunk_counter = 1

    for line in lines:
        stripped = line.strip()

        # Detect scenario markers from SECTION headers
        if "UNBLOCKING SOP" in stripped or "SECTION 1" in stripped:
            current_scenario = "UNBLOCK"
            continue
        elif "FRC SOP" in stripped or "SECTION 2" in stripped:
            current_scenario = "FRC"
            continue
        elif "REFUND SOP" in stripped or "SECTION 3" in stripped:
            current_scenario = "REFUND"
            continue
        elif "JOURNEY TYPE" in stripped or "SECTION 4" in stripped:
            current_scenario = "GENERAL"
            continue
        elif "GENERAL NOTES" in stripped or "SECTION 5" in stripped:
            current_scenario = "GENERAL"
            continue

        # Detect numbered section headers like 1.1, 2.3 etc
        match = re.match(r"^\d+\.\d+\s+(.+)", stripped)
        if match:
            if buffer and current_section_title:
                # Include section title IN chunk text for better embedding match
                chunk_text = current_section_title + "\n" + "\n".join(buffer)
                embedding = generate_embedding(chunk_text, embed_url, embed_model)
                vectors.append({
                    "chunk_id": f"CHUNK_{chunk_counter}",
                    "section": current_section_title,
                    "scenario": current_scenario,
                    "text": chunk_text,
                    "embedding": embedding
                })
                chunk_counter += 1
                buffer = []
            current_section_title = stripped
            continue

        # Skip separators and END markers
        if stripped.startswith("=") or stripped.startswith("SECTION") or stripped == "END OF DOCUMENT":
            continue

        if stripped:
            buffer.append(stripped)

    # Save last chunk
    if buffer and current_section_title:
        chunk_text = current_section_title + "\n" + "\n".join(buffer)
        embedding = generate_embedding(chunk_text, embed_url, embed_model)
        vectors.append({
            "chunk_id": f"CHUNK_{chunk_counter}",
            "section": current_section_title,
            "scenario": current_scenario,
            "text": chunk_text,
            "embedding": embedding
        })

    # Write vectors
    os.makedirs(os.path.dirname(vector_file), exist_ok=True)
    with open(vector_file, "w", encoding="utf-8") as f:
        json.dump(vectors, f, indent=2)

    print(f"  Done: {len(vectors)} chunks → {vector_file}")


def index_app_scenario(app_key, scenario_key):
    cfg = get_app_config(app_key, scenario_key)
    db_props = load_properties(cfg["db_config_path"])
    embed_url = db_props["embedding.url"]
    embed_model = db_props["embedding.model"]

    index_sop(cfg["sop_file"], cfg["vector_file"], embed_url, embed_model)


def index_all():
    registry = _load_registry()
    for app_key, app_data in registry.items():
        print(f"\n[APP] {app_key}")
        for scenario_key in app_data.get("scenarios", {}).keys():
            print(f"  [SCENARIO] {scenario_key}")
            try:
                index_app_scenario(app_key, scenario_key)
            except Exception as e:
                print(f"  ERROR: {e}")


if __name__ == "__main__":
    args = sys.argv[1:]

    if len(args) == 0:
        print("Indexing ALL apps and scenarios...")
        index_all()

    elif len(args) == 1:
        app_key = args[0]
        print(f"Indexing all scenarios for app: {app_key}")
        registry = _load_registry()
        for scenario_key in registry.get(app_key, {}).get("scenarios", {}).keys():
            index_app_scenario(app_key, scenario_key)

    elif len(args) == 2:
        app_key, scenario_key = args
        print(f"Indexing {app_key} / {scenario_key}")
        index_app_scenario(app_key, scenario_key)

    else:
        print("Usage: python global_indexer.py [APP_KEY] [SCENARIO_KEY]")

